#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# 2014 - Anonymous

import urllib,urllib2,re,HTMLParser,os,sys,time
try:
        import xbmcgui,xbmc,xbmcaddon,xbmcplugin
        from resolvers import *
except:
        pass

root_url = 'http://en.hdporno.ru/'

try:
        addon_id = 'plugin.video.system'
        selfAddon = xbmcaddon.Addon(id=addon_id)
        addonfolder = selfAddon.getAddonInfo('path')
        artfolder = addonfolder + '/resources/img/'
        down_path = selfAddon.getSetting('download-folder')
        mensagemprogresso = xbmcgui.DialogProgress()
except:
        pass

def abrir_url(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def formatString(texto):
        texto = texto.replace("&#8211;","-")
        texto = texto.replace("&#8217;","'")
        texto = texto.replace("&#038;","&")
        texto = texto.replace("&amp;","&")
        return texto
        
def find_match(regexp,src):
        return re.compile(regexp,flags=0).findall(src)

def Translate(texto):
        return selfAddon.getLocalizedString(texto).encode('utf-8')

# 501
##################################################################################################################################################################################################################
def MainMenu():
	addDir("Categories",'-',560,artfolder + 'videos.png')
	addDir("Highest Rated - Today",'http://en.hdporno.ru/reting/?sort=1',551,artfolder + 'videos.png')
	addDir("Highest Rated - This Month",'http://en.hdporno.ru/reting/?sort=2',551,artfolder + 'videos.png')
	addDir("Highest Rated - All Time",'http://en.hdporno.ru/reting/?sort=3',551,artfolder + 'videos.png')
	addDir("Most Popular - Today",'http://en.hdporno.ru/pop/?sort=1',551,artfolder + 'videos.png')
	addDir("Most Popular - This Month",'http://en.hdporno.ru/pop/?sort=2',551,artfolder + 'videos.png')
	addDir("Most Popular - All Time",'http://en.hdporno.ru/pop/?sort=3',551,artfolder + 'videos.png')
	addDir("Pornstars",'http://en.hdporno.ru/porno-models/',570,artfolder + 'videos.png')
	addDir("Search",'-',580,artfolder + 'search.png')
	xbmc.executebuiltin("Container.SetViewMode(200)")


# 551
##################################################################################################################################################################################################################
def ListVideos(url):
        print "ListVideos: " + url
        pageSource = abrir_url(url)
        pageSource = pageSource.replace("\n","")
        
        videoblock = re.compile('<div id="preview">(.+?)</a></div>').findall(pageSource)

        a = []
        for x in range(0, len(videoblock)):
                match = re.compile('<div class="preview_screen"><a href="(.+?)"><img src="(.+?)" alt="(.+)" onmouseover="(.+)" onmouseout="(.+)"').findall(videoblock[x])[0]
                duration = re.compile('<div class="dlit">(.+?)</div>').findall(videoblock[x])[0]
                rating = re.compile('<div class="rate">(.+?)</div>').findall(videoblock[x])[0]
                views = re.compile('<div class="views">(.+?)</div>').findall(videoblock[x])[0]
                
                temp = [match[0],match[2],match[1],duration,rating,views];
                a.append(temp)

        print 'Total Videos: '+ str(len(videoblock))
        total=len(a)

        for url,title,img,duration,rating,views in a:
                if img[:2] == '//': img = 'http:' + img
                title = '(' + duration + ' - ' + rating + ' - ' + views + ') ' + title
                addDir(title,url,552,img,False,total,True)
        
        try:
                next_page = re.compile('<div class="navigation">  <a href="(.+?)"').findall(pageSource)[0]
        except:
                next_page = re.compile('<\/a>   <a href="(.+?)" title=\'Next(.*?)\'>Next &gt;&gt;').findall(pageSource)[0][0]

        addDir(Translate(2050),next_page,551,artfolder + 'next.png')
        print 'Next Page: '+str(next_page)

        
        xbmc.executebuiltin("Container.SetViewMode(500)")

#url = "http://en.xhdporno.net/category/bolyshie-sisyki/"
#url = "http://en.xhdporno.net/category/bolyshie-sisyki/page-3/"
#ListVideos(url)
# 552
##################################################################################################################################################################################################################
def FindVideoSources(name,url,iconimage):
        #mensagemprogresso.create('Adults TV', Translate(2008),Translate(2009))
        #mensagemprogresso.update(0)
        print 'FindVideoSources'
        print url
        html = abrir_url(url)
        try: 
                video_url = re.compile('file:"(.+?mp4)"').findall(html)[0]
        except: return

        #url_video = urllib.quote(video_url)
        video_url = video_url.replace("%3A",":")
        video_url = video_url.replace("480p","720p")
        
        if video_url: play(name,video_url,iconimage)
        
# 560          
##################################################################################################################################################################################################################
def CategoriesMenu():
        addLink("[B][COLOR white]CATEGORIES[/COLOR][/B]",'','-')

        page = abrir_url(root_url)
        match = re.compile('<a href="/(category.+?)">(.+?)</a>').findall(page)
        for url, title in match:
                addDir(title,root_url+url,551,artfolder + 'videos.png')
                
        xbmc.executebuiltin("Container.SetViewMode(50)")
        
# 570
##################################################################################################################################################################################################################
def ListPornstars(url):
        pageSource = abrir_url(url)
        match = re.compile('<div class="preview_screen"><a href="/(.+?)"><img src="(.+?)" alt="(.+?)" title="(.+?)">').findall(pageSource)
        for url, img, title1, title2 in match:
                addDir(title2,root_url+url,551,img)
        try:
                next_page = re.compile(' <a href="(.+)" title=\'Next \(\d+\)\'>Next &gt;&gt;').findall(pageSource)[0]
                print 'Next Page: '+next_page
                addDir(Translate(2050),next_page,570,artfolder + 'next.png')
        except: pass

        xbmc.executebuiltin("Container.SetViewMode(500)")

        
# 580
##################################################################################################################################################################################################################
def Search():
        keyb = xbmc.Keyboard('', Translate(2022)+':')
        keyb.doModal()
        if (keyb.isConfirmed()):
                searchText = keyb.getText()
                searchParameter=urllib.quote(searchText)
                url = 'http://en.hdporno.ru/search?text=' + str(searchParameter)

                ListVideos (url)


##################################################################################################################################################################################################################
def mode(mode,name,url,iconimage):
        if mode==501: MainMenu()
        elif mode==551: ListVideos(url)
        elif mode==552: FindVideoSources(name,url,iconimage)
        elif mode==580: Search()
        elif mode==205: download(name,url)
        elif mode==206: selfAddon.openSettings()
        elif mode==560: CategoriesMenu()
        elif mode==570: ListPornstars(url)
        
        
##################################################################################################################################################################################################################
def download(name,url):
        if down_path == '':
                dialog = xbmcgui.Dialog()
                dialog.ok(Translate(2010), Translate(2024))
                selfAddon.openSettings()
                return
        #mensagemprogresso.create('Adults TV', Translate(2008),Translate(2009))
        #mensagemprogresso.update(0)
        
        try: video_url = re.compile('<iframe src="(.+?)"').findall(abrir_url(url))[0]
        except: return
        if re.search('urlvk=',video_url): video_url = urllib.unquote(video_url.split('urlvk=')[1])
        if video_url[:2] == '//': video_url = 'http:' + video_url
        url_video = vkcom_resolver(video_url)
        
        name = re.sub('[^-a-zA-Z0-9_.()\\\/ ]+', '',name)
        name += ' - ' + url_video[1] + '.mp4'
        mypath=os.path.join(down_path,name)
        if os.path.isfile(mypath) is True:
                dialog = xbmcgui.Dialog()
                dialog.ok(Translate(2010),Translate(2025))
                return
        #mensagemprogresso.close()
        dp = xbmcgui.DialogProgress()
        dp.create('Download')
        start_time = time.time()                # url - url do ficheiro    mypath - localizacao ex: c:\file.mp3
        try: urllib.urlretrieve(url, mypath, lambda nb, bs, fs: dialogdown(nb, bs, fs, dp, start_time))
        except:
                while os.path.exists(mypath): 
                        try: os.remove(mypath); break 
                        except: pass
                dp.close()
                return
        dp.close()
        
##################################################################################################################################################################################################################
def dialogdown(numblocks, blocksize, filesize, dp, start_time):
      try:
            percent = min(numblocks * blocksize * 100 / filesize, 100)
            currently_downloaded = float(numblocks) * blocksize / (1024 * 1024) 
            kbps_speed = numblocks * blocksize / (time.time() - start_time) 
            if kbps_speed > 0: eta = (filesize - numblocks * blocksize) / kbps_speed 
            else: eta = 0 
            kbps_speed = kbps_speed / 1024 
            total = float(filesize) / (1024 * 1024) 
            mbs = '%.02f MB %s %.02f MB' % (currently_downloaded,Translate(2026), total) 
            e = ' (%.0f Kb/s) ' % kbps_speed 
            tempo = Translate(2027) + ' %02d:%02d' % divmod(eta, 60) 
            dp.update(percent, mbs + e,tempo)
      except: 
            percent = 100 
            dp.update(percent) 
      if dp.iscanceled(): 
            dp.close()
            raise StopDownloading('Stopped Downloading')

##################################################################################################################################################################################################################
class StopDownloading(Exception):
      def __init__(self, value): self.value = value 
      def __str__(self): return repr(self.value)


def abrir_url(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link
                
def addLink(name,url,iconimage):
        name = formatString(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', addonfolder + '/fanart.jpg')
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok

def addDir(name,url,mode,iconimage,pasta = True,total=1,video=False):
        name = formatString(name)
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', addonfolder + '/fanart.jpg')
        cm =[]
        if video: 
                cm.append(('Download', 'XBMC.RunPlugin(%s?mode=205&url=%s&name=%s)' % (sys.argv[0], urllib.quote_plus(url),name)))
                liz.addContextMenuItems(cm, replaceItems=True) 
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=pasta,totalItems=total)
        return ok

def play(name,streamurl,iconimage = "DefaultVideo.png"):
        listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        player = xbmc.Player()
        #streamurl = "https://lh3.googleusercontent.com/3VDqSJZi2gEINCTJV5fkPQhQ0jQ2L6vHrHfpXxL3EPE8CqJ7XNvmakAb40xnKIrv_A_9fsalD8qx=m37"
        player.play(streamurl,listitem)

