import okxxx

#-----------------------------------------------------------------------------------------------
def test_VideosMenu():
        videoItemArr = okxxx.VideosMenu(okxxx.urls.allVideos.value)
        assert len(videoItemArr) > 0

#-----------------------------------------------------------------------------------------------
def test_TagsMenu():
        menuItemsArr = okxxx.TagsMenu(okxxx.urls.tags.value)
        assert len(menuItemsArr) > 0

#-----------------------------------------------------------------------------------------------
def test_ChannelsMenu():
        channelItemsArr = okxxx.ChannelsMenu(okxxx.urls.channels.value)
        assert len(channelItemsArr) > 0

#-----------------------------------------------------------------------------------------------
def test_PornstarsMenu():
        pornstarItemsArr = okxxx.PornstarsMenu(okxxx.urls.pornstars.value)
        assert len(pornstarItemsArr) > 0

#-----------------------------------------------------------------------------------------------
def test_GetVideoUrl():
        videoUrl = okxxx.GetVideoUrl(okxxx.urls.singleVideo.value)
        assert videoUrl.startswith('https://')




