import re
import html
import common
import xbmcgui,xbmc,xbmcaddon,xbmcplugin
from enum import Enum

#-----------------------------------------------------------------------------------------------
class mode(Enum):
        Min = 600
        MainMenu = 601
        TopTagsMenu = 602
        ChannelsMenu = 603
        ListChannels = 604
        VideosMenu = 605
        PlayVideo = 606
        PornstarsMenu = 607
        CreatorsMenu = 608
        Search = 609
        Max = 699

#-----------------------------------------------------------------------------------------------
class urls(Enum):
        rootUrl = 'https://spankbang.com'
        trendingVideos = rootUrl+'/trending_videos'
        topTags = rootUrl+'/tags'
        channels = rootUrl+'/channels'
        exclusive = rootUrl+'/s/exclusive/'
        mostPopular = rootUrl+'/most_popular'
        pornstars = rootUrl+'/pornstars'
        creators = rootUrl+'/creators'
        search = rootUrl+'/keyword?keyword=={text}'
        singleVideo = rootUrl+'/a2amy/video/three+paths+to+pleasure'

#-----------------------------------------------------------------------------------------------
def setMode(newMode,name,url,iconimage):
        if newMode==mode.MainMenu.value: MainMenu()
        elif newMode==mode.VideosMenu.value: VideosMenu(url)
        elif newMode==mode.ChannelsMenu.value: ChannelsMenu(url)
        elif newMode==mode.PlayVideo.value: PlayVideo(name,url,iconimage)
        elif newMode==mode.Search.value: Search(url)
        #elif newMode==605: common.download(name,url)
        #elif newMode==206: common.selfAddon.openSettings()
        elif newMode==mode.TopTagsMenu.value: TopTagsMenu(url)
        elif newMode==mode.PornstarsMenu.value: PornstarsMenu(url)
        elif newMode==mode.CreatorsMenu.value: CreatorsMenu(url)
        
#-----------------------------------------------------------------------------------------------
def PlayVideo(name,url,iconimage):
        print ("PlayVideo: " + url)

        common.ShowMessage('System', "Opening Video. Please Wait...")

        video_url = GetVideoUrl(url)

        if video_url: common.PlayVideo(name,video_url,iconimage)

#-----------------------------------------------------------------------------------------------
def Search(url):
        searchText = common.GetSearchText()
        
        if searchText:
                VideosMenu (url.replace('{text}',searchText))

#Search(urls.search.value)
#-----------------------------------------------------------------------------------------------
def MainMenu():
        common.addLinkItem("[B][COLOR white]SpankBang[/COLOR][/B]",None,None)

        folderItemsArr = [
                ["Trending Videos", urls.trendingVideos.value, mode.VideosMenu.value],
                ["Top Tags", urls.topTags.value, mode.TopTagsMenu.value],
                ["Channels", urls.channels.value, mode.ChannelsMenu.value],
                ["Popular", urls.mostPopular.value, mode.VideosMenu.value],
                ["Exclusive", urls.exclusive.value, mode.VideosMenu.value],
                ["Pornstars", urls.pornstars.value, mode.PornstarsMenu.value],
                ["Creators", urls.creators.value, mode.CreatorsMenu.value],
                ["Search", urls.search.value, mode.Search.value]
        ]
        common.addFolderItemsArr(folderItemsArr,'','')

#-----------------------------------------------------------------------------------------------
def VideosMenu(url):
        print ("VideosMenu: " + url)
        pageHtml = common.OpenUrl(url)

        #pattern1 = r'<div\s+data-testid="video-item"\s+\S+\s+class=".+"\s+>\s+<a\s+href="(.+)"\s+class=".+"\s+\S+\s+\S+\s+\S+\s+\S+ \S+\s+\S+ \S+\s+>\s+<picture>\s+<img\s+src="(.+)"+\s+loading=".+"\s+alt="(.+)"\s+class=".+"\s+x-ref=".+"\s+\/>\s+<\/picture>\s+<div\s+x-show=".+"\s+class=".+"\s+><\/div>\s+<video\s+id=".+"\s+muted\s+x-show=".+"\s+x-ref=".+"\s+class=".+"\s+x-cloak\s+playsinline\s+@error=".+"\s+@canplay=".+"\s+@ended=".+"\s+>\s+<source data-src=".+"\s+\/>\s+<\/video>\s+<div\s+class=".+"\s+data-testid="video-item-resolution"'
        pattern1 = r'<div\s+data-testid="video-item"\s+\S+\s+class=".+"\s+>\s+<a\s+href="(.+)"\s+class=".+"\s+\S+\s+\S+\s+\S+\s+\S+ \S+\s+\S+ \S+\s+>\s+<picture>\s+<img\s+src="(.+)"+\s+loading=".+"\s+alt="(.+)"\s+class=".+"\s+x-ref=".+"\s+\/>\s+<\/picture>\s+<div\s+x-show=".+"\s+class=".+"\s+><\/div>\s+<video\s+id=".+"\s+muted\s+x-show=".+"\s+x-ref=".+"\s+class=".+"\s+x-cloak\s+playsinline\s+@error=".+"\s+@canplay=".+"\s+@ended=".+"\s+>\s+<source data-src=".+"\s+\/>\s+<\/video>'
        pattern2 = r'<div class="video-item responsive-page".+">\s+.+\s+<a\s+href="(.+)"\s+.+.+\s+.+\s+.+\s.+\s.+\s+<img\s+src=".+"\s+data-src="(.+)"\s+alt="(.+)"'

        match = []
        match1 = re.compile(pattern1).findall(pageHtml)
        match2 = re.compile(pattern2).findall(pageHtml)

        if len(match1)>0: match=match1
        if len(match2)>0: match=match2

        skip = 8
        curr = 0

        videoItemsArr = []
        for url, img, title in match:
                curr = curr + 1
                if curr <= skip: continue

                title = html.unescape(title)
                url = urls.rootUrl.value + url
                print ("title: "+title)
                print ("img: "+img)
                print ("url: "+url)
                print ("---------------------")
                videoItemsArr.append([title,url,img,mode.PlayVideo.value])
        
        nextPageUrl=""        
        try:
                nextPageUrl = re.compile(r'<li class="active"><a>(\d+)</a></li><li><a href="(.+?)">').findall(pageHtml)[0]
                nextPageUrl = urls.rootUrl.value + nextPageUrl[1]
        except:
                nextPageUrl=""

        print ("Next Page: "+str(nextPageUrl))
        
        common.addVideoItemsArr(videoItemsArr,nextPageUrl,mode.VideosMenu.value)

        return videoItemsArr
#VideosMenu(urls.trendingVideos.value)
#VideosMenu("https://spankbang.com/1gk/channel/spankbang+gold/")
#-----------------------------------------------------------------------------------------------
def ChannelsMenu(url):
        print ("ListChannels: " + url)

        pageHtml = common.OpenUrl(url)
        match = re.compile(r'<li>\s*<a href="(.+)" class=".+">\s*<img src="(.+)" title="(.+)" alt=".+"').findall(pageHtml)

        videoItemsArr = []
        for url, img, title in match:
                title = html.unescape(title)
                url = urls.rootUrl.value + url
                img = "https:"+img

                print ("title: "+title)
                print ("img: "+img)
                print ("url: "+url)
                print ("---------------------")
                videoItemsArr.append([title,url,img,mode.VideosMenu.value])
        
        nextPageUrl=""        
        try:
                nextPageUrl = re.compile(r'<li class="active"><a>(\d+)<\/a><\/li><li><a href="(.+?)">').findall(pageHtml)[0][1]
                nextPageUrl = urls.rootUrl.value + nextPageUrl
        except:
                nextPageUrl=""

        print ("Next Page: "+str(nextPageUrl))
        
        common.addVideoItemsArr(videoItemsArr,nextPageUrl,mode.ChannelsMenu.value)

        return videoItemsArr

#ChannelsMenu(urls.channels.value)
#-----------------------------------------------------------------------------------------------
def TopTagsMenu(url):
        print ("TopTagsMenu: " + url)
        common.addLinkItem("[B][COLOR white]TOP TAGS[/COLOR][/B]",'','-')

        pageHtml = common.OpenUrl(url)

        tags = re.compile(r'<ul class="top_tags_list">[\s\S]*?<\/ul>').findall(pageHtml)
        match = re.compile(r'<li><a href="(.+)" class="keyword">(.+)<\/a><\/li>').findall(tags[0])

        itemsArr = []
        for url, title in match:
                url = urls.rootUrl.value + url
                title = title.replace('<b>','')
                title = title.replace('</b>','')
                title = html.unescape(title)
                print ("title: "+title)
                print ("url: "+url)
                print ("---------------------")
                itemsArr.append([title,url,mode.VideosMenu.value])
        
        common.addGenericItemsArr(itemsArr,'','')
                
        return itemsArr

#TopTagsMenu(urls.topTags.value)
#-----------------------------------------------------------------------------------------------
def PornstarsMenu(url):
        print ("PornstarsMenu: "+url)

        pageHtml = common.OpenUrl(url)

        match = re.compile(r'<a\s+href="(.+)"\s+class=".+"\s+aria-label=".+"\s+>\s+<img\s+class=".+"\s+src=".+"\s+data-src="(.+)"\s+alt="(.+)"').findall(pageHtml)
        
        videoItemsArr = []
        for url, img, title in match:
                url = urls.rootUrl.value + url
                img = "https:"+img
                title = title.replace('<b>','')
                title = title.replace('</b>','')
                title = html.unescape(title)
                print ("title: "+title)
                print ("img: "+img)
                print ("url: "+url)
                print ("---------------------")
                videoItemsArr.append([title,url,img,mode.VideosMenu.value])
        
        nextPageUrl=""        
        try:
                nextPageUrl = re.compile(r'<li class="active"><a>(\d+)</a></li><li><a href="(.+?)">').findall(pageHtml)[0][1]
                nextPageUrl = urls.rootUrl.value + nextPageUrl
        except:
                nextPageUrl=""

        print ("Next Page: "+str(nextPageUrl))
        
        common.addVideoItemsArr(videoItemsArr,nextPageUrl,mode.PornstarsMenu.value)
                
        return videoItemsArr

#PornstarsMenu(urls.pornstars.value)
#-----------------------------------------------------------------------------------------------
def CreatorsMenu(url):
        print ("CreatorsMenu: "+url)

        pageHtml = common.OpenUrl(url)
        match = re.compile(r'<a href="(.+)" class=".+" >\s+<span class=".+">\s+<img\s+class=".+"\s+alt="(.+)"\s+src=".+"\s+data-src="(.+)"').findall(pageHtml)
        
        videoItemsArr = []
        for url, title, img in match:
                url = urls.rootUrl.value + url
                img = "https:"+img
                title = title.replace('<b>','')
                title = title.replace('</b>','')
                title = html.unescape(title)
                print ("title: "+title)
                print ("img: "+img)
                print ("url: "+url)
                print ("---------------------")
                videoItemsArr.append([title,url,img,mode.VideosMenu.value])
        
        nextPageUrl=""        
        try:
                nextPageUrl = re.compile(r'<li class="next"><a href="(.+)"><svg').findall(pageHtml)[0]
                nextPageUrl = urls.rootUrl.value + nextPageUrl
        except:
                nextPageUrl=""

        print ("Next Page: "+str(nextPageUrl))
        
        common.addVideoItemsArr(videoItemsArr,nextPageUrl,mode.PornstarsMenu.value)
                
        return videoItemsArr

#CreatorsMenu(urls.creators.value)
#-----------------------------------------------------------------------------------------------
def GetVideoUrl(url):
        print ("GetVideoUrl: " + url)

        html = common.OpenUrl(url)

        try:
                stream_url_480p = re.compile(r"'480p':\s\['(\S+)'\]").findall(html)[0]
        except:
                stream_url_480p = ''
        try:
                stream_url_720p = re.compile(r"'720p':\s\['(\S+)'\]").findall(html)[0]
        except:
                stream_url_720p = ''
        try:
                stream_url_1080p = re.compile(r"'1080p':\s\['(\S+)'\]").findall(html)[0]
        except:
                stream_url_1080p = ''
        try:
                stream_url_4k = re.compile(r'"contentUrl": "(.+)"').findall(html)[0]
        except:
                stream_url_4k = ''

        video_url = ''
        video_quality = "1"
        if video_quality == "1":
                video_url = ( stream_url_4k if stream_url_4k != '' else ( stream_url_1080p if stream_url_1080p != '' else ( stream_url_720p if stream_url_720p != '' else stream_url_480p ) ) )
        else:
                video_url = stream_url_480p
                        
                        
        print ("stream_url_480p: " + stream_url_480p)
        print ("stream_url_720p: " + stream_url_720p)
        print ("stream_url_1080p: " + stream_url_1080p)
        print ("stream_url_4k: " + stream_url_4k)

        #url_video = quote(video_url)
        video_url = video_url.replace("%3A",":")

        #video_url = "https://cdnthumb4.spankbang.com/0/5/0/5042243-t.mp4"

        print ("GetVideoUrl: "+video_url)
        return video_url

#GetVideoUrl("https://spankbang.com/a2amy/video/three+paths+to+pleasure")
#-----------------------------------------------------------------------------------------------
