import html
import re
import common
import xbmcgui,xbmc,xbmcaddon,xbmcplugin
from enum import Enum

#-----------------------------------------------------------------------------------------------
class mode(Enum):
        Min = 110
        MainMenu = 111
        VideosMenu = 112
        TagsMenu = 113
        PornstarsMenu = 114
        ChannelsMenu = 115
        PlayVideo = 116
        Search = 117
        Max = 120

#-----------------------------------------------------------------------------------------------
class urls(Enum):
        rootUrl = 'https://freshporno.net'
        allVideos = rootUrl
        tags = rootUrl+'/tags/'
        pornstars = rootUrl+'/models/'
        channels = rootUrl+'/channels/'
        search = rootUrl+'/search/{text}/'
        singleVideo = rootUrl+'/videos/lusting-for-a-fucking/'

#-----------------------------------------------------------------------------------------------
def setMode(newMode,name,url,iconimage):
        match newMode:
                case mode.MainMenu.value: MainMenu()
                case mode.VideosMenu.value: VideosMenu(url)
                case mode.PlayVideo.value: PlayVideo(name,url,iconimage)
                case mode.Search.value: Search(url)
                case mode.TagsMenu.value: TagsMenu(url)
                case mode.ChannelsMenu.value: ChannelsMenu(url)
                case mode.PornstarsMenu.value: PornstarsMenu(url)      
        
#-----------------------------------------------------------------------------------------------
def PlayVideo(name,url,iconimage):
        print ("PlayVideo: " + url)

        common.ShowMessage('System', "Opening Video. Please Wait...")

        video_url = GetVideoUrl(url)

        if video_url: common.PlayVideo(name,video_url,iconimage)

#-----------------------------------------------------------------------------------------------
def Search(url):
        searchText = common.GetSearchText()
        
        if searchText:
                VideosMenu (url.replace('{text}',searchText))

#-----------------------------------------------------------------------------------------------
def GetVideoUrl(url):
        print ("GetVideoUrl: " + url)
        html = common.OpenUrl(url)
        
        pattern1 = r'<meta itemprop="contentUrl" content="(.+)">'
        pattern2 = r"video_url: '(.+)',\s*preview_url"
        pattern3 = r'(https:\/\/.+mp4).+\?download=true&download_filename=(.+\.mp4)'

        match1 = re.compile(pattern1).findall(html)
        match2 = re.compile(pattern2).findall(html)
        match3 = re.compile(pattern2).findall(html)

        videoUrl = ''
        if len(match1)>0:
                videoUrl = re.compile(pattern1).findall(html)[0]
        elif len(match2)>0:
                videoUrl = re.compile(pattern2).findall(html)[0]
        elif len(match3)>0:
                videoUrl = re.compile(pattern3).findall(html)[0]

        print ("videoUrl: "+ str(videoUrl))
       

        return videoUrl

#GetVideoUrl(urls.singleVideo.value)
#-----------------------------------------------------------------------------------------------
def MainMenu():
        common.addLinkItem("[B][COLOR white]FreshPorno[/COLOR][/B]",None,None)
        folderItemsArr = [
                ["All Videos", urls.allVideos.value, mode.VideosMenu.value],
                ["Pornstars", urls.pornstars.value, mode.PornstarsMenu.value],
                ["Channels", urls.channels.value, mode.ChannelsMenu.value],
                ["Tags", urls.tags.value, mode.TagsMenu.value],
                ["Search", urls.search.value, mode.Search.value]
        ]
        common.addFolderItemsArr(folderItemsArr,'','')

#-----------------------------------------------------------------------------------------------
def VideosMenu(url):
        print ("VideosMenu: " + url)
        html = common.OpenUrl(url)
        
        match = re.compile(r'<div class="page-content item">\s+.*\s*<a href="(.+)" title="(.+)" >(?:\s*.+){2} data-original="(.+)" data-webp').findall(html)

        videoItemsArr = []
        for url,title,img in match:
                print ("url: "+url)
                print ("title: "+title)
                print ("img: "+img)
                print ("---------------------")
                videoItemsArr.append([title,url,img,mode.PlayVideo.value])
        
        nextPageUrl=""        
        try:
                nextPageUrl = re.compile(r'<li class="pagination-next"><a href="(.+)"  data-').findall(html)[0]
                nextPageUrl = urls.rootUrl.value + nextPageUrl
        except:
                nextPageUrl=""

        print ("Next Page: "+str(nextPageUrl))
        
        common.addVideoItemsArr(videoItemsArr,nextPageUrl,mode.VideosMenu.value)

        return videoItemsArr


#VideosMenu (urls.allVideos.value)
#VideosMenu ("https://freshporno.net/models/ricky-spanish/")
#VideosMenu ("https://freshporno.net/channels/cuckold-sessions/")
#-----------------------------------------------------------------------------------------------
def TagsMenu(url):
        print ("TagsMenu: " + url)
        common.addLinkItem("[B][COLOR white]TAGS[/COLOR][/B]",'','-')

        html = common.OpenUrl(url)

        match = re.compile(r'<a href="(.+)"><i class=".+"><\/i> (.+)<\/a>').findall(html)

        itemsArr = []
        for url, title in match:
                url = urls.rootUrl.value + url
                title = title.replace('<b>','')
                title = title.replace('</b>','')
                print ("title: "+title)
                print ("url: "+url)
                print ("---------------------")
                itemsArr.append([title,url,mode.VideosMenu.value])
        
        common.addGenericItemsArr(itemsArr,'','')
                
        return itemsArr

#TagsMenu(urls.tags.value)
#-----------------------------------------------------------------------------------------------
def ChannelsMenu(url):
        print ("ChannelsMenu: " + url)

        html = common.OpenUrl(url)

        match = re.compile(r'<a title="(.+)" href="(.+)">\s*.*\s*(?:<img class=".+" src=".+" data-original="(.+)" alt=".+")?(?:.*\s*){5}<\/i>(.+)<\/div>').findall(html)

        videoItemsArr=[]
        for title,url,img,total_videos in match:
                url = url
                img = img.replace(' ','%20')
                title = title + ' (' + total_videos + ' videos)'
                print ("url: "+url)
                print ("img: "+img)
                print ("title: "+title)
                print ("---------------------")
                videoItemsArr.append([title,url,img,mode.VideosMenu.value])
                
        nextPageUrl = ''
        try:
                nextPageUrl = re.compile(r'<li class="pagination-next"><a href="(.+)">Next</a></li>').findall(html)[0]
                nextPageUrl = urls.rootUrl.value + nextPageUrl
                print ("Next Page: "+str(nextPageUrl))
        except:
                pass

        common.addVideoItemsArr(videoItemsArr,nextPageUrl,mode.ChannelsMenu.value)

        return videoItemsArr

#ChannelsMenu (urls.channels.value)
#-----------------------------------------------------------------------------------------------
def PornstarsMenu(url):
        print ("PornstarsMenu: " + url)

        html = common.OpenUrl(url)

        match = re.compile(r'<div class="page-content item">\s*.+\s*<a title="(.+)" href="(.+)"(?:\s*.*){3} data-original="(.+)" alt=".+"(?:.*\s*){5}i>(.+)<\/div>').findall(html)

        videoItemsArr=[]
        for title,url,img,total_videos in match:
                img = img.replace(' ','%20')
                title = title + ' (' + total_videos + ' videos)'
                temp = [url,img,title]
                print ("url: "+url)
                print ("img: "+img)
                print ("title: "+title)
                print ("---------------------")
                videoItemsArr.append([title,url,img,mode.VideosMenu.value])
                
        nextPageUrl = ''
        try:
                nextPageUrl = re.compile(r'<li class="pagination-next"><a href="(.+)"  data').findall(html)[0]
                nextPageUrl = urls.rootUrl.value + nextPageUrl
        except:
                pass
        print ("Next Page: "+str(nextPageUrl))

        common.addVideoItemsArr(videoItemsArr,nextPageUrl,mode.PornstarsMenu.value)

        return videoItemsArr

#PornstarsMenu (urls.pornstars.value)
#-----------------------------------------------------------------------------------------------
