import hdporno

#-----------------------------------------------------------------------------------------------
def test_VideosMenu():
        videoItemArr = hdporno.VideosMenu(hdporno.urls.allVideos.value)
        assert len(videoItemArr) > 0

#-----------------------------------------------------------------------------------------------
def test_CategoriesMenu():
        menuItemsArr = hdporno.CategoriesMenu(hdporno.urls.categories.value)
        assert len(menuItemsArr) > 0

#-----------------------------------------------------------------------------------------------
def test_PornstarsMenu():
        pornstarItemsArr = hdporno.PornstarsMenu(hdporno.urls.pornstars.value)
        assert len(pornstarItemsArr) > 0

#-----------------------------------------------------------------------------------------------
def test_GetVideoUrl():
        videoUrl = hdporno.GetVideoUrl(hdporno.urls.singleVideo.value)
        assert videoUrl.startswith('https://')




