import freshporno

#-----------------------------------------------------------------------------------------------
def test_VideosMenu():
        videoItemArr = freshporno.VideosMenu(freshporno.urls.allVideos.value)
        assert len(videoItemArr) > 0

#-----------------------------------------------------------------------------------------------
def test_TagsMenu():
        tagItemsArr = freshporno.TagsMenu(freshporno.urls.tags.value)
        assert len(tagItemsArr) > 0

#-----------------------------------------------------------------------------------------------
def test_ChannelsMenu():
        channelItemsArr = freshporno.ChannelsMenu(freshporno.urls.channels.value)
        assert len(channelItemsArr) > 0

#-----------------------------------------------------------------------------------------------
def test_PornstarsMenu():
        pornstarItemsArr = freshporno.PornstarsMenu(freshporno.urls.pornstars.value)
        assert len(pornstarItemsArr) > 0

#-----------------------------------------------------------------------------------------------
def test_GetVideoUrl():
        videoUrl = freshporno.GetVideoUrl(freshporno.urls.singleVideo.value)
        assert videoUrl.startswith('https://')




