import html
import re
import common
import xbmcgui,xbmc,xbmcaddon,xbmcplugin
from enum import Enum

#-----------------------------------------------------------------------------------------------
class mode(Enum):
        Min = 200
        MainMenu = 201
        VideosMenu = 202
        TagsMenu = 203
        PornstarsMenu = 204
        ChannelsMenu = 205
        PlayVideo = 206
        Search = 207
        Max = 299

#-----------------------------------------------------------------------------------------------
class urls(Enum):
        rootUrl = 'https://ok.xxx'
        allVideos = rootUrl
        popular = rootUrl+'/popular/'
        trending = rootUrl+'/trending/'
        tags = rootUrl+'/tags/'
        pornstars = rootUrl+'/models/'
        channels = rootUrl+'/channels/'
        search = rootUrl+'/search/{text}/'
        singleVideo = rootUrl+'/video/678723/'

#-----------------------------------------------------------------------------------------------
def setMode(newMode,name,url,iconimage):
        match newMode:
                case mode.MainMenu.value: MainMenu()
                case mode.VideosMenu.value: VideosMenu(url)
                case mode.PlayVideo.value: PlayVideo(name,url,iconimage)
                case mode.Search.value: Search()
                case mode.TagsMenu.value: TagsMenu(url)
                case mode.ChannelsMenu.value: ChannelsMenu(url)
                case mode.PornstarsMenu.value: PornstarsMenu(url)      
        
#-----------------------------------------------------------------------------------------------
def PlayVideo(name,url,iconimage):
        print ("PlayVideo: " + url)

        common.ShowMessage('System', "Opening Video. Please Wait...")

        video_url = GetVideoUrl(url)

        if video_url: common.PlayVideo(name,video_url,iconimage)

#-----------------------------------------------------------------------------------------------
def Search(url):
        searchText = common.GetSearchText()
        
        if searchText:
                VideosMenu (url.replace('{text}',searchText))

#-----------------------------------------------------------------------------------------------
def GetVideoUrl(url):
        html = common.OpenUrl(url)
        
        video_url = re.compile(r"var videoUrl = '(.+)'").findall(html)[0]

        print ("video_url: "+ str(video_url))

        return video_url
#GetVideoUrl(urls.singleVideo.value)
#-----------------------------------------------------------------------------------------------
def MainMenu():
        common.addLinkItem("[B][COLOR white]ok.xxx[/COLOR][/B]",None,None)
        folderItemsArr = [
                ["All Videos", urls.allVideos.value, mode.VideosMenu.value],
                ["Popular", urls.popular.value, mode.VideosMenu.value],
                ["Trending", urls.trending.value, mode.VideosMenu.value],
                ["Pornstars", urls.pornstars.value, mode.PornstarsMenu.value],
                ["Channels", urls.channels.value, mode.ChannelsMenu.value],
                ["Tags", urls.tags.value, mode.TagsMenu.value],
                ["Search", '-', mode.Search.value]
        ]
        common.addFolderItemsArr(folderItemsArr,'','')

#-----------------------------------------------------------------------------------------------
def VideosMenu(url):
        print ("VideosMenu: " + url)
        html = common.OpenUrl(url)
        
        match = re.compile(r'<a href="(.+)" title="(.+)"\s+data-preview-custom=".+">\s+<img class=".+" fetchpriority=".+" loading=".+" src=".+" data-original="(.+)" alt=".+"').findall(html)


        videoItemsArr = []
        for url,title,img in match:
                url = urls.rootUrl.value + url
                img = 'https:' + img.replace(' ','%20')
                print ("url: "+url)
                print ("title: "+title)
                print ("img: "+img)
                print ("---------------------")
                videoItemsArr.append([title,url,img,mode.PlayVideo.value])

        nextPageUrl=""        
        try:
                nextPageUrl = re.compile(r'<li class="pagination-next"><a href="(.+)">Next</a></li>').findall(html)[0]
                nextPageUrl = urls.rootUrl.value + nextPageUrl
        except:
                nextPageUrl=""

        print ("Next Page: "+str(nextPageUrl))
        
        common.addVideoItemsArr(videoItemsArr,nextPageUrl,mode.VideosMenu.value)

        return videoItemsArr
#VideosMenu(urls.allVideos.value)
#-----------------------------------------------------------------------------------------------
def TagsMenu(url):
        print ("TagsMenu: " + url)
        common.addLinkItem("[B][COLOR white]TAGS[/COLOR][/B]",'','-')

        html = common.OpenUrl(url)

        match = re.compile(r'<a class="item" href="(.+)"><i class=".+"><\/i> (.+)<\/a>').findall(html)

        itemsArr = []
        for url, title in match:
                url = urls.rootUrl.value + url
                title = title.replace('<b>','')
                title = title.replace('</b>','')
                print ("title: "+title)
                print ("url: "+url)
                print ("---------------------")
                itemsArr.append([title,url,mode.VideosMenu.value])
        
        common.addGenericItemsArr(itemsArr,'','')
                
        return itemsArr

#-----------------------------------------------------------------------------------------------
def ChannelsMenu(url):
        print ("ChannelsMenu: " + url)

        html = common.OpenUrl(url)

        match = re.compile(r'<a title="(.+)" href="(.+)">\s+<img class=".+" src="(.+)" alt=".+"\/>\s*.+\s*.*\s.*i> (.+)<\/div>').findall(html)

        videoItemsArr=[]
        for title,url,img,total_videos in match:
                url = urls.rootUrl.value + url
                img = img.replace(' ','%20')
                img = 'https:' + img.replace(' ','%20')
                title = title + ' (' + total_videos + ' videos)'
                print ("url: "+url)
                print ("img: "+img)
                print ("title: "+title)
                print ("---------------------")
                videoItemsArr.append([title,url,img,mode.VideosMenu.value])

        nextPageUrl = ''
        try:
                nextPageUrl = re.compile(r'<li class="pagination-next"><a href="(.+)">Next</a></li>').findall(html)[0]
                nextPageUrl = urls.rootUrl.value + nextPageUrl
                print ("Next Page: "+str(nextPageUrl))
        except:
                pass

        common.addVideoItemsArr(videoItemsArr,nextPageUrl,mode.ChannelsMenu.value)

        return videoItemsArr
#ChannelsMenu (urls.channels.value)
#-----------------------------------------------------------------------------------------------
def PornstarsMenu(url):
        print ("PornstarsMenu: " + url)

        html = common.OpenUrl(url)
        match = re.compile(r'<a href="(.+)" title="(.+)">\s*<img.+original="(.+)" alt=".+"\/>\s*.+\s*<\/a>\s*.*i> (.+)<\/div>').findall(html)

        videoItemsArr=[]
        for url,title,img,total_videos in match:
                img = img.replace(' ','%20')
                title = title + ' (' + total_videos + ' videos)'
                temp = [url,img,title]
                print ("url: "+url)
                print ("img: "+img)
                print ("title: "+title)
                print ("---------------------")
                videoItemsArr.append([title,url,img,mode.VideosMenu.value])
                
        nextPageUrl = ''
        try:
                nextPageUrl = re.compile(r'<li class="pagination-next"><a href="(.+)">Next</a></li>').findall(html)[0]
                nextPageUrl = urls.rootUrl.value + nextPageUrl
        except:
                pass
        print ("Next Page: "+str(nextPageUrl))

        common.addVideoItemsArr(videoItemsArr,nextPageUrl,mode.PornstarsMenu.value)

        return videoItemsArr

#-----------------------------------------------------------------------------------------------
