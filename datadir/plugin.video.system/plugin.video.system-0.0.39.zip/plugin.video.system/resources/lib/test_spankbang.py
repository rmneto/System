import spankbang

#-----------------------------------------------------------------------------------------------
def test_VideosMenu():
        itemsArr = spankbang.VideosMenu(spankbang.urls.rootUrl.value)
        assert len(itemsArr) > 0

#-----------------------------------------------------------------------------------------------
def test_ChannelsMenu():
        itemsArr = spankbang.VideosMenu(spankbang.urls.channels.value)
        assert len(itemsArr) > 0

#-----------------------------------------------------------------------------------------------
def test_TopTagsMenu():
        itemsArr = spankbang.TopTagsMenu(spankbang.urls.topTags.value)
        assert len(itemsArr) > 0

#-----------------------------------------------------------------------------------------------
def test_PornstarsMenu():
        itemsArr = spankbang.PornstarsMenu(spankbang.urls.pornstars.value)
        assert len(itemsArr) > 0

#-----------------------------------------------------------------------------------------------
def test_CreatorsMenu():
        itemsArr = spankbang.CreatorsMenu(spankbang.urls.creators.value)
        assert len(itemsArr) > 0

#-----------------------------------------------------------------------------------------------
def test_GetVideoUrl():
        videoUrl = spankbang.GetVideoUrl(spankbang.urls.singleVideo.value)
        assert videoUrl.startswith('https://')




