import re
import common
import xbmcgui,xbmc,xbmcaddon,xbmcplugin
from enum import Enum

#-----------------------------------------------------------------------------------------------
class mode(Enum):
        Min = 500
        MainMenu = 501
        VideosMenu = 502
        PlayVideo = 503
        Search = 504
        CategoriesMenu = 505
        PornstarsMenu = 506
        Max = 599

#-----------------------------------------------------------------------------------------------
class urls(Enum):
        rootUrl = 'https://en.xhdporno.name'
        allVideos = rootUrl
        categories = rootUrl
        highestRated = rootUrl+'/reting/?sort=1'
        mostPopular = rootUrl+'/?sort=1'
        pornstars = rootUrl+'/porno-models/'
        search = rootUrl+'/search?text={text}'
        singleVideo = rootUrl+'/video/strastnye-milfy-s-bolshimi-siskami-ustroili-gruppovushku.html'

#-----------------------------------------------------------------------------------------------
def setMode(newMode,name,url,iconimage):
        match newMode:
                case mode.MainMenu.value: MainMenu()
                case mode.VideosMenu.value: VideosMenu(url)
                case mode.PlayVideo.value: PlayVideo(name,url,iconimage)
                case mode.Search.value: Search(url)
                case mode.CategoriesMenu.value: CategoriesMenu(url)
                case mode.PornstarsMenu.value: PornstarsMenu(url)
        
#-----------------------------------------------------------------------------------------------
def PlayVideo(name,url,iconimage):
        print ("PlayVideo: " + url)

        common.ShowMessage('System', "Opening Video. Please Wait...")

        video_url = GetVideoUrl(url)

        if video_url: common.PlayVideo(name,video_url,iconimage)

#-----------------------------------------------------------------------------------------------
def Search(url):
        searchText = common.GetSearchText()
        
        if searchText:
                VideosMenu (url.replace('{text}',searchText))

#Search(urls.search.value)
#-----------------------------------------------------------------------------------------------
def MainMenu():
        common.addLinkItem("[B][COLOR white]xHDPorno[/COLOR][/B]",None,None)
        folderItemsArr = [
                ["All Videos", urls.allVideos.value, mode.VideosMenu.value],
                ["Categories", urls.categories.value, mode.CategoriesMenu.value],
                ["Most Popular", urls.mostPopular.value, mode.VideosMenu.value],
                ["Highest Rated", urls.highestRated.value, mode.VideosMenu.value],
                ["Pornstars", urls.pornstars.value, mode.PornstarsMenu.value],
                ["Search", urls.search.value, mode.Search.value]
        ]
        common.addFolderItemsArr(folderItemsArr,'','')

#-----------------------------------------------------------------------------------------------
def VideosMenu(url):
        print ("VideosMenu: " + url)
        html = common.OpenUrl(url)
        
        match = re.compile(r'<a href="(.+?)">\s*<img src="(.+?)" alt="(.+?)" onmouseover(?:.*\s){3}<div class="dlit">(.+)<\/div>\s+<div class="rate">(.+)<\/div>\s+<div class="views">(.+)<\/div>\s+').findall(html)

        videoItemsArr = []
        for url, img, title, duration, likes, views in match:
                if img[:2] == '//': img = 'http:' + img
                title = '(' + duration + ' - ' + likes + ' - ' + views + ') ' + title
                print ("url: "+url)
                print ("title: "+title)
                print ("img: "+img)
                print ("---------------------")
                videoItemsArr.append([title,url,img,mode.PlayVideo.value])
        
        nextPageUrl=""        
        try:
                nextPageUrl = re.compile(r'<div class="navigation">\s*<a href="(.+?)"').findall(html)[0]
                nextPageUrl = nextPageUrl
        except:
                nextPageUrl=""

        print ("Next Page: "+str(nextPageUrl))
        
        common.addVideoItemsArr(videoItemsArr,nextPageUrl,mode.VideosMenu.value)

        return videoItemsArr

#VideosMenu(urls.allVideos.value)
#-----------------------------------------------------------------------------------------------
def CategoriesMenu(url):
        print ("CategoriesMenu: "+ url)
        common.addLinkItem("[B][COLOR white]CATEGORIES[/COLOR][/B]",'','-')

        html = common.OpenUrl(url)
        #page = page.replace("\n","")

        match = re.compile(r'<a href="(/category.+?)">(.+?)</a>').findall(html)

        itemsArr = []
        for url, title in match:
                url = urls.rootUrl.value+url
                title = title.replace('<b>','')
                title = title.replace('</b>','')
                print ("title: "+title)
                print ("url: "+url)
                print ("---------------------")
                itemsArr.append([title,url,mode.VideosMenu.value])
        
        common.addGenericItemsArr(itemsArr,'','')
                
        return itemsArr

#CategoriesMenu(urls.rootUrl.value)
#-----------------------------------------------------------------------------------------------
def PornstarsMenu(url):
        print ("PornstarsMenu: " + url)

        html = common.OpenUrl(url)

        match = re.compile(r'<div class="preview_screen"><a href="(/.+?)"><img src="(.+?)" alt=".+?" title="(.+?)">').findall(html)

        videoItemsArr=[]
        for url,img,title in match:
                url = urls.rootUrl.value+url
                print ("url: "+url)
                print ("img: "+img)
                print ("title: "+title)
                print ("---------------------")
                videoItemsArr.append([title,url,img,mode.VideosMenu.value])
                
        nextPageUrl = ''
        try:
                nextPageUrl = re.compile(r' <a href="(.+)" title=\'Next \(\d+\)\'>Next &gt;&gt;').findall(html)[0]
        except:
                pass
        print ("Next Page: "+str(nextPageUrl))

        common.addVideoItemsArr(videoItemsArr,nextPageUrl,mode.PornstarsMenu.value)

        return videoItemsArr

#PornstarsMenu(urls.pornstars.value)
#-----------------------------------------------------------------------------------------------
def GetVideoUrl(url):
        html = common.OpenUrl(url)
        video_url = ""

        try:
                url_1080p = re.compile(r'\[1080p\] (\S+mp4)').findall(html)[0]
        except:
                url_1080p = ""

        try:
                url_720p = re.compile(r'\[720p\] (\S+mp4)').findall(html)[0]
        except:
                url_720p = ""

        try:
                url_480p = re.compile(r'\[480p\] (\S+mp4)').findall(html)[0]
        except:
                url_480p = ""
                
        print ("url_1080p: "+ str(url_1080p))
        print ("url_720p: "+ str(url_720p))
        print ("url_480p: "+ str(url_480p))

        video_url = ( url_1080p if url_1080p != '' else ( url_720p if url_720p != '' else ( url_480p ) ) )

        print ("video_url: "+ str(video_url))

        return video_url

#-----------------------------------------------------------------------------------------------


