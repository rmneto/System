import rusporn

#-----------------------------------------------------------------------------------------------
def test_VideosMenu():
        videoItemArr = rusporn.VideosMenu(rusporn.urls.allVideos.value)
        assert len(videoItemArr) > 0

#-----------------------------------------------------------------------------------------------
def test_CategoriesMenu():
        menuItemsArr = rusporn.CategoriesMenu(rusporn.urls.categories.value)
        assert len(menuItemsArr) > 0

#-----------------------------------------------------------------------------------------------
def test_PornstarsMenu():
        pornstarItemsArr = rusporn.PornstarsMenu(rusporn.urls.pornstars.value)
        assert len(pornstarItemsArr) > 0

#-----------------------------------------------------------------------------------------------
def test_GetVideoUrl():
        videoUrl = rusporn.GetVideoUrl(rusporn.urls.singleVideo.value)
        assert videoUrl.startswith('https://')




