#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# 2014 - Anonymous

import urllib,ssl,urllib2,re,HTMLParser,os,sys,time,utilis
from cookielib import CookieJar
from utilis import *
try:
        import xbmcgui,xbmc,xbmcaddon,xbmcplugin
        from resolvers import *
except:
        pass

root_url = 'https://spankbang.com'

try:
        addon_id = 'plugin.video.system'
        selfAddon = xbmcaddon.Addon(id=addon_id)
        addonfolder = selfAddon.getAddonInfo('path')
        artfolder = addonfolder + '/resources/img/'
        down_path = selfAddon.getSetting('download-folder')
        video_quality = selfAddon.getSetting('kodion.video.quality')
        progressMessage = xbmcgui.DialogProgress()
except:
        pass

def addDir(name,url,mode,iconimage,pasta = True,total=1,video=False):
        name = formatString(name)
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', addonfolder + '/fanart.jpg')
        cm =[]
        if video: 
                cm.append(('Download', 'XBMC.RunPlugin(%s?mode=605&url=%s&name=%s)' % (sys.argv[0], urllib.quote_plus(url),name)))
                liz.addContextMenuItems(cm, replaceItems=True) 
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=pasta,totalItems=total)
        return ok

def formatString(texto):
        texto = texto.replace("&#8211;","-")
        texto = texto.replace("&#8217;","'")
        texto = texto.replace("&#038;","&")
        texto = texto.replace("&amp;","&")
        return texto
        
def find_match(regexp,src):
        return re.compile(regexp,flags=0).findall(src)

def Translate(texto):
        return selfAddon.getLocalizedString(texto).encode('utf-8')

def OpenUrl(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        try:
                gcontext = ssl._create_unverified_context()
                response = urllib2.urlopen(req,context=gcontext)
        except:
                response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link


# 601
##################################################################################################################################################################################################################
def MainMenu():
	addDir("Categories",'-',660,artfolder + 'videos.png')

	addDir("Trending",'https://spankbang.com/trending_videos/',651,artfolder + 'videos.png')
	addDir("Upcoming",'https://spankbang.com/upcoming/',651,artfolder + 'videos.png')
	addDir("Interesting",'https://spankbang.com/interesting/',651,artfolder + 'videos.png')
	addDir("New",'https://spankbang.com/new_videos/',651,artfolder + 'videos.png')
	
	addDir("Popular - Today",'https://spankbang.com/most_popular/?period=today',651,artfolder + 'videos.png')
	addDir("Popular - This Week",'https://spankbang.com/most_popular/?period=week',651,artfolder + 'videos.png')
	addDir("Popular - This Month",'https://spankbang.com/most_popular/?period=month',651,artfolder + 'videos.png')
	addDir("Popular - Three Months",'https://spankbang.com/most_popular/?period=season',651,artfolder + 'videos.png')
	addDir("Popular - This Year",'https://spankbang.com/most_popular/?period=year',651,artfolder + 'videos.png')
	addDir("Popular - All Time",'https://spankbang.com/most_popular/?period=all',651,artfolder + 'videos.png')

	addDir("Most Liked - Today",'https://spankbang.com/top_rated/?period=today',651,artfolder + 'videos.png')
	addDir("Most Liked - This Week",'https://spankbang.com/top_rated/?period=week',651,artfolder + 'videos.png')
	addDir("Most Liked - This Month",'https://spankbang.com/top_rated/?period=month',651,artfolder + 'videos.png')
	addDir("Most Liked - Three Months",'https://spankbang.com/top_rated/?period=season',651,artfolder + 'videos.png')
	addDir("Most Liked - This Year",'https://spankbang.com/top_rated/?period=year',651,artfolder + 'videos.png')
	addDir("Most Liked - All Time",'https://spankbang.com/top_rated/?period=all',651,artfolder + 'videos.png')

	addDir("Longest videos",'https://spankbang.com/longest_videos/',651,artfolder + 'videos.png')

	addDir("Pornstars",'https://spankbang.com/pornstars',670,artfolder + 'videos.png')

	addDir("Search",'-',680,artfolder + 'search.png')
	xbmc.executebuiltin("Container.SetViewMode(200)")


# 651
##################################################################################################################################################################################################################
def ListVideos(url):

        print "ListVideos: " + url
        pageSource = OpenUrl(url)
        #pageSource = pageSource.replace("\r","")
        #pageSource = pageSource.replace("\n","")
        
        #videoblock = re.compile('<div class="video-item" data-id="\d+">\s<a href="(.+)" class=".+">\s<img src=".*" data-src="(.*)" alt="(.*)" class=".+ />\s<span class=".+"></span>\s<span class=".+">.+\s<span .+clock-o"></i>(.+)</span>').findall(pageSource)
        #videoblock = re.compile('<div class="video-item" data-id="\d+">\s<a href="(.+)" class=".+">\s<img src=".*" data-src="(.*)" alt="(.*)" class=".+ />\s<span class=".+"></span>\s(<span class="i-hd">.+</span>)*(\s)*<span class=".+"><i class="fa fa-clock-o"></i>(.+)</span>').findall(pageSource)
        #videoblock = re.compile('<div class="video-item" data-id="\d+">\s<a href="(.+)" class=".+">\s<img src=".*" data-src="(.*)" alt="(.*)" data-preview=".*" class=".+ />\s<p>\s<span class=".+">(.*)</span>\s(<span class=".+">(.*)</span>)?').findall(pageSource)
        #videoblock = re.compile('<div class="video-item v-i-\d+" data-id="\d+">\s<a href="(.+)" class=".+">\s<img src=".*" data-src="(.*)" alt="(.*)" data-preview=".*" class=".+" />\s<p>\s<span class="i-len">(.+)</span>').findall(pageSource)

        videoblock = re.compile('<div class="video-item " data-id="\d+">\s<a href="(.+)">\s<picture>\s<img src=".+" data-src="(.+)" alt=".+" data-preview=".+" \/>\s</picture>\s<p class=".+">\s<span class=".+">(.+)</span>\s<span class=".+">.+</span>\s<span class=".+">(.+)</span>').findall(pageSource)
        

        a = []
        for x in range(0, len(videoblock)):     
                url = videoblock[x][0]
                img = videoblock[x][1]
                title = videoblock[x][3]
                try:
                        duration = videoblock[x][2]
                except:
                        duration = ''
                if len(duration)>0:
                        title = "("+duration+" min) "+title
                title = title.replace("&#39;","'")
                title = title.replace("{IGGY}","")
                title = title.replace("<strong>","")
                title = title.replace("</strong>","")

                print img

                temp = [url,title,img];
                a.append(temp)

        print 'Total Videos: '+ str(len(videoblock))
        total=len(a)

        for url,title,img in a:
                if img[:2] == '//': img = 'http:' + img
                addDir(title,url,652,img,False,total,True)
                #context_menu.append('Download...', url)

        try:
                next_page = re.compile('<li class="active"><a>(\d+)</a></li><li><a href="(.+?)">').findall(pageSource)[0][1]
        except:
                next_page = ''

        next_page = root_url + next_page
        
        print 'Next Page: '+str(next_page)
        addDir(Translate(2050),next_page,651,artfolder + 'next.png')

        xbmc.executebuiltin('Container.SetViewMode(500)')
        
#                #https://spankbang.com/api/search/suggest?id=white
#                keyword?keyword=

url = "https://spankbang.com/keyword?keyword=white"
url = "https://spankbang.com/32/pornstar/angela+white"
url = "https://spankbang.com/category/big+tits/?order=trending"
#ListVideos(url)
# 562
##################################################################################################################################################################################################################
def FindVideoSources(name,url,iconimage):
        progressMessage.create('System', "Opening Video. Please Wait...","")
        progressMessage.update(0)
        print 'FindVideoSources: '+url

        video_url = GetVideoUrl(url)

        if video_url: play(name,video_url,iconimage)
        
# 660          
##################################################################################################################################################################################################################
def CategoriesMenu():
        addLink("[B][COLOR white]CATEGORIES[/COLOR][/B]",'','-')

        page = OpenUrl(root_url+"/categories")

        match = re.compile('<a href="(\/category.+)"><img src=".+"><span>(.+)</span></a>').findall(page)

        for url, title in match:
                #print url
                addDir(title,root_url+url,651,artfolder + 'videos.png')
                
        xbmc.executebuiltin("Container.SetViewMode(50)")
#CategoriesMenu()
# 670
##################################################################################################################################################################################################################
def ListPornstars(url):
        #url = "https://spankbang.com/pornstars"
        print "ListPornstars: "+url
        pageSource = OpenUrl(url)
        #print pageSource
        #match = re.compile('<a href="(.+)" class=".+">\s<img src="(.+)" title="(.+)" alt=".+" />\s<span class="views"><i class="fa fa-eye"></i>(.+)</span>\s<span class="videos"><i class="fa fa-video-camera"></i>(.+)</span>\s</a>').findall(pageSource)
        #match = re.compile('<a href="(.+)" class=".+">\s<img src=".+" data-src="(.+)" alt="(.+)" class="lazyload" />').findall(pageSource)
        match = re.compile('<a href="(.+)" class=".+">\s<img src="(.+)" title="(.+)" alt=".+" />\s<span class="views"><svg class=".+"><use xlink:href=".+"></use></svg>(.+)</span>\s<span class="videos"><svg class=".+"><use xlink:href=".+"></use></svg>(.+)</span>\s</a>').findall(pageSource)
        
        print 'Total: '+ str(len(match))

        for url, img, title, viewCount, videoCount in match:
        #for url, img, title, in match:
                url = root_url+url
                if img[:2] == '//': img = 'http:' + img
                title = title + ' ' + viewCount + ' views ' + videoCount + ' videos'
                #print title
                addDir(title,url,651,img)
        try:
                next_page = re.compile('<li class="active"><a>(\d+)</a></li><li><a href="(.+?)">').findall(pageSource)[0][1]
        except:
                next_page = ''


        next_page = root_url + next_page
        
        print 'Next Page: '+str(next_page)
        addDir(Translate(2050),next_page,670,artfolder + 'next.png')

        xbmc.executebuiltin("Container.SetViewMode(500)")

url = "https://spankbang.com/pornstars"
#ListPornstars(url)
# 680
##################################################################################################################################################################################################################
def Search():
        keyb = xbmc.Keyboard('', Translate(2022)+':')
        keyb.doModal()
        if (keyb.isConfirmed()):
                searchText = keyb.getText()
                searchParameter=urllib.quote(searchText)
                #url = root_url+'/s/' + str(searchParameter)
                url = root_url+"/keyword?keyword==" + str(searchParameter)
                ListVideos (url)


##################################################################################################################################################################################################################
def mode(mode,name,url,iconimage):
        if mode==601: MainMenu()
        elif mode==651: ListVideos(url)
        elif mode==652: FindVideoSources(name,url,iconimage)
        elif mode==680: Search()
        elif mode==605: download(name,url)
        elif mode==206: selfAddon.openSettings()
        elif mode==660: CategoriesMenu()
        elif mode==670: ListPornstars(url)
        
        
##################################################################################################################################################################################################################
def GetVideoUrl(url):
        #url = urllib.quote(url)
        print root_url+url
        html = OpenUrl(root_url+url)

        try:
                stream_url_480p = re.compile("var stream_url_480p  = '(.+)';").findall(html)[0]
        except:
                stream_url_480p = ''
        try:
                stream_url_720p = re.compile("var stream_url_720p  = '(.+)';").findall(html)[0]
        except:
                stream_url_720p = ''
        try:
                stream_url_1080p = re.compile("var stream_url_1080p  = '(.+)';").findall(html)[0]
        except:
                stream_url_1080p = ''
        try:
                stream_url_4k = re.compile('"contentUrl": "(.+)"').findall(html)[0]
        except:
                stream_url_4k = ''

        video_url = ''
        video_quality = "1"
        if video_quality == "1":
                video_url = ( stream_url_4k if stream_url_4k != '' else ( stream_url_1080p if stream_url_1080p != '' else ( stream_url_720p if stream_url_720p != '' else stream_url_480p ) ) )
        else:
                video_url = stream_url_480p
                        
                        
        print "stream_url_480p: " + stream_url_480p
        print "stream_url_720p: " + stream_url_720p
        print "stream_url_1080p: " + stream_url_1080p
        print "stream_url_4k: " + stream_url_4k

        #url_video = urllib.quote(video_url)
        video_url = video_url.replace("%3A",":")

        #video_url = "https://cdnthumb4.spankbang.com/0/5/0/5042243-t.mp4"

        print "GetVideoUrl: "+video_url
        return video_url
url = "/46ejn/video/detention+foursome"
#GetVideoUrl(url)
##################################################################################################################################################################################################################
def download(name,url):
        if down_path == '':
                dialog = xbmcgui.Dialog()
                dialog.ok("Download Folder Missing", "Please Select Download Folder")
                selfAddon.openSettings()
                return
        progressMessage.create('System', "Preparing Download. Please Wait...","")
        progressMessage.update(0)

        print "download page: "+url

        video_url = GetVideoUrl(url)

        fileName = re.compile('\/[^\/]+$').findall(video_url)[0]
        fileName = fileName.replace("/","")
        print "fileName: "+fileName
        
        mypath=os.path.join(down_path,fileName)
        print "mypath: "+mypath
        if os.path.isfile(mypath) is True:
                dialog = xbmcgui.Dialog()
                dialog.ok("file exists 1","file exists 2")
                return
        progressMessage.close()
        dp = xbmcgui.DialogProgress()
        dp.create('Download')
        start_time = time.time()                # url - url do ficheiro    mypath - localizacao ex: c:\file.mp3
        urllib.urlretrieve(video_url, mypath, lambda nb, bs, fs: dialogdown(nb, bs, fs, dp, start_time))
        try: urllib.urlretrieve(video_url, mypath, lambda nb, bs, fs: dialogdown(nb, bs, fs, dp, start_time))
        except:
                #dialog = xbmcgui.Dialog()
                #dialog.ok("Error Saving File", "Please Select A Different Download Folder And Try Again")
                while os.path.exists(mypath): 
                        try: os.remove(mypath); break 
                        except: pass
                dp.close()
                return
        dp.close()
        
##################################################################################################################################################################################################################
def dialogdown(numblocks, blocksize, filesize, dp, start_time):
      try:
            percent = min(numblocks * blocksize * 100 / filesize, 100)
            currently_downloaded = float(numblocks) * blocksize / (1024 * 1024) 
            kbps_speed = numblocks * blocksize / (time.time() - start_time) 
            if kbps_speed > 0: eta = (filesize - numblocks * blocksize) / kbps_speed 
            else: eta = 0 
            kbps_speed = kbps_speed / 1024 
            total = float(filesize) / (1024 * 1024) 
            mbs = '%.02f MB %s %.02f MB' % (currently_downloaded,Translate(2026), total) 
            e = ' (%.0f Kb/s) ' % kbps_speed 
            tempo = Translate(2027) + ' %02d:%02d' % divmod(eta, 60) 
            dp.update(percent, mbs + e,tempo)
      except: 
            percent = 100 
            dp.update(percent) 
      if dp.iscanceled(): 
            dp.close()
            raise StopDownloading('Stopped Downloading')

##################################################################################################################################################################################################################
class StopDownloading(Exception):
      def __init__(self, value): self.value = value 
      def __str__(self): return repr(self.value)


def addLink(name,url,iconimage):
        name = formatString(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', addonfolder + '/fanart.jpg')
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def play(name,streamurl,iconimage = "DefaultVideo.png"):
        listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        player = xbmc.Player()
        #streamurl = "https://lh3.googleusercontent.com/3VDqSJZi2gEINCTJV5fkPQhQ0jQ2L6vHrHfpXxL3EPE8CqJ7XNvmakAb40xnKIrv_A_9fsalD8qx=m37"
        player.play(streamurl,listitem)

