#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# 2014 - Anonymous

import urllib,urllib2,re,HTMLParser,os,sys,time
import mechanize
import hqqresolver

#---------------------------------------------------------------------------------------------------------------------
def abrir_url(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link
        
#---------------------------------------------------------------------------------------------------------------------
def find_match(regexp,src):
        return re.compile(regexp,flags=0).findall(src)
        

#---------------------------------------------------------------------------------------------------------------------
def listar_videos(url):
        codigo_fonte = abrir_url(url)
        codigo_fonte = codigo_fonte.replace("\n","")
        
        codigo_fonte_videos = find_match('<div class="td-header-wrap(.*?)<div class="td-footer-wrapper">',codigo_fonte)

        try:
                page = int(find_match('<span class="current">(.+?)</span>',codigo_fonte)[0])
        except: page = 1
        print "Page: " + str(page)

        a = []
        for m in codigo_fonte_videos:
                match = find_match('<div class="td-module-thumb"><a href="(http.+?)" rel="bookmark" title="(.+?)"><img width="\d+" height="\d+" itemprop="image" class="(.+?)" src="(.+?)" alt=',m)
                for x in range(0, len(match)):
                        temp = [match[x][0],match[x][1],match[x][3]];
                        if page > 1:
                                if x > 18: a.append(temp)
                        else:
                                if x > 13: a.append(temp)
                match = find_match('<div class="td-module-thumb"><a href="(http.+?)" rel="bookmark" title="(.+?)"><img width="\d+" height="\d+" itemprop="image" class="(.+?)" data="(.+?)" src="(.+?)" alt',m)
                print 'Total Videos: '+ str(len(match))
                for x in range(0, len(match)):
                        temp = [match[x][0],match[x][1],match[x][4]]; 
                        a.append(temp)
        total=len(a)
        for url,titulo,img in a:
                if img[:2] == '//': img = 'http:' + img
                print titulo + ' ' + url
                addDir(titulo,url,152,img,False,total,True)
        
        try:
                next_page = re.compile('<span class="current">(.+?)</span><a href="(http.+?)" class="page" title="(.+?)"').findall(codigo_fonte)
                url = next_page[len(next_page)-1][1]
                print 'Next Page: '+url
                addDir(traducao(2050),url,151,artfolder + 'next.png')
        except: pass

#---------------------------------------------------------------------------------------------------------------------
def ListVideos(url):
        codigo_fonte = abrir_url(url)
        codigo_fonte = codigo_fonte.replace("\n","")
        
        codigo_fonte_videos = find_match('<div class="td-header-wrap(.*?)<div class="td-footer-wrapper">',codigo_fonte)

        try:
                page = int(find_match('<span class="current">(.+?)</span>',codigo_fonte)[0])
        except: page = 1

        a = []
        for m in codigo_fonte_videos:
                match = find_match('<div class="td-module-thumb"><a href="(http.+?)" rel="bookmark" title="(.+?)"><img width="\d+" height="\d+" itemprop="image" class="(.+?)" data="(.+?)" src="(.+?)" alt',m)
                for x in range(0, len(match)):
                        temp = [match[x][0],match[x][1],match[x][4]]; 
                        a.append(temp)
        print 'Total Videos: '+ str(len(a))
        for url,titulo,img in a:
                if img[:2] == '//': img = 'http:' + img
                print titulo 
                #addDir(titulo,url,152,img,False,total,True)
        try:
                next_page = re.compile('<span class="current">(.+?)</span><a href="(http.+?)" class="page" title="(.+?)"').findall(codigo_fonte)
                url = next_page[len(next_page)-1][1]
                print 'Next: '+url
                addDir(traducao(2050),url,151,artfolder + 'next.png')
                #addDir("total "+len(a),url,151,artfolder + 'next.png')
        except: pass
        
        xbmc.executebuiltin("Container.SetViewMode(500)")


#---------------------------------------------------------------------------------------------------------------------
url = 'https://pornohub.su/porn/brazzers/baby-got-boobs/'
#listar_videos(url)
page1 = "https://pornohub.su/?s=white"
page2 = "https://pornohub.su/page/2/?s=white"
ListVideos(page2)
