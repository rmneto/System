#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# 2014 - Anonymous

import cookielib,urllib,urllib2,re,HTMLParser,os,sys,time
try:
        import xbmcgui,xbmc,xbmcaddon,xbmcplugin
        from resolvers import *
except:
        pass

root_url = 'https://en.rusporn.porn'

try:
        addon_id = 'plugin.video.system'
        selfAddon = xbmcaddon.Addon(id=addon_id)
        addonfolder = selfAddon.getAddonInfo('path')
        artfolder = addonfolder + '/resources/img/'
        down_path = selfAddon.getSetting('download-folder')
        video_quality = selfAddon.getSetting('kodion.video.quality')
        mensagemprogresso = xbmcgui.DialogProgress()
except:
        artfolder=""


def ListMode():
        try:
                xbmc.executebuiltin("Container.SetViewMode(50)")
        except:
                pass

def PreviewMode():
        try:
                xbmc.executebuiltin("Container.SetViewMode(500)")
        except:
                pass
        
def formatString(texto):
        texto = texto.replace("&#8211;","-")
        texto = texto.replace("&#8217;","'")
        texto = texto.replace("&#038;","&")
        texto = texto.replace("&amp;","&")
        return texto
        
def find_match(regexp,src):
        return re.compile(regexp,flags=0).findall(src)

def Translate(texto):
        return selfAddon.getLocalizedString(texto).encode('utf-8')

def OpenUrl(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        html=response.read()
        response.close()
        return html
                
def addLink(name,url,iconimage):
        try:
                name = formatString(name)
                ok=True
                liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
                liz.setProperty('fanart_image', addonfolder + '/fanart.jpg')
                liz.setInfo( type="Video", infoLabels={ "Title": name } )
                ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        except:
           print "Link: "+name+" ["+url+"]"
        return ok

def addDir(name,url,mode,iconimage,pasta = True,total=1,video=False):
        try:
                name = formatString(name)
                u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
                ok=True
                liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
                liz.setProperty('fanart_image', addonfolder + '/fanart.jpg')
                cm =[]
                if video: 
                        cm.append(('Download', 'XBMC.RunPlugin(%s?mode=505&url=%s&name=%s)' % (sys.argv[0], urllib.quote_plus(url),name)))
                        liz.addContextMenuItems(cm, replaceItems=True) 
                ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=pasta,totalItems=total)
                return ok
        except:
           print "Folder: "+name+" ["+url+"]"

def play(name,streamurl,iconimage = "DefaultVideo.png"):
        listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        player = xbmc.Player()
        #streamurl = "https://lh3.googleusercontent.com/3VDqSJZi2gEINCTJV5fkPQhQ0jQ2L6vHrHfpXxL3EPE8CqJ7XNvmakAb40xnKIrv_A_9fsalD8qx=m37"
        player.play(streamurl,listitem)



# 501
##################################################################################################################################################################################################################
def MainMenu():
	addDir("All Videos",'https://en.rusporn.porn/',751,artfolder + 'videos.png')
	addDir("Categories",'-',760,artfolder + 'videos.png')
	addDir("Popular",'https://en.rusporn.porn/most-popular/',751,artfolder + 'videos.png')
	addDir("Best",'https://en.rusporn.porn/the-best/',751,artfolder + 'videos.png')
	addDir("Pornstars",'https://en.rusporn.porn/models/',770,artfolder + 'videos.png')
	addDir("Search",'-',780,artfolder + 'search.png')
	xbmc.executebuiltin("Container.SetViewMode(200)")


# 551
##################################################################################################################################################################################################################
def ListVideos(url):
        print "ListVideos: " + url
        
        page = OpenUrl(url)
        page = page.replace("\r\n","")
        
        videoblocks = re.compile('<div class="preview-images">(.+?)</div>\s+</div>\s+</div>').findall(page)

        a=[]
        for block in videoblocks:
                match = re.compile('<a href="(.+?)">\s*<img src="(.+?)" alt="(.+?)"').findall(block)
                for url,img,title in match:
                        duration = re.compile('<div class="duration">(.+?)</div>').findall(block)[0]
                        likes = re.compile('<div class="likes">(.+?)</div>').findall(block)[0]
                        views = re.compile('<div class="views">(.+?)</div>').findall(block)[0]
                        temp = [url,title,img,str(duration),str(likes),str(views)];
                        a.append(temp)
                
        total=len(a)
        print 'Total Videos: '+ str(total)

        for url,title,img,duration,rating,views in a:
                if img[:2] == '//': img = 'http:' + img
                title = '(' + duration + ' - ' + rating + ' - ' + views + ') ' + title
                #print img
                url = url + "?videoformat=4"
                addDir(title,url,752,img,False,total,True)
                #context_menu.append('Download...', url)
        try:
                next_page = re.compile('<a href="(.+?)">Next&raquo;<\/a>').findall(page)[0]
        except:
                next_page=""


        #next_page = re.compile('<a href="(.+?)">Next&raquo;<\/a>').findall(pageSource)[0]
        #next_page = url.replace(root_url,'')
        #next_page = urllib.quote(next_page)
        #next_page = root_url+next_page

        print 'Next Page: '+str(next_page)
        if next_page!="":
                addDir(Translate(2050),next_page,751,artfolder + 'next.png')

        
        PreviewMode()

url = "https://en.rusporn.porn/tolstushki/"
url = "https://en.rusporn.porn/"
#ListVideos(url)
# 552
##################################################################################################################################################################################################################
def FindVideoSources(name,url,iconimage):
        mensagemprogresso.create('System', "Opening Video. Please Wait...","")
        mensagemprogresso.update(0)
        print 'FindVideoSources: '+url

        video_url = GetVideoUrl(url)

        if video_url: play(name,video_url,iconimage)
        
# 560          
##################################################################################################################################################################################################################
def CategoriesMenu():
        addLink("[B][COLOR white]CATEGORIES[/COLOR][/B]",'','-')

        page = OpenUrl(root_url)
        page = page.replace("\n","")

        categories = re.compile('<div id="leftcategories">(.+?)<\/div>').findall(page)[0]
        print len(categories)
        
        match = re.compile('<a href="(.+?)">(.+?)</a>').findall(categories)
        for url, title in match:
                print title+": "+url
                addDir(title,url,751,artfolder + 'videos.png')
                
        ListMode()

#CategoriesMenu()
# 570
##################################################################################################################################################################################################################
def ListPornstars(url):

        page = OpenUrl(url)
        page = page.replace("\n","")

        videoblocks = re.compile('<div class="preview-images">(.+?)</div>\s+</div>\s+</div>').findall(page)

        a=[]
        for block in videoblocks:
                match = re.compile('<a href="(.+?)">\s*<img src="(.+?)" alt="(.+?) - (.+?)"').findall(block)
                for url,img,title_ru,title_en in match:
                        temp = [root_url+url,img,title_en];
                        a.append(temp)
                
        total=len(a)
        print 'Total Videos: '+ str(total)

        for url, img, title in a:
                #print url
                addDir(title,url,751,img)

        try:
                next_page = re.compile('<a href="(.+?)">Next&raquo;<\/a>').findall(page)
                print "NextPage: "+str(len(next_page[0]))
                addDir(Translate(2050),next_page,770,artfolder + 'next.png')
        except:
                pass

        PreviewMode()

#ListPornstars("https://en.rusporn.porn/models/")
# 580
##################################################################################################################################################################################################################
def Search():
        keyb = xbmc.Keyboard('', Translate(2022)+':')
        keyb.doModal()
        if (keyb.isConfirmed()):
                searchText = keyb.getText()
                searchParameter=urllib.quote(searchText)
                url = 'https://en.rusporn.porn/search/?text=' + str(searchParameter)

                ListVideos (url)


##################################################################################################################################################################################################################
def mode(mode,name,url,iconimage):
        if mode==701: MainMenu()
        elif mode==751: ListVideos(url)
        elif mode==752: FindVideoSources(name,url,iconimage)
        elif mode==780: Search()
        elif mode==705: download(name,url)
        elif mode==706: selfAddon.openSettings()
        elif mode==760: CategoriesMenu()
        elif mode==770: ListPornstars(url)
        
        
##################################################################################################################################################################################################################
def GetVideoUrl(url):
        html = OpenUrl(url)
        try: 
                video_url = re.compile('file:"(.+?mp4)"').findall(html)[0]
        except: return
        print video_url


        #url_video = urllib.quote(video_url)
        video_url = video_url.replace("%3A",":")

        if video_quality == "1":
                video_url = video_url.replace("480p","720p")

        print "GetVideoUrl: "+video_url
        return video_url
url = "https://en.rusporn.porn/video/hudenkaya-krasotka-soglasilas-na-domashniy-anal-krupnym-planom.html"
url = "https://en.rusporn.porn/video/grudastaya-milfa-bryunetka-zamutila-seks-s-ghigolo-v-tualete-kafe-za-babki.html"
url = "https://en.rusporn.porn/video/tresnuli-skrepy-ili-ihnyaya-vecherinka-na-hellouin.html"
url = "https://en.rusporn.porn/video/milfa-s-tatuhoy-otsosala-sosedu-pod-dushem-i-trahnulasy-na-krovati.html"

#https://v2.cdnde.com/x2//upload_f448011d61e216526c5b87d99a35a4e4/18748/JOPORN_NET_18748_720p.mp4
#https://v2.cdnde.com/x2//upload_9c066484ce27ec302125a2c4858d4d29/18748/JOPORN_NET_18748_720p.mp4

video_quality = "1"
#GetVideoUrl(url)
##################################################################################################################################################################################################################
def download(name,url):
        if down_path == '':
                dialog = xbmcgui.Dialog()
                dialog.ok("Download Folder Missing", "Please Select Download Folder")
                selfAddon.openSettings()
                return
        mensagemprogresso.create('System', "Preparing Download. Please Wait...","")
        mensagemprogresso.update(0)

        print "download page: "+url

        video_url = GetVideoUrl(url)

        fileName = re.compile('\/[^\/]+$').findall(video_url)[0]
        fileName = fileName.replace("/","")
        print "fileName: "+fileName
        
        mypath=os.path.join(down_path,fileName)
        print "mypath: "+mypath
        if os.path.isfile(mypath) is True:
                dialog = xbmcgui.Dialog()
                dialog.ok("file exists 1","file exists 2")
                return
        mensagemprogresso.close()
        dp = xbmcgui.DialogProgress()
        dp.create('Download')
        start_time = time.time()                # url - url do ficheiro    mypath - localizacao ex: c:\file.mp3
        try: urllib.urlretrieve(video_url, mypath, lambda nb, bs, fs: dialogdown(nb, bs, fs, dp, start_time))
        except:
                #dialog = xbmcgui.Dialog()
                #dialog.ok("Error Saving File", "Please Select A Different Download Folder And Try Again")
                while os.path.exists(mypath): 
                        try: os.remove(mypath); break 
                        except: pass
                dp.close()
                return
        dp.close()
        
##################################################################################################################################################################################################################
def dialogdown(numblocks, blocksize, filesize, dp, start_time):
      try:
            percent = min(numblocks * blocksize * 100 / filesize, 100)
            currently_downloaded = float(numblocks) * blocksize / (1024 * 1024) 
            kbps_speed = numblocks * blocksize / (time.time() - start_time) 
            if kbps_speed > 0: eta = (filesize - numblocks * blocksize) / kbps_speed 
            else: eta = 0 
            kbps_speed = kbps_speed / 1024 
            total = float(filesize) / (1024 * 1024) 
            mbs = '%.02f MB %s %.02f MB' % (currently_downloaded,Translate(2026), total) 
            e = ' (%.0f Kb/s) ' % kbps_speed 
            tempo = Translate(2027) + ' %02d:%02d' % divmod(eta, 60) 
            dp.update(percent, mbs + e,tempo)
      except: 
            percent = 100 
            dp.update(percent) 
      if dp.iscanceled(): 
            dp.close()
            raise StopDownloading('Stopped Downloading')

##################################################################################################################################################################################################################
class StopDownloading(Exception):
      def __init__(self, value): self.value = value 
      def __str__(self): return repr(self.value)


