from urllib.request import urlopen, Request
from urllib.parse import urlencode, quote_plus
import urllib
import re,os,sys
import common
import spankbang, hdporno, rusporn, okxxx
import xbmcplugin,xbmcgui,xbmc,xbmcaddon,xbmcvfs,time

addon_id = 'plugin.video.system'
selfAddon = xbmcaddon.Addon(id=addon_id)
addonfolder = selfAddon.getAddonInfo('path')
artfolder = addonfolder + '/resources/img/'
pastaperfil = xbmcvfs.translatePath(selfAddon.getAddonInfo('profile'))#.decode('utf-8')
if xbmc.getCondVisibility('system.platform.windows'): pastaperfil = pastaperfil.replace('\\','/')
mensagemprogresso = xbmcgui.DialogProgress()


#-----------------------------------------------------------------------------------------------
def MainMenu():
	common.addFolderItem("ok.xxx",'-',okxxx.mode.MainMenu.value)
	common.addFolderItem("SpankBang",'-',spankbang.mode.MainMenu.value)
	common.addFolderItem("RusPorn",'-',rusporn.mode.MainMenu.value)
	common.addFolderItem("xHDPorno",'-',hdporno.mode.MainMenu.value)
	password()

	xbmcplugin.endOfDirectory(common._HANDLE)
	xbmc.executebuiltin("Container.SetViewMode(500)")

#-----------------------------------------------------------------------------------------------
def first_run():
	print ("first_run")
	if not xbmcvfs.exists(pastaperfil): xbmcvfs.mkdir(pastaperfil)
	if not os.path.exists(os.path.join(pastaperfil,"passwd.txt")):
		savefile("passwd.txt","<flag='false'>")
	
#-----------------------------------------------------------------------------------------------
def password():
        if pass_status() == False: common.addPasswordItem("Enable Password",'-',100)
        else: common.addPasswordItem("Disable Password",'-',100)
	
#-----------------------------------------------------------------------------------------------
def pass_status():
	try:
		if re.compile("flag='(.+?)'").findall(openfile("passwd.txt"))[0] == "true": return True
	except: return True
	return False

#-----------------------------------------------------------------------------------------------
def check_pass():
	print ("check_pass")
	if pass_status() == False: return
	try: check = re.compile("password='(.+?)'").findall(openfile("passwd.txt"))[0]
	except: sys.exit(0)
	keyb = xbmc.Keyboard('', "Enter the current password:") 
	keyb.setHiddenInput(True)
	keyb.doModal()
	if (keyb.isConfirmed()): password = keyb.getText()
	else: sys.exit(0)
	if password != check:
		xbmcgui.Dialog().ok("Error:", "Wrong Password!")
		sys.exit(0)
	
#-----------------------------------------------------------------------------------------------
def change_pass_status():
	if pass_status() == False:
		keyb = xbmc.Keyboard('', "Enter the desired password:") 
		keyb.setHiddenInput(True)
		keyb.doModal()
		if (keyb.isConfirmed()): password = keyb.getText()
		else: return
		if password == '' or "'" in password:
			xbmcgui.Dialog().ok("Error", "Enter a valid password!")
			return
		savefile("passwd.txt","<flag='true' password='%s'>" % password)
	else: 
		check = re.compile("password='(.+?)'").findall(openfile("passwd.txt"))[0]
		keyb = xbmc.Keyboard('', "Enter the current password:") 
		keyb.setHiddenInput(True)
		keyb.doModal()
		if (keyb.isConfirmed()): password = keyb.getText()
		else: return
		if password == '':
			xbmcgui.Dialog().ok("Error:", "Enter a valid password!")
			return
		if password == check: savefile("passwd.txt","<flag='false'>")
		else: xbmcgui.Dialog().ok("Error:", "Wrong password!")	
	xbmc.executebuiltin("Container.Refresh")
	
#-----------------------------------------------------------------------------------------------
def savefile(filename, contents,pastafinal=pastaperfil):
	print ("savefile")
	destination = os.path.join(pastafinal,filename)
	print ("destination: "+pastaperfil)
	try:
		fh = open(destination, 'w')
		fh.write(contents)  
		fh.close()
	except: print ("error in savefile")

#-----------------------------------------------------------------------------------------------
def openfile(filename,pastafinal=pastaperfil):
	#try:
		destination = os.path.join(pastafinal, filename)
		print ("openfile:"+destination)
		fh = open(destination, 'r')
		print ("fh")
		contents=fh.read()
		print ("contents:"+contents)
		fh.close()
		return contents
	#except:
	#	print ("Falhou a abrir txt")
	#	return None

#-----------------------------------------------------------------------------------------------
#                                          getParams
#-----------------------------------------------------------------------------------------------
def getParams():
	param=[]
	
	if (len(sys.argv)>=2):
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
			params=sys.argv[2]
			cleanedparams=params.replace('?','')
			if (params[len(params)-1]=='/'):
				params=params[0:len(params)-2]
			pairsofparams=cleanedparams.split('&')
			param={}
			for i in range(len(pairsofparams)):
				splitparams={}
				splitparams=pairsofparams[i].split('=')
				if (len(splitparams))==2:
					param[splitparams[0]]=splitparams[1] 
	return param

params=getParams()
url=None
name=None
mode=None
iconimage=None

try: url=urllib.parse.unquote_plus(params["url"])
except: pass
try: name=urllib.parse.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass
try: iconimage=urllib.parse.unquote_plus(params["iconimage"])
except: pass

print ("Mode: "+str(mode))
print ("URL: "+str(url))
print ("Name: "+str(name))
print ("Iconimage: "+str(iconimage))

#-----------------------------------------------------------------------------------------------
#                                          SetModes                                                 
#-----------------------------------------------------------------------------------------------
if mode==None or url==None or len(url)<1: 
	first_run()
	check_pass()
	MainMenu()
	mode == 1
elif mode==0: MainMenu()
elif mode==22: 
	selfAddon.openSettings()
	xbmcgui.Dialog().ok("Advice!", "Restart the addon for the changes to take effect.")
elif mode==100: change_pass_status()
#xHDPorno
elif mode>=hdporno.mode.Min.value and mode <= hdporno.mode.Max.value:
	hdporno.setMode(mode,name,url,iconimage)
#SpankBang
elif mode>=spankbang.mode.Min.value and mode <= spankbang.mode.Max.value:
	spankbang.setMode(mode,name,url,iconimage)
#RusPorn
elif mode>=rusporn.mode.Min.value and mode <= rusporn.mode.Max.value:
	rusporn.setMode(mode,name,url,iconimage)
#ok.xxx
elif mode>=okxxx.mode.Min.value and mode <= okxxx.mode.Max.value:
	okxxx.setMode(mode,name,url,iconimage)	