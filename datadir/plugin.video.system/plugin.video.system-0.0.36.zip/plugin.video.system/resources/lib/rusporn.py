import re
import common
import xbmcgui,xbmc,xbmcaddon,xbmcplugin
from enum import Enum

root_url = 'https://en.rusporn.porn'
#-----------------------------------------------------------------------------------------------
class mode(Enum):
        Min = 700
        MainMenu = 701
        ListVideos = 702
        FindVideoSources = 703
        Search = 704
        CategoriesMenu = 705
        ListPornstars = 706
        Max = 799

#-----------------------------------------------------------------------------------------------
def setMode(newMode,name,url,iconimage):
        if newMode==mode.MainMenu.value: MainMenu()
        elif newMode==mode.ListVideos.value: ListVideos(url)
        elif newMode==mode.FindVideoSources.value: FindVideoSources(name,url,iconimage)
        elif newMode==mode.Search.value: Search()
        #elif newMode==705: download(name,url)
        elif newMode==mode.CategoriesMenu.value: CategoriesMenu()
        elif newMode==mode.ListPornstars.value: ListPornstars(url)
        
#-----------------------------------------------------------------------------------------------
# 501
#-----------------------------------------------------------------------------------------------
def MainMenu():
        common.addFolderItem("All Videos",root_url,mode.ListVideos.value)
        common.addFolderItem("Categories",'-',mode.CategoriesMenu.value)
        common.addFolderItem("Popular",root_url+'/most-popular/',mode.ListVideos.value)
        common.addFolderItem("Best",root_url+'/the-best/',mode.ListVideos.value)
        common.addFolderItem("Pornstars",root_url+'/models/',mode.ListPornstars.value)
        common.addSearchItem("Search",'-',mode.Search.value)
        common.EndOfDirectoryListMode()

#-----------------------------------------------------------------------------------------------
# 551
#-----------------------------------------------------------------------------------------------
def ListVideos(url):
        print ("ListVideos: " + url)
        page = common.OpenUrl(url)
        page = page.replace("\r\n","")
        
        videoblocks = re.compile(r'<div class="preview-images">(.+?)</div>\s+</div>\s+</div>').findall(page)

        a=[]
        for block in videoblocks:
                match = re.compile(r'<a href="(.+?)">\s*<img src="(.+?)" width=".+" height=".+" alt="(.+?)"').findall(block)
                for url,img,title in match:
                        duration = re.compile(r'<div class="duration">(.+?)</div>').findall(block)[0]
                        likes = re.compile(r'<div class="likes">(.+?)</div>').findall(block)[0]
                        views = re.compile(r'<div class="views">(.+?)</div>').findall(block)[0]
                        temp = [url,title,img,str(duration),str(likes),str(views)];
                        a.append(temp)
                
        total=len(a)
        print ("total: "+str(total))
        for url,title,img,duration,rating,views in a:
                if img[:2] == '//': img = 'http:' + img
                title = '(' + duration + ' - ' + rating + ' - ' + views + ') ' + title
                #url = url + "?videoformat=4"
                #print (url)
                common.addVideoItem(title,url,mode.FindVideoSources.value,img)
                #context_menu.append('Download...', url)
        try:
                next_page = re.compile(r'<a href="(.+?)">Next&raquo;<\/a>').findall(page)[0]
        except:
                next_page=""

        print ("Next Page: "+str(next_page))
        if len(next_page) > 0:
                common.addNextItem("Next",next_page,mode.ListVideos.value)
        common.EndOfDirectoryPreviewMode()
#ListVideos('https://en.rusporn.porn/bolshiye-doyki/')
#-----------------------------------------------------------------------------------------------
# 552
#-----------------------------------------------------------------------------------------------
def FindVideoSources(name,url,iconimage):
        video_url = GetVideoUrl(url)
        if video_url: common.PlayVideo(name,video_url,iconimage)

#-----------------------------------------------------------------------------------------------
# 560          
#-----------------------------------------------------------------------------------------------
def CategoriesMenu():
        common.addLinkItem("[B][COLOR white]CATEGORIES[/COLOR][/B]",'','-')

        page = common.OpenUrl(root_url)
        page = page.replace("\n","")

        categories = re.compile(r'<div id="leftcategories">(.+?)<\/div>').findall(page)[0]
        match = re.compile(r'<a href="(.+?)">(.+?)</a>').findall(categories)
        for url, title in match:
                common.addVideosItem(title,url,mode.ListVideos.value)
                
        common.EndOfDirectoryListMode()

#-----------------------------------------------------------------------------------------------
# 570
#-----------------------------------------------------------------------------------------------
def ListPornstars(url):

        page = common.OpenUrl(url)
        page = page.replace("\n","")

        videoblocks = re.compile(r'<div class="preview-images">(.+?)</div>\s+</div>\s+</div>').findall(page)

        a=[]
        for block in videoblocks:
                match = re.compile(r'<a href="(.+?)">\s*<img src="(.+?)" alt="(.+?) - (.+?)"').findall(block)
                for url,img,title_ru,title_en in match:
                        temp = [root_url+url,img,title_en];
                        a.append(temp)
                
        total=len(a)

        for url, img, title in a:
                print (url)
                common.addVideosItemWithImg(title,url,mode.ListVideos.value,img)

        try:
                next_page = re.compile(r'<a href="(.+?)">Next&raquo;<\/a>').findall(page)
                common.addNextItem("Next",next_page,mode.ListPornstars.value)
        except:
                pass

        common.EndOfDirectoryPreviewMode()

#-----------------------------------------------------------------------------------------------
# 580
#-----------------------------------------------------------------------------------------------
def Search():
        keyb = xbmc.Keyboard('', "Enter Keyword:")
        keyb.doModal()
        if (keyb.isConfirmed()):
                searchText = keyb.getText()
                searchParameter=common.quote_plus(searchText)
                url = root_url+'/search?text=' + str(searchParameter)
                ListVideos (url)

#-----------------------------------------------------------------------------------------------
def GetVideoUrl(url):
        html = common.OpenUrl(url)
        video_url = ""

        try:
                url_1080p = re.compile(r'\[1080\] (\S+mp4)').findall(html)[0]
        except:
                url_1080p = ""

        try:
                url_720p = re.compile(r'\[720p\] (\S+mp4)').findall(html)[0]
        except:
                url_720p = ""

        try:
                url_480p = re.compile(r'\[480p\] (\S+mp4)').findall(html)[0]
        except:
                url_480p = ""
                
        print ("url_1080p: "+ str(url_1080p))
        print ("url_720p: "+ str(url_720p))
        print ("url_480p: "+ str(url_480p))

        video_url = ( url_1080p if url_1080p != '' else ( url_720p if url_720p != '' else ( url_480p ) ) )

        print ("video_url: "+ str(video_url))

        return video_url
#GetVideoUrl('https://en.rusporn.porn/movie/paren-s-devushkoy-ustroili-strastnyy-seks-v-vannoy-komnate')
#-----------------------------------------------------------------------------------------------
