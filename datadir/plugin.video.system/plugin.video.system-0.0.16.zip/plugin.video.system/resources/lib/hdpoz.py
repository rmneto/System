#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# 2014 - Anonymous

import xbmcgui,xbmc,xbmcaddon,xbmcplugin
import urllib,urllib2,re,HTMLParser,os,sys,time
import hqqresolver
from resolvers import *

addon_id = 'plugin.video.system'
selfAddon = xbmcaddon.Addon(id=addon_id)
addonfolder = selfAddon.getAddonInfo('path')
artfolder = addonfolder + '/resources/img/'
down_path = selfAddon.getSetting('download-folder')
mensagemprogresso = xbmcgui.DialogProgress()

def formatString(texto):
        texto = texto.replace("&#8211;","-")
        texto = texto.replace("&#8216;","'")
        texto = texto.replace("&#8217;","'")
        texto = texto.replace("&#038;","&")
        texto = texto.replace("&amp;","&")
        return texto
        

def traducao(texto):
        return selfAddon.getLocalizedString(texto).encode('utf-8')

def mainmenu():
        addDir("Bangbros",'http://hdpoz.com/HDtag/bangbros/',310, artfolder + 'videos.png')
        addDir("Big Tits",'http://hdpoz.com/HDtag/big/',310, artfolder + 'videos.png')
        addDir("Brazzers",'http://hdpoz.com/HDtag/brazzers/',310, artfolder + 'videos.png')
        addDir("DDF",'http://hdpoz.com/HDtag/ddf/',310, artfolder + 'videos.png')
        addDir("Full HD",'http://hdpoz.com/HDtag/fullhd/',310, artfolder + 'videos.png')
        addDir("FTV Girls HD",'http://hdpoz.com/HDtag/ftvgirls/',310, artfolder + 'videos.png')
        addDir("Kink",'http://hdpoz.com/HDtag/kink/',310, artfolder + 'videos.png')
        addDir("MILF",'http://hdpoz.com/HDtag/milf/',310, artfolder + 'videos.png')
        addDir("Playboy Plus",'http://hdpoz.com/HDtag/playboyplus/',310, artfolder + 'videos.png')
        addDir("Naughty America",'http://hdpoz.com/HDtag/naughtyamerica/',310, artfolder + 'videos.png')
	addDir("Search",'-',305,artfolder + 'search.png')

	xbmc.executebuiltin("Container.SetViewMode(50)")

#############################################################################################################################
def mode(mode,name,url,iconimage):
        if mode==301: mainmenu()
        elif mode==305: pesquisa()
        elif mode==310: listar_videos(url)
        elif mode==311: encontrar_fontes(name,url,iconimage)
        
        
def download(name,url):
        if down_path == '':
                dialog = xbmcgui.Dialog()
                dialog.ok(traducao(2010), traducao(2024))
                selfAddon.openSettings()
                return
        #mensagemprogresso.create('Adults TV', traducao(2008),traducao(2009))
        #mensagemprogresso.update(0)
        
        try: video_url = re.compile('<iframe src="(.+?)"').findall(abrir_url(url))[0]
        except: return
        if re.search('urlvk=',video_url): video_url = urllib.unquote(video_url.split('urlvk=')[1])
        if video_url[:2] == '//': video_url = 'http:' + video_url
        url_video = vkcom_resolver(video_url)
        
        name = re.sub('[^-a-zA-Z0-9_.()\\\/ ]+', '',name)
        name += ' - ' + url_video[1] + '.mp4'
        mypath=os.path.join(down_path,name)
        if os.path.isfile(mypath) is True:
                dialog = xbmcgui.Dialog()
                dialog.ok(traducao(2010),traducao(2025))
                return
        #mensagemprogresso.close()
        dp = xbmcgui.DialogProgress()
        dp.create('Download')
        start_time = time.time()                # url - url do ficheiro    mypath - localizacao ex: c:\file.mp3
        try: urllib.urlretrieve(url, mypath, lambda nb, bs, fs: dialogdown(nb, bs, fs, dp, start_time))
        except:
                while os.path.exists(mypath): 
                        try: os.remove(mypath); break 
                        except: pass
                dp.close()
                return
        dp.close()
        
def dialogdown(numblocks, blocksize, filesize, dp, start_time):
      try:
            percent = min(numblocks * blocksize * 100 / filesize, 100)
            currently_downloaded = float(numblocks) * blocksize / (1024 * 1024) 
            kbps_speed = numblocks * blocksize / (time.time() - start_time) 
            if kbps_speed > 0: eta = (filesize - numblocks * blocksize) / kbps_speed 
            else: eta = 0 
            kbps_speed = kbps_speed / 1024 
            total = float(filesize) / (1024 * 1024) 
            mbs = '%.02f MB %s %.02f MB' % (currently_downloaded,traducao(2026), total) 
            e = ' (%.0f Kb/s) ' % kbps_speed 
            tempo = traducao(2027) + ' %02d:%02d' % divmod(eta, 60) 
            dp.update(percent, mbs + e,tempo)
      except: 
            percent = 100 
            dp.update(percent) 
      if dp.iscanceled(): 
            dp.close()
            raise StopDownloading('Stopped Downloading')

class StopDownloading(Exception):
      def __init__(self, value): self.value = value 
      def __str__(self): return repr(self.value)
          
def listar_videos(url):
        codigo_fonte = abrir_url(url)
        codigo_fonte = codigo_fonte.replace("\n","")
        
        all_clips = re.compile('<div class="thumb">(.+?)</div>',flags=0).findall(codigo_fonte)

        total = len(all_clips)

        for clip in all_clips:
                match = re.compile('<a class="clip-link" data-id="(.+?)" title="(.+?)" href="(.+?)"',flags=0).findall(clip)[0]
                url = match[2]
                title = urllib.unquote(match[1])
                
                match = re.compile('<img src="(.+?)"',flags=0).findall(clip)[0]
                image = match

                addDir(title,url,311,image,False,total,True)

        xbmc.executebuiltin("Container.SetViewMode(500)")

        try:
                next_page = re.compile("<div class='wp-pagenavi'>(.+?)</div>").findall(codigo_fonte)
                current = re.compile("<span class='current'>(.+?)</span>").findall(next_page[0])
                next_url = re.compile('<a class="page larger" href="(.+?)">(.+?)</a>').findall(next_page[0])
                print next_url[0][0]
                addDir(traducao(2050),next_url[0][0],310,artfolder + 'next.png')
        except: pass


        
def encontrar_fontes(name,url,iconimage):
        codigo_fonte = abrir_url(url)
        codigo_fonte = codigo_fonte.replace("\n","")

        video_wrapper = re.compile('<div class="screen fluid-width-video-wrapper">(.+?)</script>').findall(codigo_fonte)
        playlist_url = re.compile('playlist: \'(.+?)\'').findall(codigo_fonte)[0]
        playlist = abrir_url(playlist_url)

        jwplayer_url = re.compile('<jwplayer:source file="(.+?)" type="mp4" label="(.+?)" default="true"/>').findall(playlist)[0]
        print jwplayer_url
        
        url_video = jwplayer_url[0]

        if url_video: play(name,url_video,iconimage)

def listar_categories():
        codigo_fonte = abrir_url('http://brazzershd.net/category/brazzers-hd/?orderby=date')
        codigo_fonte = codigo_fonte.replace("\n","")
        
        match = re.compile('<li id="menu-item(.+?)" class="menu-item(.+?)"><a href="(.+?)">(.+?)</a></li>',flags=0).findall(codigo_fonte)

        a = []
        for x in range(0, len(match)):
                temp = [match[x][2],match[x][3]];
                if len(match[x][2]) > 5: a.append(temp)
        total=len(a)
        for url,titulo in a:
                addDir(titulo,url,210,artfolder + 'videos.png')
                print titulo
        
def play(name,streamurl,iconimage = "DefaultVideo.png"):
        listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        player = xbmc.Player()
        player.play(streamurl,listitem)
        
def pesquisa():
        keyb = xbmc.Keyboard('', traducao(2022)+':')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText()
                parametro_pesquisa=urllib.quote(search)
                url = 'http://hdpoz.com/?s=' + str(parametro_pesquisa)
                listar_videos(url)

def abrir_url(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link
                
def addLink(name,url,iconimage):
        name = formatString(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', addonfolder + '/fanart.jpg')
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok

def addDir(name,url,mode,iconimage,pasta = True,total=1,video=False):
        name = formatString(name)
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', addonfolder + '/fanart.jpg')
        cm =[]
        if video: 
                cm.append(('Download', 'XBMC.RunPlugin(%s?mode=205&url=%s&name=%s)' % (sys.argv[0], urllib.quote_plus(url),name)))
                liz.addContextMenuItems(cm, replaceItems=True) 
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=pasta,totalItems=total)
        return ok
