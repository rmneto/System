import re
import common
from enum import Enum
from common import ListMenu, PreviewMenu, ListItem,  NextPageItem, regexp
#-----------------------------------------------------------------------------------------------
class modes(Enum):
    Min = 110
    MainMenu = 111
    VideosMenu = 112
    TagsMenu = 113
    PornstarsMenu = 114
    ChannelsMenu = 115
    PlayVideo = 116
    Search = 117
    Max = 120

#-----------------------------------------------------------------------------------------------
class urls(Enum):
    rootUrl = 'https://freshporno.net'
    allVideos = rootUrl
    tags = rootUrl+'/tags/'
    pornstars = rootUrl+'/models/'
    channels = rootUrl+'/channels/'
    search = rootUrl+'/search/{text}/'
    singleVideo = rootUrl+'/videos/lusting-for-a-fucking/'

#-----------------------------------------------------------------------------------------------
def GetMainMenu():
    menu = ListMenu(title = "FreshPorno")
    menu.items = [ 
        ListItem(title="All Videos", url=urls.allVideos.value,mode=modes.VideosMenu.value),
        ListItem(title="Pornstars", url=urls.pornstars.value,mode=modes.PornstarsMenu.value),
        ListItem(title="Channels", url=urls.channels.value,mode=modes.ChannelsMenu.value),
        ListItem(title="Tags", url=urls.tags.value,mode=modes.TagsMenu.value),
        ListItem(title="Search", url=urls.search.value,mode=modes.Search.value)
    ]
    return menu

#-----------------------------------------------------------------------------------------------
def ProcessRequest(mode:modes, name, url, iconimage):
    print ("ProcessRequest: "+str(mode)+" - "+name+" - "+url)
    menu = None

    if mode == modes.PlayVideo.value:
        PlayVideo(name,url,iconimage)
    else: 
        match mode:
            case modes.MainMenu.value: menu = GetMainMenu()
            case modes.VideosMenu.value: menu = GetVideosMenu(url)
            case modes.PornstarsMenu.value: menu = GetPornstarsMenu(url)
            case modes.ChannelsMenu.value: menu = GetChannelsMenu(url)
            case modes.TagsMenu.value: menu = GetTagsMenu(url)
            case modes.Search.value: menu = GetSearchMenu(url)

    return menu

#-----------------------------------------------------------------------------------------------
def GetVideosMenu(url):
    print ("GetVideosMenu: " + url)
    menu = PreviewMenu(rootUrl=urls.rootUrl)
    html = common.OpenUrl(url)
    
    match = regexp.findAll(html,r'<div class="page-content item">\s+.*\s*<a href="(.+)" title="(.+)" >(?:\s*.+){2} data-original="(.+)" data-webp')

    for url,title,img in match:
        menu.AddItem(title=title, url=url, img=img, mode=modes.PlayVideo.value)        
    
    nextPageUrl = regexp.findAny(html,r'<li class="pagination-next"><a href="(.+)"  data-')
    menu.SetNextPageItem(url=nextPageUrl, mode=modes.VideosMenu.value)

    return menu

#GetVideosMenu (urls.allVideos.value)
#VideosMenu ("https://freshporno.net/models/ricky-spanish/")
#VideosMenu ("https://freshporno.net/channels/cuckold-sessions/")
#-----------------------------------------------------------------------------------------------
def GetTagsMenu(url):
    print ("GetTagsMenu: " + url)
    menu = ListMenu(rootUrl=urls.rootUrl)

    html = common.OpenUrl(url)

    match = regexp.findAll(html,r'<a href="(.+)"><i class=".+"><\/i> (.+)<\/a>')

    for url, title in match:
        url = urls.rootUrl.value + url
        title = title.replace('<b>','')
        title = title.replace('</b>','')
        menu.AddItem(title=title, url=url, mode=modes.VideosMenu.value)        
    
    return menu

#GetTagsMenu(urls.tags.value)
#-----------------------------------------------------------------------------------------------
def GetChannelsMenu(url):
    print ("GetChannelsMenu: " + url)
    menu = PreviewMenu(rootUrl=urls.rootUrl)

    html = common.OpenUrl(url)

    match = regexp.findAll(html,r'<a title="(.+)" href="(.+)">\s*.*\s*(?:<img class=".+" src=".+" data-original="(.+)" alt=".+")?(?:.*\s*){5}<\/i>(.+)<\/div>')

    for title,url,img,total_videos in match:
        url = url
        img = img.replace(' ','%20')
        title = title + ' (' + total_videos + ' videos)'
        menu.AddItem(title=title, url=url, img=img, mode=modes.VideosMenu.value)        
        
    nextPageUrl = regexp.findAny(html,r'<li class="pagination-next"><a href="(.+)">Next</a></li>')
    menu.SetNextPageItem(url=nextPageUrl, mode=modes.ChannelsMenu.value)

    return menu

#GetChannelsMenu (urls.channels.value)
#-----------------------------------------------------------------------------------------------
def GetPornstarsMenu(url):
    print ("GetPornstarsMenu: " + url)
    menu = PreviewMenu(rootUrl=urls.rootUrl)

    html = common.OpenUrl(url)

    match = regexp.findAll(html,r'<div class="page-content item">\s*.+\s*<a title="(.+)" href="(.+)"(?:\s*.*){3} data-original="(.+)" alt=".+"(?:.*\s*){5}i>(.+)<\/div>')

    for title,url,img,total_videos in match:
        img = img.replace(' ','%20')
        title = title + ' (' + total_videos + ' videos)'
        menu.AddItem(title=title, url=url, img=img, mode=modes.VideosMenu.value)        
        
    nextPageUrl = regexp.findAny(html,r'<li class="pagination-next"><a href="(.+)"  data')
    menu.SetNextPageItem(url=nextPageUrl, mode=modes.PornstarsMenu.value)

    return menu

#GetPornstarsMenu (urls.pornstars.value)
#-----------------------------------------------------------------------------------------------
def GetSearchMenu(url):
    print ("Search: " + url)
    searchText = common.GetSearchText()
    menu = PreviewMenu(rootUrl=urls.rootUrl)
    
    if searchText:
        url = url.replace('{text}',searchText)
        menu = GetVideosMenu (url)
    
    return menu

#-----------------------------------------------------------------------------------------------
def PlayVideo(name,url,iconimage):
    print ("PlayVideo: " + url)

    common.ShowMessage('System', "Opening Video. Please Wait...")

    video_url = GetVideoUrl(url)

    if video_url: common.PlayVideo(name,video_url,iconimage)

#-----------------------------------------------------------------------------------------------
def GetVideoUrl(url):
    print ("GetVideoUrl: " + url)
    html = common.OpenUrl(url)
    
    pattern1 = r'<meta itemprop="contentUrl" content="(.+)">'
    pattern2 = r"video_url: '(.+)',\s*preview_url"
    pattern3 = r'(https:\/\/.+mp4).+\?download=true&download_filename=(.+\.mp4)'

    match1 = regexp.findOne(html, pattern1)
    match2 = regexp.findOne(html, pattern2)
    match3 = regexp.findOne(html, pattern2)

    videoUrl = ''
    if len(match1)>0:
        videoUrl = regexp.findOne(html, pattern1)
    elif len(match2)>0:
        videoUrl = regexp.findOne(html, pattern2)
    elif len(match3)>0:
        videoUrl = regexp.findOne(html, pattern3)

    print ("videoUrl: "+ str(videoUrl))
       

    return videoUrl

GetVideoUrl(urls.singleVideo.value)
#-----------------------------------------------------------------------------------------------


