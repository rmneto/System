import re
import common
from enum import Enum
from common import ListMenu, PreviewMenu, ListItem,  NextPageItem, regexp
#-----------------------------------------------------------------------------------------------
class modes(Enum):
    Min = 200
    MainMenu = 201
    VideosMenu = 202
    TagsMenu = 203
    PornstarsMenu = 204
    ChannelsMenu = 205
    PlayVideo = 206
    Search = 207
    Max = 219

#-----------------------------------------------------------------------------------------------
class urls(Enum):
    rootUrl = 'https://ok.xxx'
    allVideos = rootUrl
    popular = rootUrl+'/popular/'
    trending = rootUrl+'/trending/'
    tags = rootUrl+'/tags/'
    pornstars = rootUrl+'/models/'
    channels = rootUrl+'/channels/'
    search = rootUrl+'/search/{text}/'
    singleVideo = rootUrl+'/video/678723/'

#-----------------------------------------------------------------------------------------------
def GetMainMenu():
    menu = ListMenu(title = "ok.xxx")
    menu.items = [ 
        ListItem(title="All Videos", url=urls.allVideos.value,mode=modes.VideosMenu.value),
        ListItem(title="Popular", url=urls.popular.value,mode=modes.VideosMenu.value),
        ListItem(title="Trending", url=urls.trending.value,mode=modes.VideosMenu.value),
        ListItem(title="Channels", url=urls.channels.value,mode=modes.ChannelsMenu.value),
        ListItem(title="Pornstars", url=urls.pornstars.value,mode=modes.PornstarsMenu.value),
        ListItem(title="Tags", url=urls.tags.value,mode=modes.TagsMenu.value),
        ListItem(title="Search", url=urls.search.value,mode=modes.Search.value) 
    ]

    return menu

#-----------------------------------------------------------------------------------------------
def ProcessRequest(mode:modes, name, url, iconimage):
    print ("ProcessRequest: "+str(mode)+" - "+name+" - "+url)
    menu = None

    if mode == modes.PlayVideo.value:
        PlayVideo(name,url,iconimage)
    else: 
        match mode:
            case modes.MainMenu.value: menu = GetMainMenu()
            case modes.VideosMenu.value: menu = GetVideosMenu(url)
            case modes.ChannelsMenu.value: menu = GetChannelsMenu(url)
            case modes.PornstarsMenu.value: menu = GetPornstarsMenu(url)
            case modes.TagsMenu.value: menu = GetTagsMenu(url)
            case modes.Search.value: menu = GetSearchMenu(url)

    return menu
    
#-----------------------------------------------------------------------------------------------
def GetVideosMenu(url):
    print ("GetVideosMenu: " + url)
    menu = PreviewMenu(rootUrl=urls.rootUrl)

    html = common.OpenUrl(url)
    
    match = regexp.findAll(html,r'<div class="thumb thumb-video">[\s\S]*?<\/ul>\s+<\/div>\s+<\/div>')

    for video in match:
        url,title = regexp.findOne(video,r'<a href="(.+)" title="(.+)"  data')
        img = regexp.findOne(video,r'data-original="(.+)" alt')
        duration = regexp.findOne(video,r'fa-clock-o"><\/i> <span>(.+)<\/span>')
        views = regexp.findOne(video,r'fa-eye"><\/i> <span>(.+)<\/span>')
        
        menu.AddItem(title=title, url=url, img=img, mode=modes.PlayVideo.value, duration=duration, views=views)        
    
    nextPageUrl = regexp.findAny(html,r'<li class="pagination-next"><a href="(.+)">Next</a></li>')
    menu.SetNextPageItem(url=nextPageUrl, mode=modes.VideosMenu.value)

    return menu
#GetVideosMenu(urls.allVideos.value)
#-----------------------------------------------------------------------------------------------
def GetTagsMenu(url):
    print ("GetTagsMenu: " + url)
    menu = ListMenu(rootUrl=urls.rootUrl)

    html = common.OpenUrl(url)

    match = regexp.findAll(html,r'<a class="item" href="(.+)"><i class="fa fa-tag"><\/i>(.+)<\/a>\s')

    for url, title in match:
        menu.AddItem(title=title, url=url, mode=modes.VideosMenu.value)        
    
    return menu
#GetTagsMenu(urls.tags.value)
#-----------------------------------------------------------------------------------------------
def GetChannelsMenu(url):
    print ("GetChannelsMenu: " + url)
    menu = PreviewMenu(rootUrl=urls.rootUrl)

    html = common.OpenUrl(url)

    match = regexp.findAll(html,r'<div class="thumb-bl">[\s\S]*?<\/div>')
    
    for channel in match:
        title,url,img = regexp.findOne(channel,r'<a title="(.+)" href="(.+)">\s+<img class=".+" src="(.+)" alt')
        videos = regexp.findOne(channel,r'<\/i> (.+)<\/div>')
        menu.AddItem(title=title, url=url, img=img, videos=videos, mode=modes.VideosMenu.value)

    nextPageUrl = regexp.findAny(html,r'<li class="pagination-next"><a href="(.+)">Next</a></li>')
    menu.SetNextPageItem(url=nextPageUrl, mode=modes.ChannelsMenu.value)

    return menu
#GetChannelsMenu (urls.channels.value)
#-----------------------------------------------------------------------------------------------
def GetPornstarsMenu(url):
    print ("GetPornstarsMenu: " + url)
    menu = PreviewMenu(rootUrl=urls.rootUrl)

    html = common.OpenUrl(url)

    match = regexp.findAll(html,r'<a href="(.+)" title="(.+)">\s*<img.+original="(.+)" alt=".+"\/>\s*.+\s*<\/a>\s*.*i> (.+)<\/div>')

    for url, title, img, videos in match:
        menu.AddItem(title=title, url=url, img=img, videos=videos, mode=modes.VideosMenu.value)        
        
    nextPageUrl = regexp.findAny(html,r'<li class="pagination-next"><a href="(.+)">Next</a></li>')
    menu.SetNextPageItem(url=nextPageUrl, mode=modes.PornstarsMenu.value)

    return menu
#GetPornstarsMenu(urls.pornstars.value)
#-----------------------------------------------------------------------------------------------
def GetSearchMenu(url):
    print ("GetSearchMenu: " + url)
    searchText = common.GetSearchText()
    menu = PreviewMenu(rootUrl=urls.rootUrl)
    
    if searchText:
        url = url.replace('{text}',searchText)
        menu = GetVideosMenu (url)
    
    return menu

#-----------------------------------------------------------------------------------------------
def PlayVideo(name,url,iconimage):
    print ("PlayVideo: " + url)

    common.ShowMessage('System', "Opening Video. Please Wait...")

    video_url = GetVideoUrl(url)

    if video_url: common.PlayVideo(name,video_url,iconimage)

#-----------------------------------------------------------------------------------------------
def GetVideoUrl(url):
    html = common.OpenUrl(url)
    
    video_url = regexp.findOne(html,r"var videoUrl = '(.+)'")

    print ("video_url: "+ str(video_url))

    return video_url
#GetVideoUrl(urls.singleVideo.value)
#-----------------------------------------------------------------------------------------------
