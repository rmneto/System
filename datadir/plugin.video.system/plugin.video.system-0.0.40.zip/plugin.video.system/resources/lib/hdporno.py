import re
import common
from enum import Enum
from common import ListMenu, PreviewMenu, ListItem,  NextPageItem, regexp
#-----------------------------------------------------------------------------------------------
class modes(Enum):
    Min = 500
    MainMenu = 501
    VideosMenu = 502
    PlayVideo = 503
    Search = 504
    CategoriesMenu = 505
    PornstarsMenu = 506
    Max = 599

#-----------------------------------------------------------------------------------------------
class urls(Enum):
    rootUrl = 'https://en.xhdporno.name'
    allVideos = rootUrl
    categories = rootUrl
    highestRated = rootUrl+'/reting/?sort=1'
    mostPopular = rootUrl+'/?sort=1'
    pornstars = rootUrl+'/porno-models/'
    search = rootUrl+'/search?text={text}'
    singleVideo = rootUrl+'/video/strastnaya-russkaya-parochka-otlichno-trahaetsya-v-domashnem-porno.html'

#-----------------------------------------------------------------------------------------------
def GetMainMenu():
    menu = ListMenu(title = "xHDPorno")
    menu.items = [ 
        ListItem(title="All Videos", url=urls.allVideos.value,mode=modes.VideosMenu.value),
        ListItem(title="Categories", url=urls.categories.value,mode=modes.CategoriesMenu.value),
        ListItem(title="Most Popular", url=urls.mostPopular.value,mode=modes.VideosMenu.value),
        ListItem(title="Highest Rated", url=urls.highestRated.value,mode=modes.VideosMenu.value),
        ListItem(title="Pornstars", url=urls.pornstars.value,mode=modes.PornstarsMenu.value),
        ListItem(title="Search", url=urls.search.value,mode=modes.Search.value)
    ]

    return menu

#-----------------------------------------------------------------------------------------------
def ProcessRequest(mode:modes, name, url, iconimage):
    print ("ProcessRequest: "+str(mode)+" - "+name+" - "+url)
    menu = None

    if mode == modes.PlayVideo.value:
        PlayVideo(name,url,iconimage)
    else: 
        match mode:
            case modes.MainMenu.value: menu = GetMainMenu()
            case modes.VideosMenu.value: menu = GetVideosMenu(url)
            case modes.CategoriesMenu.value: menu = GetCategoriesMenu(url)
            case modes.PornstarsMenu.value: menu = GetPornstarsMenu(url)
            case modes.Search.value: menu = GetSearchMenu(url)

    return menu

#-----------------------------------------------------------------------------------------------
def GetVideosMenu(url):
    print ("GetVideosMenu: " + url)
    menu = PreviewMenu(rootUrl=urls.rootUrl)

    html = common.OpenUrl(url)
    
    match = regexp.findAll(html,r'<a href="(.+?)">\s*<img src="(.+?)" alt="(.+?)" onmouseover(?:.*\s){3}<div class="dlit">(.+)<\/div>\s+<div class="rate">(.+)<\/div>\s+<div class="views">(.+)<\/div>\s+')

    for url, img, title, duration, likes, views in match:
        if img[:2] == '//': img = 'http:' + img
        title = '(' + duration + ' - ' + likes + ' - ' + views + ') ' + title
        menu.AddItem(title=title, url=url, img=img, mode=modes.PlayVideo.value)        
    
    nextPageUrl = regexp.findAny(html,r'<div class="navigation">\s*<a href="(.+?)"')
    menu.SetNextPageItem(url=nextPageUrl, mode=modes.VideosMenu.value)

    return menu

#GetVideosMenu(urls.allVideos.value)
#-----------------------------------------------------------------------------------------------
def GetCategoriesMenu(url):
    print ("GetCategoriesMenu: "+ url)
    menu = ListMenu(rootUrl=urls.rootUrl)

    html = common.OpenUrl(url)

    match = regexp.findAll(html,r'<a href="(/category.+?)">(.+?)</a>')

    for url, title in match:
        url = urls.rootUrl.value+url
        title = title.replace('<b>','')
        title = title.replace('</b>','')
        menu.AddItem(title=title, url=url, mode=modes.VideosMenu.value)        
    
    return menu

#menu = GetCategoriesMenu(urls.rootUrl.value)
#common.BuildListMenu(menu)
#-----------------------------------------------------------------------------------------------
def GetPornstarsMenu(url):
    print ("GetPornstarsMenu: " + url)
    menu = PreviewMenu(rootUrl=urls.rootUrl)

    html = common.OpenUrl(url)

    match = regexp.findAll(html,r'<div class="preview_screen"><a href="(/.+?)"><img src="(.+?)" alt=".+?" title="(.+?)">')

    for url,img,title in match:
        url = urls.rootUrl.value+url
        menu.AddItem(title=title, url=url, img=img, mode=modes.VideosMenu.value)        
        
    nextPageUrl = regexp.findAny(html,r' <a href="(.+)" title=\'Next \(\d+\)\'>Next &gt;&gt;')
    menu.SetNextPageItem(url=nextPageUrl, mode=modes.PornstarsMenu.value)

    return menu

#GetPornstarsMenu(urls.pornstars.value)
#-----------------------------------------------------------------------------------------------
def GetSearchMenu(url):
    print ("Search: " + url)
    searchText = common.GetSearchText()
    menu = PreviewMenu(rootUrl=urls.rootUrl)
    
    if searchText:
        url = url.replace('{text}',searchText)
        menu = GetVideosMenu (url)
    
    return menu

#-----------------------------------------------------------------------------------------------
def PlayVideo(name,url,iconimage):
    print ("PlayVideo: " + url)

    common.ShowMessage('System', "Opening Video. Please Wait...")

    video_url = GetVideoUrl(url)

    if video_url: common.PlayVideo(name,video_url,iconimage)

#-----------------------------------------------------------------------------------------------
def GetVideoUrl(url):
    html = common.OpenUrl(url)
    video_url = ""

    url_1080p = regexp.findAny(html,r'\[1080p\] (\S+mp4)')
    url_720p = regexp.findAny(html,r'\[720p\] (\S+mp4)')
    url_480p = regexp.findAny(html,r'\[480p\] (\S+mp4)')

    print ("url_1080p: "+ str(url_1080p))
    print ("url_720p: "+ str(url_720p))
    print ("url_480p: "+ str(url_480p))

    video_url = ( url_1080p if url_1080p else ( url_720p if url_720p else ( url_480p ) ) )

    print ("video_url: "+ str(video_url))

    return video_url

#GetVideoUrl(urls.singleVideo.value)
#-----------------------------------------------------------------------------------------------


