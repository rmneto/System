import freshporno

#-----------------------------------------------------------------------------------------------
def test_Search():
    menu = freshporno.GetVideosMenu(freshporno.urls.search.value.replace('{searchText}','boobs'))
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_VideosMenu():
    menu = freshporno.GetVideosMenu(freshporno.urls.allVideos.value)
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_TagsMenu():
    menu = freshporno.GetTagsMenu(freshporno.urls.tags.value)
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_ChannelsMenu():
    menu = freshporno.GetChannelsMenu(freshporno.urls.channels.value)
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_PornstarsMenu():
    menu = freshporno.GetPornstarsMenu(freshporno.urls.pornstars.value)
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_GetVideoUrl():
    videoUrl = freshporno.GetVideoUrl(freshporno.urls.singleVideo.value)
    assert videoUrl.startswith('https://')




