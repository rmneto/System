import spankbang

#-----------------------------------------------------------------------------------------------
def test_Search():
    menu = spankbang.GetVideosMenu(spankbang.urls.search.value.replace('{searchText}','boobs'))
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_VideosMenu():
    menu = spankbang.GetVideosMenu(spankbang.urls.rootUrl.value)
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_ChannelsMenu():
    menu = spankbang.GetChannelsMenu(spankbang.urls.channels.value)
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_TopTagsMenu():
    menu = spankbang.GetTopTagsMenu(spankbang.urls.topTags.value)
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_PornstarsMenu():
    menu = spankbang.GetPornstarsMenu(spankbang.urls.pornstars.value)
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_CreatorsMenu():
    menu = spankbang.GetCreatorsMenu(spankbang.urls.creators.value)
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_GetVideoUrl():
    videoUrl = spankbang.GetVideoUrl(spankbang.urls.singleVideo.value)
    assert videoUrl.startswith('https://')




