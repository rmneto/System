import hqporn

#-----------------------------------------------------------------------------------------------
def test_Search():
    menu = hqporn.GetVideosMenu(hqporn.urls.search.value.replace('{searchText}','boobs'))
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_VideosMenu():
    menu = hqporn.GetVideosMenu(hqporn.urls.allVideos.value)
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_ChannelsMenu():
    menu = hqporn.GetChannelsMenu(hqporn.urls.channels.value)
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_PornstarsMenu():
    menu = hqporn.GetChannelsMenu(hqporn.urls.pornstars.value)
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_GetVideoUrl():
    videoUrl = hqporn.GetVideoUrl(hqporn.urls.singleVideo.value)
    assert videoUrl.startswith('https://')




