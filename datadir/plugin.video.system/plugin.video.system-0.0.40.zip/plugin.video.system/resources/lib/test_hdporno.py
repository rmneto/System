import hdporno

#-----------------------------------------------------------------------------------------------
def test_Search():
    menu = hdporno.GetVideosMenu(hdporno.urls.search.value.replace('{searchText}','boobs'))
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_VideosMenu():
    menu = hdporno.GetVideosMenu(hdporno.urls.allVideos.value)
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_CategoriesMenu():
    menu = hdporno.GetCategoriesMenu(hdporno.urls.categories.value)
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_PornstarsMenu():
    menu = hdporno.GetPornstarsMenu(hdporno.urls.pornstars.value)
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_GetVideoUrl():
    videoUrl = hdporno.GetVideoUrl(hdporno.urls.singleVideo.value)
    assert videoUrl.startswith('https://')




