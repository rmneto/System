import re
import common
from enum import Enum
from common import ListMenu, PreviewMenu, ListItem,  NextPageItem, regexp
#-----------------------------------------------------------------------------------------------
class modes(Enum):
    Min = 600
    MainMenu = 601
    TopTagsMenu = 602
    ChannelsMenu = 603
    ListChannels = 604
    VideosMenu = 605
    PlayVideo = 606
    PornstarsMenu = 607
    CreatorsMenu = 608
    Search = 609
    Max = 699

#-----------------------------------------------------------------------------------------------
class urls(Enum):
    rootUrl = 'https://spankbang.com'
    trendingVideos = rootUrl+'/trending_videos'
    topTags = rootUrl+'/tags'
    channels = rootUrl+'/channels'
    exclusive = rootUrl+'/s/exclusive/'
    mostPopular = rootUrl+'/most_popular'
    pornstars = rootUrl+'/pornstars'
    creators = rootUrl+'/creators'
    search = rootUrl+'/keyword?keyword=={text}'
    singleVideo = rootUrl+'/a2amy/video/three+paths+to+pleasure'

#-----------------------------------------------------------------------------------------------
def GetMainMenu():
    menu = ListMenu(title = "SpankBang")
    menu.items = [ 
        ListItem(title="Trending Videos", url=urls.trendingVideos.value,mode=modes.VideosMenu.value),
        ListItem(title="Top Tags", url=urls.topTags.value,mode=modes.TopTagsMenu.value),
        ListItem(title="Channels", url=urls.channels.value,mode=modes.ChannelsMenu.value),
        ListItem(title="Popular", url=urls.mostPopular.value,mode=modes.VideosMenu.value),
        ListItem(title="Exclusive", url=urls.exclusive.value,mode=modes.VideosMenu.value),
        ListItem(title="Pornstars", url=urls.pornstars.value,mode=modes.PornstarsMenu.value),
        ListItem(title="Creators", url=urls.creators.value,mode=modes.CreatorsMenu.value),
        ListItem(title="Search", url=urls.search.value,mode=modes.Search.value)
    ]
    
    return menu

#-----------------------------------------------------------------------------------------------
def ProcessRequest(mode:modes, name, url, iconimage):
    print ("ProcessRequest: "+str(mode)+" - "+name+" - "+url)
    menu = None

    if mode == modes.PlayVideo.value:
        PlayVideo(name,url,iconimage)
    else: 
        match mode:
            case modes.MainMenu.value: menu = GetMainMenu()
            case modes.VideosMenu.value: menu = GetVideosMenu(url)
            case modes.ChannelsMenu.value: menu = GetChannelsMenu(url)
            case modes.CreatorsMenu.value: menu = GetCreatorsMenu(url)
            case modes.PornstarsMenu.value: menu = GetPornstarsMenu(url)
            case modes.TopTagsMenu.value: menu = GetTopTagsMenu(url)
            case modes.Search.value: menu = GetSearchMenu(url)

    return menu
    
#-----------------------------------------------------------------------------------------------
def GetVideosMenu(url):
    print ("GetVideosMenu: " + url)
    menu = PreviewMenu(rootUrl=urls.rootUrl)

    html = common.OpenUrl(url)

    #pattern1 = r'<div\s+data-testid="video-item"\s+\S+\s+class=".+"\s+>\s+<a\s+href="(.+)"\s+class=".+"\s+\S+\s+\S+\s+\S+\s+\S+ \S+\s+\S+ \S+\s+>\s+<picture>\s+<img\s+src="(.+)"+\s+loading=".+"\s+alt="(.+)"\s+class=".+"\s+x-ref=".+"\s+\/>\s+<\/picture>\s+<div\s+x-show=".+"\s+class=".+"\s+><\/div>\s+<video\s+id=".+"\s+muted\s+x-show=".+"\s+x-ref=".+"\s+class=".+"\s+x-cloak\s+playsinline\s+@error=".+"\s+@canplay=".+"\s+@ended=".+"\s+>\s+<source data-src=".+"\s+\/>\s+<\/video>\s+<div\s+class=".+"\s+data-testid="video-item-resolution"'
    pattern1 = r'<div\s+data-testid="video-item"\s+\S+\s+class=".+"\s+>\s+<a\s+href="(.+)"\s+class=".+"\s+\S+\s+\S+\s+\S+\s+\S+ \S+\s+\S+ \S+\s+>\s+<picture>\s+<img\s+src="(.+)"+\s+loading=".+"\s+alt="(.+)"\s+class=".+"\s+x-ref=".+"\s+\/>\s+<\/picture>\s+<div\s+x-show=".+"\s+class=".+"\s+><\/div>\s+<video\s+id=".+"\s+muted\s+x-show=".+"\s+x-ref=".+"\s+class=".+"\s+x-cloak\s+playsinline\s+@error=".+"\s+@canplay=".+"\s+@ended=".+"\s+>\s+<source data-src=".+"\s+\/>\s+<\/video>'
    pattern2 = r'<div class="video-item responsive-page".+">\s+.+\s+<a\s+href="(.+)"\s+.+.+\s+.+\s+.+\s.+\s.+\s+<img\s+src=".+"\s+data-src="(.+)"\s+alt="(.+)"'

    match = []
    match1 = regexp.findAll(html, pattern1)
    match2 = regexp.findAll(html, pattern2)

    if len(match1)>0: match=match1
    if len(match2)>0: match=match2

    skip = 8
    curr = 0

    for url, img, title in match:
        curr = curr + 1
        if curr <= skip: continue
        menu.AddItem(title=title, url=url, img=img, mode=modes.PlayVideo.value)        
    
    try:
        nextPageUrl = regexp.findAny(html,r'<li class="active"><a>(\d+)</a></li><li><a href="(.+?)">')[1]
        menu.SetNextPageItem(url=nextPageUrl, mode=modes.VideosMenu.value)
    except:
        pass

    return menu
#VideosMenu(urls.trendingVideos.value)
#GetVideosMenu("https://spankbang.com/1gk/channel/spankbang+gold/")
#-----------------------------------------------------------------------------------------------
def GetChannelsMenu(url):
    print ("GetChannelsMenu: " + url)
    menu = PreviewMenu(rootUrl=urls.rootUrl)

    html = common.OpenUrl(url)
    match = regexp.findAll(html,r'<li>\s*<a href="(.+)" class=".+">\s*<img src="(.+)" title="(.+)" alt=".+"')

    for url, img, title in match:
        menu.AddItem(title=title, url=url, img=img, mode=modes.VideosMenu.value)        
    
    nextPageUrl = regexp.findAny(html,r'<li class="active"><a>(\d+)<\/a><\/li><li><a href="(.+?)">')[1]
    menu.SetNextPageItem(url=nextPageUrl, mode=modes.ChannelsMenu.value)

    return menu

#ChannelsMenu(urls.channels.value)
#-----------------------------------------------------------------------------------------------
def GetTopTagsMenu(url):
    print ("GetTopTagsMenu: " + url)
    menu = ListMenu(rootUrl=urls.rootUrl)

    html = common.OpenUrl(url)

    tags = regexp.findOne(html,r'<ul class="top_tags_list">[\s\S]*?<\/ul>')
    match = regexp.findAll(tags,r'<li><a href="(.+)" class="keyword">(.+)<\/a><\/li>')

    for url, title in match:
        menu.AddItem(title=title, url=url, mode=modes.VideosMenu.value)        
    
    return menu
#TopTagsMenu(urls.topTags.value)
#-----------------------------------------------------------------------------------------------
def GetPornstarsMenu(url):
    print ("GetPornstarsMenu: "+url)
    menu = PreviewMenu(rootUrl=urls.rootUrl)

    html = common.OpenUrl(url)

    match = regexp.findAll(html,r'<a\s+href="(.+)"\s+class=".+"\s+aria-label=".+"\s+>\s+<img\s+class=".+"\s+src=".+"\s+data-src="(.+)"\s+alt="(.+)"')
    
    for url, img, title in match:
        menu.AddItem(title=title, url=url, img=img, mode=modes.VideosMenu.value)        
    
    nextPageUrl = regexp.findAny(html,r'<li class="active"><a>(\d+)</a></li><li><a href="(.+?)">')[1]
    menu.SetNextPageItem(url=nextPageUrl, mode=modes.PornstarsMenu.value)

    return menu

#PornstarsMenu(urls.pornstars.value)
#-----------------------------------------------------------------------------------------------
def GetCreatorsMenu(url):
    print ("GetCreatorsMenu: "+url)
    menu = PreviewMenu(rootUrl=urls.rootUrl)

    html = common.OpenUrl(url)
    match = regexp.findAll(html,r'<a href="(.+)" class=".+" >\s+<span class=".+">\s+<img\s+class=".+"\s+alt="(.+)"\s+src=".+"\s+data-src="(.+)"')
    
    for url, title, img in match:
        menu.AddItem(title=title, url=url, img=img, mode=modes.VideosMenu.value)        
    
    nextPageUrl = regexp.findAny(html,r'<li class="next"><a href="(.+)"><svg')
    menu.SetNextPageItem(url=nextPageUrl, mode=modes.CreatorsMenu.value)

    return menu

#CreatorsMenu(urls.creators.value)
#-----------------------------------------------------------------------------------------------
def GetSearchMenu(url):
    print ("Search: " + url)
    searchText = common.GetSearchText()
    menu = PreviewMenu(rootUrl=urls.rootUrl)
    
    if searchText:
        url = url.replace('{text}',searchText)
        menu = GetVideosMenu (url)
    
    return menu

#-----------------------------------------------------------------------------------------------
def PlayVideo(name,url,iconimage):
    print ("PlayVideo: " + url)

    common.ShowMessage('System', "Opening Video. Please Wait...")

    video_url = GetVideoUrl(url)

    if video_url: common.PlayVideo(name,video_url,iconimage)

#-----------------------------------------------------------------------------------------------
def GetVideoUrl(url):
    print ("GetVideoUrl: " + url)

    html = common.OpenUrl(url)

    url_1080p = regexp.findAny(html,r"'1080p':\s\['(\S+)'\]")
    url_720p = regexp.findAny(html,r"'720p':\s\['(\S+)'\]")
    url_480p = regexp.findAny(html,r"'480p':\s\['(\S+)'\]")

    print ("url_1080p: "+ str(url_1080p))
    print ("url_720p: "+ str(url_720p))
    print ("url_480p: "+ str(url_480p))

    video_url = ( url_1080p if url_1080p else ( url_720p if url_720p else ( url_480p ) ) )

    print ("video_url: "+ str(video_url))

    return video_url

#GetVideoUrl(urls.singleVideo.value)
#-----------------------------------------------------------------------------------------------
