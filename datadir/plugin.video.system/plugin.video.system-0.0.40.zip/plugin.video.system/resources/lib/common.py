import re
import sys
import html
from urllib.request import urlopen, Request
from urllib.parse import urlencode, quote_plus
import xbmc,xbmcgui,xbmcaddon,xbmcplugin

try:
        import cloudscraper2
except:
        import cloudscraper

#-----------------------------------------------------------------------------------------------
addon_id = 'plugin.video.system'
selfAddon = xbmcaddon.Addon(id=addon_id)
addonfolder = selfAddon.getAddonInfo('path')
artfolder = addonfolder + '/resources/img/'
down_path = selfAddon.getSetting('download-folder')
video_quality = selfAddon.getSetting('kodion.video.quality')
progressMessage = xbmcgui.DialogProgress()

_HANDLE = None
try:
        _HANDLE = int(sys.argv[1])
except:
        pass        
#-----------------------------------------------------------------------------------------------
class ListItem:
	def __init__(self, title, url, mode):		
		self.title = title
		self.url = url
		self.mode = mode

class PreviewItem(ListItem):
	def __init__(self, title, url, iconImage, mode):		
		super().__init__(title, url, mode)
		self.iconImage = iconImage
		
class NextPageItem:
	def __init__(self, url, mode):
		self.url = url
		self.mode = mode

class ListMenu:
	def __init__(self, items=[], title=None, nextPage=None, rootUrl=None):
		self.title = title
		self.items = items
		self.nextPage = nextPage
		self.rootUrl = rootUrl

	def FormatUrl(self, url):
		url = url.replace(' ','%20')
		if not url.startswith('https:') and url.startswith('//'): 
			url = 'https:'+url
		if self.rootUrl and not url.startswith('https://'):
			url = self.rootUrl.value+url
		return url

	def FormatTitle(self, title):
		title = html.unescape(title)
		title = title.replace('<b>','')
		title = title.replace('</b>','')
		return title;

		
	def AddItem(self, url:str, title:str, mode:int):
		#title
		title = self.FormatTitle(title)

		#url
		url = self.FormatUrl(url)

		print ("title: "+title)
		print ("url: "+url)
		print ("---------------------")
		self.items.append( ListItem(title=title, url=url, mode=mode) )

	def SetNextPageItem(self, url:str, mode:int):
		if url:
			url = self.FormatUrl(url)
			print ("nextPage: "+str(url))
			self.nextPage = NextPageItem(url=url, mode=mode)

class PreviewMenu(ListMenu):
	def __init__(self, items=[], title=None, nextPage=None, rootUrl=None):
		super().__init__(items=items, title=title, nextPage=nextPage, rootUrl=rootUrl)
	def AddItem(self, url:str, title:str, img:str, mode:int, duration:str=None, views:str=None, likes:str=None, videos:str=None):
		#title
		title = self.FormatTitle(title)
		
		#img
		img = self.FormatUrl(img)

		#url
		url = self.FormatUrl(url)
		
		#addInfo
		addInfo = ''
		if duration: addInfo = f'{addInfo} {duration}'.strip()
		if likes: addInfo = f'{addInfo} {likes}'.strip()
		if views: addInfo = f'{addInfo} {views}'.strip()
		if videos: addInfo = f'{addInfo} {videos} videos'.strip()

		if len(addInfo)>0:
			title = f'({addInfo}) ' + title

		print ("title: "+title)
		print ("img: "+img)
		print ("url: "+url)
		print ("---------------------")
		self.items.append( PreviewItem(title=title, url=url, iconImage=img, mode=mode) )


#-----------------------------------------------------------------------------------------------
class regexp:
	def findAll(text:str,exp:str,flags=None):
		if flags:
			match = re.compile(exp,flags).findall(text)
		else:
			match = re.compile(exp).findall(text)
		print("found: "+str(len(match)))
		return match
	
	def findOne(text:str,exp:str,flags=None):
		if flags:
			match = re.compile(exp,flags).findall(text)[0]
		else:
			match = re.compile(exp).findall(text)[0]
		return match

	def findAny(text:str,exp:str,flags=None):
		match = None
		try:
			if flags:
				match = re.compile(exp,flags).findall(text)[0]
			else:
				match = re.compile(exp).findall(text)[0]
		except:
			pass
		
		return match

#-----------------------------------------------------------------------------------------------
def OpenUrl(url):
        try:
                scraper = cloudscraper2.create_scraper(browser={'browser': 'firefox','platform': 'windows','mobile': False})
        except:
                scraper = cloudscraper.create_scraper(browser={'browser': 'firefox','platform': 'windows','mobile': False})
        return scraper.get(url).content.decode('utf-8')

#-----------------------------------------------------------------------------------------------
def addLinkItem(name,url,iconimage):
	name = formatString(name)
	ok=True
	liz=xbmcgui.ListItem(name)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	try:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
	except:
		pass
	return ok

#-----------------------------------------------------------------------------------------------
def addGenericItem(name,url,mode,iconimage):
	#print ("addFolderItem")
	name = formatString(name)
	u=sys.argv[0]+"?url="+quote_plus(url)+"&mode="+str(mode)+"&name="+quote_plus(name)+"&iconimage="+quote_plus(iconimage)
	#print ("u: "+u)
	ok=True
	liz=xbmcgui.ListItem(name)
	#print ("iconimage:"+iconimage)
	#liz.setArt({'icon': 'DefaultVideoPlaylists.png'})
	
	liz.setArt({'icon': iconimage})

	try:
		ok=xbmcplugin.addDirectoryItem(handle=_HANDLE,url=u,listitem=liz,isFolder=True,totalItems=1)
	except:
		pass

	return ok

#-----------------------------------------------------------------------------------------------
def addVideosItem(name,url,mode):
	return addGenericItem(name,url,mode,'Videos.png')

#-----------------------------------------------------------------------------------------------
def addPreviewItem(name,url,mode,img):
	return addGenericItem(name,url,mode,img)

#-----------------------------------------------------------------------------------------------
def addFolderItem(name,url,mode):
	return addGenericItem(name,url,mode,'DefaultFolder.png')

#-----------------------------------------------------------------------------------------------
def addPasswordItem(name,url,mode):
	return addGenericItem(name,url,mode,artfolder+'Password.png')

#-----------------------------------------------------------------------------------------------
def addNextItem(name,url,mode):
	return addGenericItem(name,url,mode,artfolder+'Next.png')

#-----------------------------------------------------------------------------------------------
def addSearchItem(name,url,mode):
	return addGenericItem(name,url,mode,artfolder+'Search.png')

#-----------------------------------------------------------------------------------------------
def addVideoItem(name,url,mode,iconimage):
	name = formatString(name)
	u=sys.argv[0]+"?url="+quote_plus(url)+"&mode="+str(mode)+"&name="+quote_plus(name)+"&iconimage="+quote_plus(iconimage)
	ok=True
	liz=xbmcgui.ListItem(name)

	if iconimage[:2] == '//': iconimage = 'https:' + iconimage
	liz.setArt({'icon':iconimage})

	ok=xbmcplugin.addDirectoryItem(handle=_HANDLE,url=u,listitem=liz,isFolder=False,totalItems=1)

	return ok

#-----------------------------------------------------------------------------------------------
def formatString(text):
        text = str(text)
        text = text.replace("&#8211;","-")
        text = text.replace("&#8217;","'")
        text = text.replace("&#038;","&")
        text = text.replace("&amp;","&")
        return text

#-----------------------------------------------------------------------------------------------
def ShowMessage(title, message, times=5000):
        progressMessage.create('System', message)
        progressMessage.update(0)

#-----------------------------------------------------------------------------------------------
def PlayVideo(name,streamurl,iconimage = "DefaultVideo.png"):
        progressMessage.create('System', "Opening Video. Please Wait...")
        progressMessage.update(0)

        listitem = xbmcgui.ListItem(name)
        listitem.setArt({'icon':iconimage})
        player = xbmc.Player()
        player.play(streamurl,listitem)

#-----------------------------------------------------------------------------------------------
def GetSearchText():
	keyb = xbmc.Keyboard('', "Enter Keyword:")
	keyb.doModal()
	searchText = None
	
	if (keyb.isConfirmed()):
		searchText = keyb.getText()
		searchText=quote_plus(searchText)

	return searchText

#-----------------------------------------------------------------------------------------------
def EndOfDirectoryListMode():
	xbmcplugin.endOfDirectory(_HANDLE)
	xbmc.sleep(50)
	xbmc.executebuiltin("Container.SetViewMode(200)")

#-----------------------------------------------------------------------------------------------
def EndOfDirectoryPreviewMode():
	xbmcplugin.endOfDirectory(_HANDLE)
	xbmc.sleep(50)
	xbmc.executebuiltin("Container.SetViewMode(500)")

#-----------------------------------------------------------------------------------------------
def BuildListMenu(menuObj:ListMenu):
	
	if menuObj.title:
		addLinkItem("[B][COLOR white]"+menuObj.title+"[/COLOR][/B]",None,None)

	for item in menuObj.items:
		addFolderItem(item.title,item.url,item.mode)

	if menuObj.nextPage:
		addNextItem("Next",menuObj.nextPage.url,menuObj.nextPage.mode)
	
	EndOfDirectoryListMode()

#-----------------------------------------------------------------------------------------------
def BuildPreviewMenu(menuObj:PreviewMenu):

	if menuObj.title:
		addLinkItem("[B][COLOR white]"+menuObj.title+"[/COLOR][/B]",None,None)

	for item in menuObj.items:
		addPreviewItem(item.title,item.url,item.mode,item.iconImage)

	if menuObj.nextPage:
		addNextItem("Next",menuObj.nextPage.url,menuObj.nextPage.mode)
	
	EndOfDirectoryPreviewMode()

#-----------------------------------------------------------------------------------------------
