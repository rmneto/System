import rusporn

#-----------------------------------------------------------------------------------------------
def test_Search():
    menu = rusporn.GetVideosMenu(rusporn.urls.search.value.replace('{searchText}','boobs'))
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_VideosMenu():
    menu = rusporn.GetVideosMenu(rusporn.urls.allVideos.value)
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_CategoriesMenu():
    menu = rusporn.GetCategoriesMenu(rusporn.urls.categories.value)
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_PornstarsMenu():
    menu = rusporn.GetPornstarsMenu(rusporn.urls.pornstars.value)
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_GetVideoUrl():
    videoUrl = rusporn.GetVideoUrl(rusporn.urls.singleVideo.value)
    assert videoUrl.startswith('https://')




