import okxxx

#-----------------------------------------------------------------------------------------------
def test_Search():
    menu = okxxx.GetVideosMenu(okxxx.urls.search.value.replace('{searchText}','boobs'))
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_VideosMenu():
    menu = okxxx.GetVideosMenu(okxxx.urls.allVideos.value)
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_TagsMenu():
    menu = okxxx.GetTagsMenu(okxxx.urls.tags.value)
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_ChannelsMenu():
    menu = okxxx.GetChannelsMenu(okxxx.urls.channels.value)
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_PornstarsMenu():
    menu = okxxx.GetPornstarsMenu(okxxx.urls.pornstars.value)
    assert len(menu.items) > 0

#-----------------------------------------------------------------------------------------------
def test_GetVideoUrl():
    videoUrl = okxxx.GetVideoUrl(okxxx.urls.singleVideo.value)
    assert videoUrl.startswith('https://')




