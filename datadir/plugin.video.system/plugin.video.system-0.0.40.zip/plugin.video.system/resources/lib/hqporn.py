import re
import common
from enum import Enum
from common import ListMenu, PreviewMenu, ListItem,  NextPageItem, regexp
#-----------------------------------------------------------------------------------------------
class modes(Enum):
    Min = 220
    MainMenu = Min+1
    VideosMenu = Min+2
    ChannelsMenu = Min+3
    PlayVideo = Min+4
    Search = Min+5
    Max = Min+19

#-----------------------------------------------------------------------------------------------
class urls(Enum):
    rootUrl = 'https://hqporn.xxx'
    allVideos = rootUrl
    new = rootUrl+'/fresh/'
    best = rootUrl+'/best/'
    channels = rootUrl+'/channels/'
    categories = rootUrl+'/categories/'
    pornstars = rootUrl+'/pornstars/'
    search = rootUrl+'/search/{text}/'
    singleVideo = rootUrl+'/hottest-babe-angela-sommers-angela-saint-threesome_1011899.html'

#-----------------------------------------------------------------------------------------------
def GetMainMenu():
    menu = ListMenu(title = "HQPorn")
    menu.items = [
        ListItem(title="All Videos", url=urls.allVideos.value,mode=modes.VideosMenu.value),
        ListItem(title="New", url=urls.new.value,mode=modes.VideosMenu.value),
        ListItem(title="Best", url=urls.best.value,mode=modes.VideosMenu.value),
        ListItem(title="Channels", url=urls.channels.value,mode=modes.ChannelsMenu.value),
        ListItem(title="Categories", url=urls.categories.value,mode=modes.ChannelsMenu.value),
        ListItem(title="Pornstars", url=urls.pornstars.value,mode=modes.ChannelsMenu.value),
        ListItem(title="Search", url=urls.search.value,mode=modes.Search.value)
    ]

    return menu

#-----------------------------------------------------------------------------------------------
def ProcessRequest(mode:modes, name, url, iconimage):
    print ("ProcessRequest: "+str(mode)+" - "+name+" - "+url)
    menu = None

    if mode == modes.PlayVideo.value:
        PlayVideo(name,url,iconimage)
    else: 
        match mode:
            case modes.MainMenu.value: menu = GetMainMenu()
            case modes.VideosMenu.value: menu = GetVideosMenu(url)
            case modes.ChannelsMenu.value: menu = GetChannelsMenu(url)
            case modes.Search.value: menu = GetSearchMenu(url)

    return menu
    
#-----------------------------------------------------------------------------------------------
def GetVideosMenu(url):
    print ("GetVideosMenu: " + url)
    menu = PreviewMenu(rootUrl=urls.rootUrl)

    html = common.OpenUrl(url)
    
    match = regexp.findAll(html,r'<div class="b-thumb-item js-thumb-item js-thumb">(?:\s*.*){4}href="(.+)"(?:\s*.*){7}title="(.+)"(?:\s*.*){6}<img loading="lazy" data-src="(.+)" width=".+"(?:\s*.*){6}<span>(.+)<\/span>')

    for url,title,img,duration in match:
        url = urls.rootUrl.value + url
        title = '(' + duration + ') ' + title
        menu.AddItem(title=title, url=url, img=img, mode=modes.PlayVideo.value)        

    nextPageUrl = regexp.findAny(html,r'<li class="b-pagination__next"><a href="(.+)" target="_self">Next<\/a><\/li>')
    menu.SetNextPageItem(url=nextPageUrl, mode=modes.VideosMenu.value)

    return menu
#items = GetVideosMenu(urls.pornstars.value)
#common.BuildPreviewMenu(items)
#-----------------------------------------------------------------------------------------------
def GetChannelsMenu(url):
    print ("GetChannelsMenu: " + url)
    menu = PreviewMenu(rootUrl=urls.rootUrl)

    html = common.OpenUrl(url)

    match = regexp.findAll(html,r'title="(.+)"\s*href="(.+)"(?:\s*.*){9}src="(.+)" width')

    for title,url,img in match:
        url = urls.rootUrl.value + url
        menu.AddItem(title=title, url=url, img=img, mode=modes.VideosMenu.value)        

    nextPageUrl = regexp.findAny(html,r'<li class="b-pagination__next"><a href="(.+)" target="_self">Next<\/a><\/li>')
    menu.SetNextPageItem(url=nextPageUrl, mode=modes.ChannelsMenu.value)

    return menu
#items = GetChannelsMenu(urls.channels.value)
#common.BuildPreviewMenu(items)
#-----------------------------------------------------------------------------------------------
def GetSearchMenu(url):
    print ("Search: " + url)
    searchText = common.GetSearchText()
    menu = PreviewMenu(rootUrl=urls.rootUrl)
    
    if searchText:
        url = url.replace('{text}',searchText)
        menu = GetVideosMenu (url)
    
    return menu

#-----------------------------------------------------------------------------------------------
def PlayVideo(name,url,iconimage):
    print ("PlayVideo: " + url)

    common.ShowMessage('System', "Opening Video. Please Wait...")

    video_url = GetVideoUrl(url)

    if video_url: common.PlayVideo(name,video_url,iconimage)

#-----------------------------------------------------------------------------------------------
def GetVideoUrl(url):
    html = common.OpenUrl(url)
    
    video_url = regexp.findOne(html, r'<video(?:\s*.*){10}<source src="(.+)" data-url-exp')

    print ("video_url: "+ str(video_url))

    return video_url
#GetVideoUrl(urls.singleVideo.value)
#-----------------------------------------------------------------------------------------------
