import re
import html
import common
import xbmcgui,xbmc,xbmcaddon,xbmcplugin
from enum import Enum

root_url = 'https://spankbang.com'
#-----------------------------------------------------------------------------------------------
class mode(Enum):
        Min = 600
        MainMenu = 601
        CategoriesMenu = 602
        TopTagsMenu = 603
        ChannelsMenu = 604
        ListChannels = 605
        ListVideos = 606
        PlayVideo = 607
        PornstarsMenu = 608
        CreatorsMenu = 609
        Search = 610
        Max = 699

#-----------------------------------------------------------------------------------------------
def setMode(newMode,name,url,iconimage):
        if newMode==mode.MainMenu.value: MainMenu()
        elif newMode==mode.ListVideos.value: ListVideos(url)
        elif newMode==mode.ListChannels.value: ListChannels(url)
        elif newMode==mode.PlayVideo.value: PlayVideo(name,url,iconimage)
        elif newMode==mode.Search.value: Search()
        elif newMode==605: common.download(name,url)
        elif newMode==206: common.selfAddon.openSettings()
        elif newMode==mode.TopTagsMenu.value: TopTagsMenu()
        elif newMode==mode.CategoriesMenu.value: CategoriesMenu()
        elif newMode==mode.ChannelsMenu.value: ChannelsMenu()
        elif newMode==mode.PornstarsMenu.value: PornstarsMenu(url)
        elif newMode==mode.CreatorsMenu.value: CreatorsMenu(url)
        
#-----------------------------------------------------------------------------------------------
def MainMenu():
        common.addFolderItem("Top Tags",'-',mode.TopTagsMenu.value)
        common.addFolderItem("Channels",'-',mode.ChannelsMenu.value)
        #common.addFolderItem("Trending",root_url+'/trending_videos/',mode.ListVideos.value)
        #common.addFolderItem("Upcoming",root_url+'/upcoming/',mode.ListVideos.value)
        #common.addFolderItem("New",root_url+'/new_videos/',mode.ListVideos.value)
        common.addFolderItem("Popular",root_url+'/most_popular/',mode.ListVideos.value)
        common.addFolderItem("Exclusive",root_url+'/s/exclusive/',mode.ListVideos.value)
        #common.addFolderItem("Verified Creators",root_url+'/s/verified+creators/',mode.ListVideos.value)
        common.addFolderItem("Pornstars",root_url+'/pornstars',mode.PornstarsMenu.value)
        common.addFolderItem("Creators",root_url+'/creators',mode.CreatorsMenu.value)
        common.addSearchItem("Search",'-',mode.Search.value)
        common.EndOfDirectoryListMode()

#-----------------------------------------------------------------------------------------------
def ListVideos(url):

        print ("ListVideos: " + url)
        pageSource = common.OpenUrl(url)

        pattern1 = r'<div\s+data-testid="video-item"\s+\S+\s+class=".+"\s+>\s+<a\s+href="(.+)"\s+class=".+"\s+\S+\s+\S+\s+\S+\s+\S+ \S+\s+\S+ \S+\s+>\s+<picture>\s+<img\s+src="(.+)"+\s+loading=".+"\s+alt="(.+)"\s+class=".+"\s+x-ref=".+"\s+\/>\s+<\/picture>\s+<div\s+x-show=".+"\s+class=".+"\s+><\/div>\s+<video\s+id=".+"\s+muted\s+x-show=".+"\s+x-ref=".+"\s+class=".+"\s+x-cloak\s+playsinline\s+@error=".+"\s+@canplay=".+"\s+@ended=".+"\s+>\s+<source data-src=".+"\s+\/>\s+<\/video>\s+<div\s+class=".+"\s+data-testid="video-item-resolution"'
        pattern2 = r'<div class="video-item responsive-page".+">\s+.+\s+<a\s+href="(.+)"\s+.+.+\s+.+\s+.+\s.+\s.+\s+<img\s+src=".+"\s+data-src="(.+)"\s+alt="(.+)"'

        match = []
        match1 = re.compile(pattern1).findall(pageSource)
        match2 = re.compile(pattern2).findall(pageSource)

        if len(match1)>0: match=match1
        if len(match2)>0: match=match2

        for url,img,title in match:

                title = html.unescape(title)

                print ("url: "+url)
                print ("img: "+img)
                print ("title: "+title)

                common.addVideoItem(title,url,mode.PlayVideo.value,img)
        try:
                next_page = re.compile(r'<li class="active"><a>(\d+)</a></li><li><a href="(.+?)">').findall(pageSource)[0][1]
        except:
                next_page = ''

        next_page = root_url + next_page
        
        print ("Next Page: "+str(next_page))
        common.addNextItem("Next",next_page,mode.ListVideos.value)

        common.EndOfDirectoryPreviewMode()
#ListVideos ("https://spankbang.com/new_videos/")
#ListVideos ("https://spankbang.com/32/pornstar/angela+white/")
#ListVideos ("https://spankbang.com/1gk/channel/spankbang+gold/")

#-----------------------------------------------------------------------------------------------
def ListChannels(url):

        print ("ListChannels: " + url)
        pageSource = common.OpenUrl(url)

        pattern = r'href="(.+)"\s+\S*".+"\s+\S*".+"\s+\S*".+"\s+\S*".+"\s+\S*".+"\s*\S*=".+"\s*\S*>\s*\S*<picture>\s+<img\s+src="(.+)".*\s.*\s.+alt="(.+)"'

        match = re.compile(pattern).findall(pageSource)

        skip = 8
        curr = 0

        for url,img,title in match:
                curr = curr + 1
                if curr <= skip: continue

                title = html.unescape(title)

                print ("url: "+url)
                print ("img: "+img)
                print ("title: "+title)

                common.addVideoItem(title,url,mode.PlayVideo.value,img)
        try:
                next_page = re.compile(r'<li class="active"><a>(\d+)</a></li><li><a href="(.+?)">').findall(pageSource)[0][1]
        except:
                next_page = ''

        next_page = root_url + next_page
        
        print ("Next Page: "+str(next_page))
        common.addNextItem("Next",next_page,mode.ListChannels.value)

        common.EndOfDirectoryPreviewMode()
#ListVideos ("https://spankbang.com/new_videos/")
#ListVideos ("https://spankbang.com/32/pornstar/angela+white/")
#ListChannels ("https://spankbang.com/1gk/channel/spankbang+gold/")

#-----------------------------------------------------------------------------------------------
def PlayVideo(name,url,iconimage):
        video_url = GetVideoUrl(url)
        if video_url: common.PlayVideo(name,video_url,iconimage)
        
#-----------------------------------------------------------------------------------------------
def TopTagsMenu():
        common.addLinkItem("[B][COLOR white]TOP TAGS[/COLOR][/B]",'','-')

        page = common.OpenUrl(root_url+"/tags")

        tags = re.compile(r'<ul class="top_tags_list">[\s\S]*?<\/ul>').findall(page)

        match = re.compile(r'<li><a href="(.+)" class="keyword">(.+)<\/a><\/li>').findall(tags[0])

        for url, title in match:
                #print (url)
                common.addVideosItem(title,root_url+url,mode.ListVideos.value)
                
        common.EndOfDirectoryListMode()

#-----------------------------------------------------------------------------------------------
def CategoriesMenu():
        common.addLinkItem("[B][COLOR white]CATEGORIES[/COLOR][/B]",'','-')

        page = common.OpenUrl(root_url+"/categories")

        match = re.compile(r'<a href="(\/category.+)"><img src=".+"><span>(.+)</span></a>').findall(page)

        for url, title in match:
                #print url
                common.addVideosItem(title,root_url+url,mode.ListVideos.value)
                
        common.EndOfDirectoryListMode()

#-----------------------------------------------------------------------------------------------
def ChannelsMenu():
        #common.addLinkItem("[B][COLOR white]CHANNELS[/COLOR][/B]",'','-')

        page = common.OpenUrl(root_url+"/channels")

        #channel = '<a href="(.+channel.+)" class=".+">\s<img src=".+" data-src=".+" alt=".+" \/>\s(.+)\s<\/a>'
        channel = r'<li>\s+<a href="(.+)">\s+<img src="(.+)" title="(.+)" alt=".+" \/>'

        match = re.compile(channel).findall(page)

        for url, img, title in match:
                img = "https:"+img
                print (root_url+url)
                common.addVideosItemWithImg(title,root_url+url,mode.ListChannels.value,img)

        common.EndOfDirectoryPreviewMode()
#ChannelsMenu()

#-----------------------------------------------------------------------------------------------
def PornstarsMenu(url):
        print ("\nPornstarsMenu: "+url)
        pageSource = common.OpenUrl(url)
        #print ("pageSource:"+ pageSource)
        match = re.compile(r'<a\s+href="(.+)"\s+class=".+"\s+aria-label=".+"\s+>\s+<img\s+class=".+"\s+src=".+"\s+data-src="(.+)"\s+alt="(.+)"').findall(pageSource)
        
        print ("Total: "+ str(len(match)))

        for url, img, title in match:
        #for url, img, title, in match:
                url = root_url+str(url)
                img = "https:"+img

                print ("title: "+title)
                print ("url: "+url)
                print ("img: "+img)
                print ("")
                title = str(title)
                #print (img)
                common.addVideosItemWithImg(title,url,mode.ListVideos.value,img)
        try:
                next_page = re.compile(r'<li class="active"><a>(\d+)</a></li><li><a href="(.+?)">').findall(pageSource)[0][1]
        except:
                next_page = ''


        next_page = root_url + next_page
        
        print ("Next Page: "+str(next_page))
        common.addNextItem("Next",next_page,mode.PornstarsMenu.value)

        common.EndOfDirectoryPreviewMode()
#PornstarsMenu(root_url+'/pornstars')
#PornstarsMenu(root_url+'/pornstars/2')


#-----------------------------------------------------------------------------------------------
def CreatorsMenu(url):
        print ("CreatorsMenu: "+url)
        pageSource = common.OpenUrl(url)
        match = re.compile(r'<a href="(.+)" class=".+" >\s+<span class=".+">\s+<img\s+class=".+"\s+alt="(.+)"\s+src=".+"\s+data-src="(.+)"').findall(pageSource)
        
        print ("Total: "+ str(len(match)))

        for url, title, img in match:
        #for url, img, title, in match:
                url = root_url+str(url)
                img = "https:"+img

                print ("title: "+title)
                print ("url: "+url)
                print ("img: "+img)
                print ("")
                title = str(title)
                #print (img)
                common.addVideosItemWithImg(title,url,mode.ListVideos.value,img)
        try:
                next_page = re.compile(r'<li class="next"><a href="(.+)"><svg').findall(pageSource)[0]
        except:
                next_page = ''


        next_page = root_url + next_page
        
        print ("Next Page: "+str(next_page))
        common.addNextItem("Next",next_page,mode.CreatorsMenu.value)

        common.EndOfDirectoryPreviewMode()
#CreatorsMenu(root_url+'/creators')

#-----------------------------------------------------------------------------------------------
def Search():
        keyb = xbmc.Keyboard('', "Enter Keyword:")
        keyb.doModal()
        if (keyb.isConfirmed()):
                searchText = keyb.getText()
                searchParameter=common.quote_plus(searchText)
                #url = root_url+'/s/' + str(searchParameter)
                url = root_url+"/keyword?keyword==" + str(searchParameter)
                ListVideos (url)


#-----------------------------------------------------------------------------------------------
def GetVideoUrl(url):
        #url = quote(url)
        print (root_url+url)
        html = common.OpenUrl(root_url+url)

        try:
                stream_url_480p = re.compile(r"'480p':\s\['(\S+)'\]").findall(html)[0]
        except:
                stream_url_480p = ''
        try:
                stream_url_720p = re.compile(r"'720p':\s\['(\S+)'\]").findall(html)[0]
        except:
                stream_url_720p = ''
        try:
                stream_url_1080p = re.compile(r"'1080p':\s\['(\S+)'\]").findall(html)[0]
        except:
                stream_url_1080p = ''
        try:
                stream_url_4k = re.compile(r'"contentUrl": "(.+)"').findall(html)[0]
        except:
                stream_url_4k = ''

        video_url = ''
        video_quality = "1"
        if video_quality == "1":
                video_url = ( stream_url_4k if stream_url_4k != '' else ( stream_url_1080p if stream_url_1080p != '' else ( stream_url_720p if stream_url_720p != '' else stream_url_480p ) ) )
        else:
                video_url = stream_url_480p
                        
                        
        print ("stream_url_480p: " + stream_url_480p)
        print ("stream_url_720p: " + stream_url_720p)
        print ("stream_url_1080p: " + stream_url_1080p)
        print ("stream_url_4k: " + stream_url_4k)

        #url_video = quote(video_url)
        video_url = video_url.replace("%3A",":")

        #video_url = "https://cdnthumb4.spankbang.com/0/5/0/5042243-t.mp4"

        print ("GetVideoUrl: "+video_url)
        return video_url

#-----------------------------------------------------------------------------------------------
#GetVideoUrl("/a2amy/video/three+paths+to+pleasure")
