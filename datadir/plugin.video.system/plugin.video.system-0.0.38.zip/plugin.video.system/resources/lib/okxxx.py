import html
import re
import common
import xbmcgui,xbmc,xbmcaddon,xbmcplugin
from enum import Enum

root_url = 'https://ok.xxx'
#-----------------------------------------------------------------------------------------------
class mode(Enum):
        Min = 200
        MainMenu = 201
        VideosMenu = 202
        TagsMenu = 203
        PornstarsMenu = 204
        ChannelsMenu = 205
        PlayVideo = 206
        Search = 207
        Max = 299

#-----------------------------------------------------------------------------------------------
def setMode(newMode,name,url,iconimage):
        if newMode==mode.MainMenu.value: MainMenu()
        elif newMode==mode.VideosMenu.value: VideosMenu(url)
        elif newMode==mode.PlayVideo.value: PlayVideo(name,url,iconimage)
        elif newMode==mode.Search.value: Search()
        elif newMode==mode.TagsMenu.value: TagsMenu(url)
        elif newMode==mode.ChannelsMenu.value: ChannelsMenu(url)
        elif newMode==mode.PornstarsMenu.value: PornstarsMenu(url)
        
#-----------------------------------------------------------------------------------------------
def MainMenu():
        common.addFolderItem("All Videos",root_url,mode.VideosMenu.value)
        common.addFolderItem("Popular",root_url+'/popular/',mode.VideosMenu.value)
        common.addFolderItem("Trending",root_url+'/trending/',mode.VideosMenu.value)
        common.addFolderItem("Pornstars",root_url+'/models/',mode.PornstarsMenu.value)
        common.addFolderItem("Channels",root_url+'/channels/',mode.ChannelsMenu.value)
        common.addFolderItem("Tags",root_url+'/tags/',mode.TagsMenu.value)
        common.addSearchItem("Search",'-',mode.Search.value)
        common.EndOfDirectoryListMode()

#-----------------------------------------------------------------------------------------------
def VideosMenu(url):
        print ("VideosMenu: " + url)
        page = common.OpenUrl(url)
        
        match = re.compile(r'<a href="(.+)" title="(.+)"\s+data-preview-custom=".+">\s+<img class=".+" fetchpriority=".+" loading=".+" src=".+" data-original="(.+)" alt=".+"').findall(page)
        for url,title,img in match:
                url = root_url + url
                #print ("url: "+url)
                #print ("title: "+title)
                #print ("img: "+img)
                common.addVideoItem(title,url,mode.PlayVideo.value,img)
                
        try:
                next_page = re.compile(r'<li class="pagination-next"><a href="(.+)">Next</a></li>').findall(page)[0]
                next_page = root_url + next_page
        except:
                next_page=""

        print ("Next Page: "+str(next_page))
        if len(next_page) > 0:
                common.addNextItem("Next",next_page,mode.VideosMenu.value)
        common.EndOfDirectoryPreviewMode()

#-----------------------------------------------------------------------------------------------
def PlayVideo(name,url,iconimage):
        print ("PlayVideo: " + url)

        video_url = GetVideoUrl(url)

        if video_url: common.PlayVideo(name,video_url,iconimage)

#-----------------------------------------------------------------------------------------------
def TagsMenu(url):
        common.addLinkItem("[B][COLOR white]TAGS[/COLOR][/B]",'','-')

        page = common.OpenUrl(url)
        #page = page.replace("\n","")

        match = re.compile(r'<a class="item" href="(.+)"><i class=".+"><\/i> (.+)<\/a>').findall(page)
        for url, title in match:
                url = root_url + url
                title = title.replace('<b>','')
                title = title.replace('</b>','')
                print ("title: "+title)
                common.addVideosItem(title,url,mode.VideosMenu.value)
                
        common.EndOfDirectoryListMode()

#-----------------------------------------------------------------------------------------------
def ChannelsMenu(url):

        page = common.OpenUrl(url)

        match = re.compile(r'<a title="(.+)" href="(.+)">\s+<img class=".+" src="(.+)" alt=".+"\/>\s*.+\s*.*\s.*i> (.+)<\/div>').findall(page)

        a=[]
        for title,url,img,total_videos in match:
                url = root_url + url
                img = "https:"+img.replace(' ','%20')
                title = title + ' (' + total_videos + ' videos)'
                temp = [url,img,title]
                a.append(temp)
                print ("url: "+url)
                print ("img: "+img)
                print ("title: "+title)
                
        total=len(a)

        for url, img, title in a:
                #print (url)
                common.addVideosItemWithImg(title,url,mode.VideosMenu.value,img)

        try:
                next_page = re.compile(r'<li class="pagination-next"><a href="(.+)">Next</a></li>').findall(page)[0]
                next_page = root_url + next_page
                print ("Next Page: "+str(next_page))
                common.addNextItem("Next",next_page,mode.ChannelsMenu.value)
        except:
                pass

        common.EndOfDirectoryPreviewMode()

#-----------------------------------------------------------------------------------------------
def PornstarsMenu(url):

        page = common.OpenUrl(url)

        match = re.compile(r'<a href="(.+)" title="(.+)">\s*<img.+original="(.+)" alt=".+"\/>\s*.+\s*<\/a>\s*.*i> (.+)<\/div>').findall(page)

        a=[]
        for url,title,img,total_videos in match:
                url = root_url + url
                img = "https:"+img.replace(' ','%20')
                title = title + ' (' + total_videos + ' videos)'
                temp = [url,img,title]
                a.append(temp)
                print ("url: "+url)
                print ("img: "+img)
                print ("title: "+title)
                
        total=len(a)

        for url, img, title in a:
                #print (url)
                common.addVideosItemWithImg(title,url,mode.VideosMenu.value,img)

        try:
                next_page = re.compile(r'<li class="pagination-next"><a href="(.+)">Next</a></li>').findall(page)[0]
                next_page = root_url + next_page
                print ("Next Page: "+str(next_page))
                common.addNextItem("Next",next_page,mode.PornstarsMenu.value)
        except:
                pass

        common.EndOfDirectoryPreviewMode()

#-----------------------------------------------------------------------------------------------
def Search():
        keyb = xbmc.Keyboard('', "Enter Keyword:")
        keyb.doModal()
        if (keyb.isConfirmed()):
                searchText = keyb.getText()
                searchParameter=common.quote_plus(searchText)
                url = root_url+'/search/' + str(searchParameter) + '/'
                VideosMenu (url)

#-----------------------------------------------------------------------------------------------
def GetVideoUrl(url):
        html = common.OpenUrl(url)
        
        video_url = re.compile(r"var videoUrl = '(.+)'").findall(html)[0]

        print ("video_url: "+ str(video_url))

        return video_url

#-----------------------------------------------------------------------------------------------
