import re
import common
import xbmcgui,xbmc,xbmcaddon,xbmcplugin
from enum import Enum


root_url = 'https://en.xhdporno.porn'
#-----------------------------------------------------------------------------------------------
class mode(Enum):
        Min = 500
        MainMenu = 501
        VideosMenu = 502
        PlayVideo = 503
        Search = 504
        CategoriesMenu = 505
        PornstarsMenu = 506
        Max = 599

#-----------------------------------------------------------------------------------------------
def setMode(newMode,name,url,iconimage):
        if newMode==mode.MainMenu.value: MainMenu()
        elif newMode==mode.VideosMenu.value: VideosMenu(url)
        elif newMode==mode.PlayVideo.value: PlayVideo(name,url,iconimage)
        elif newMode==mode.Search.value: Search()
        elif newMode==mode.CategoriesMenu.value: CategoriesMenu()
        elif newMode==mode.PornstarsMenu.value: PornstarsMenu(url)
        
#-----------------------------------------------------------------------------------------------
def MainMenu():
        common.addFolderItem("Categories",'-',mode.CategoriesMenu.value)
        common.addFolderItem("Highest Rated",root_url+'/reting/?sort=1',mode.VideosMenu.value)
        common.addFolderItem("Most Popular",root_url+'/?sort=1',mode.VideosMenu.value)
        common.addFolderItem("Pornstars",root_url+'/porno-models/',mode.PornstarsMenu.value)
        common.addSearchItem("Search",'-',mode.Search.value)
        common.EndOfDirectoryListMode()

#-----------------------------------------------------------------------------------------------
def VideosMenu(url):
        print ("VideosMenu: " + url)
        page = common.OpenUrl(url)
        page = page.replace("\n","")
        
        videoblock = re.compile(r'<div id="preview">(.+?)</a></div>').findall(page)

        a = []
        print ("videoblock: "+ str(len(videoblock)))
        for x in range(0, len(videoblock)):
                match = re.compile(r'<div class="preview_screen"><a href="(.+?)"><img src="(.+?)" alt="(.+)" onmouseover="(.+)" onmouseout="(.+)"').findall(videoblock[x])[0]
                duration = re.compile(r'<div class="dlit">(.+?)</div>').findall(videoblock[x])[0]
                rating = re.compile(r'<div class="rate">(.+?)</div>').findall(videoblock[x])[0]
                views = re.compile(r'<div class="views">(.+?)</div>').findall(videoblock[x])[0]
                
                temp = [match[0],match[2],match[1],duration,rating,views];
                a.append(temp)

        total=len(a)
        print ("total: "+ str(total))
        for url,title,img,duration,rating,views in a:
                if img[:2] == '//': img = 'http:' + img
                title = '(' + duration + ' - ' + rating + ' - ' + views + ') ' + title
                print (url)
                common.addVideoItem(title,url,mode.PlayVideo.value,img)
                #context_menu.append('Download...', url)
        
        next_page = ""
        try:
                next_page = re.compile(r'<div class="navigation">  <a href="(.+?)"').findall(page)[0]
                print ('Next 1: '+ next_page)
        except:
                try:
                        next_page = re.compile(r'<div class="navigation"><a href="(.+?)"').findall(page)[0]
                        print ('Next 2: '+ next_page)
                except: pass

        if len(next_page) > 0:
                print ("Next Page: "+str(next_page))
                common.addNextItem("Next",next_page,mode.VideosMenu.value)
        
        common.EndOfDirectoryPreviewMode()

#-----------------------------------------------------------------------------------------------
def PlayVideo(name,url,iconimage):
        print("PlayVideo: " + url)
        video_url = GetVideoUrl(url)

        print ("video_url: "+str(video_url))
        if video_url: common.PlayVideo(name,video_url,iconimage)

#-----------------------------------------------------------------------------------------------
def CategoriesMenu():
        common.addLinkItem("[B][COLOR white]CATEGORIES[/COLOR][/B]",'','-')

        page = common.OpenUrl(root_url)
        page = page.replace("\n","")

        match = re.compile(r'<a href="/(category.+?)">(.+?)</a>').findall(page)

        for url, title in match:
                common.addVideosItem(title,root_url+"/"+url,mode.VideosMenu.value)
                
        common.EndOfDirectoryListMode()
        
#-----------------------------------------------------------------------------------------------
def PornstarsMenu(url):
        pageSource = common.OpenUrl(url)
        match = re.compile(r'<div class="preview_screen"><a href="/(.+?)"><img src="(.+?)" alt="(.+?)" title="(.+?)">').findall(pageSource)
        for url, img, title1, title2 in match:
                url = root_url+"/"+url
                common.addVideosItemWithImg(title2,url,mode.VideosMenu.value,img)
        try:
                next_page = re.compile(r' <a href="(.+)" title=\'Next \(\d+\)\'>Next &gt;&gt;').findall(pageSource)[0]
                common.addNextItem("Next",next_page,mode.PornstarsMenu.value)
                
        except: pass

        common.EndOfDirectoryPreviewMode()

#-----------------------------------------------------------------------------------------------
def Search():
        keyb = xbmc.Keyboard('', "Enter Keyword:")
        keyb.doModal()
        if (keyb.isConfirmed()):
                searchText = keyb.getText()
                searchParameter=common.quote_plus(searchText)
                url = root_url+'/search?text=' + str(searchParameter)
                VideosMenu (url)

#-----------------------------------------------------------------------------------------------
def GetVideoUrl(url):
        html = common.OpenUrl(url)
        video_url = ""

        try:
                url_1080p = re.compile(r'\[1080p\] (\S+mp4)').findall(html)[0]
        except:
                url_1080p = ""

        try:
                url_720p = re.compile(r'\[720p\] (\S+mp4)').findall(html)[0]
        except:
                url_720p = ""

        try:
                url_480p = re.compile(r'\[480p\] (\S+mp4)').findall(html)[0]
        except:
                url_480p = ""
                
        print ("url_1080p: "+ str(url_1080p))
        print ("url_720p: "+ str(url_720p))
        print ("url_480p: "+ str(url_480p))

        video_url = ( url_1080p if url_1080p != '' else ( url_720p if url_720p != '' else ( url_480p ) ) )

        print ("video_url: "+ str(video_url))

        return video_url

#-----------------------------------------------------------------------------------------------


