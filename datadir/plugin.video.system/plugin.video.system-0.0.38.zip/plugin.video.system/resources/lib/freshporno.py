import html
import re
import common
import xbmcgui,xbmc,xbmcaddon,xbmcplugin
from enum import Enum

root_url = 'https://freshporno.net'
#-----------------------------------------------------------------------------------------------
class mode(Enum):
        Min = 110
        MainMenu = 111
        VideosMenu = 112
        TagsMenu = 113
        PornstarsMenu = 114
        ChannelsMenu = 115
        PlayVideo = 116
        Search = 117
        Max = 120

#-----------------------------------------------------------------------------------------------
def setMode(newMode,name,url,iconimage):
        if newMode==mode.MainMenu.value: MainMenu()
        elif newMode==mode.VideosMenu.value: VideosMenu(url)
        elif newMode==mode.PlayVideo.value: PlayVideo(name,url,iconimage)
        elif newMode==mode.Search.value: Search()
        elif newMode==mode.TagsMenu.value: TagsMenu(url)
        elif newMode==mode.ChannelsMenu.value: ChannelsMenu(url)
        elif newMode==mode.PornstarsMenu.value: PornstarsMenu(url)
        
#-----------------------------------------------------------------------------------------------
def MainMenu():
        common.addFolderItem("All Videos",root_url,mode.VideosMenu.value)
        common.addFolderItem("Pornstars",root_url+'/models/',mode.PornstarsMenu.value)
        common.addFolderItem("Channels",root_url+'/channels/',mode.ChannelsMenu.value)
        common.addFolderItem("Tags",root_url+'/tags/',mode.TagsMenu.value)
        common.addSearchItem("Search",'-',mode.Search.value)
        common.EndOfDirectoryListMode()

#-----------------------------------------------------------------------------------------------
def VideosMenu(url):
        print ("VideosMenu: " + url)
        page = common.OpenUrl(url)
        
        match = re.compile(r'<div class="page-content item">\s+.*\s*<a href="(.+)" title="(.+)" >(?:\s*.+){2} data-original="(.+)" data-webp').findall(page)
        for url,title,img in match:
                print ("url: "+url)
                print ("title: "+title)
                print ("img: "+img)
                common.addVideoItem(title,url,mode.PlayVideo.value,img)
                
        try:
                next_page = re.compile(r'<li class="pagination-next"><a href="(.+)"  data-').findall(page)[0]
                next_page = root_url + next_page
        except:
                next_page=""

        print ("Next Page: "+str(next_page))
        if len(next_page) > 0:
                common.addNextItem("Next",next_page,mode.VideosMenu.value)
        common.EndOfDirectoryPreviewMode()
#url = root_url
#VideosMenu (url)
#-----------------------------------------------------------------------------------------------
def PlayVideo(name,url,iconimage):
        print ("PlayVideo: " + url)

        video_url = GetVideoUrl(url)

        if video_url: common.PlayVideo(name,video_url,iconimage)

#-----------------------------------------------------------------------------------------------
def TagsMenu(url):
        common.addLinkItem("[B][COLOR white]TAGS[/COLOR][/B]",'','-')

        page = common.OpenUrl(url)
        #page = page.replace("\n","")

        match = re.compile(r'<a href="(.+)"><i class=".+"><\/i> (.+)<\/a>').findall(page)
        for url, title in match:
                url = root_url + url
                title = title.replace('<b>','')
                title = title.replace('</b>','')
                print ("title: "+title)
                common.addVideosItem(title,url,mode.VideosMenu.value)
                
        common.EndOfDirectoryListMode()

#-----------------------------------------------------------------------------------------------
def ChannelsMenu(url):

        page = common.OpenUrl(url)

        match = re.compile(r'<a title="(.+)" href="(.+)">\s*.*\s*(?:<img class=".+" src=".+" data-original="(.+)" alt=".+")?(?:.*\s*){5}<\/i>(.+)<\/div>').findall(page)

        a=[]
        for title,url,img,total_videos in match:
                url = url
                img = img.replace(' ','%20')
                title = title + ' (' + total_videos + ' videos)'
                temp = [url,img,title]
                a.append(temp)
                print ("url: "+url)
                print ("img: "+img)
                print ("title: "+title)
                
        total=len(a)

        for url, img, title in a:
                #print (url)
                common.addVideosItemWithImg(title,url,mode.VideosMenu.value,img)

        try:
                next_page = re.compile(r'<li class="pagination-next"><a href="(.+)">Next</a></li>').findall(page)[0]
                next_page = root_url + next_page
                print ("Next Page: "+str(next_page))
                common.addNextItem("Next",next_page,mode.ChannelsMenu.value)
        except:
                pass

        common.EndOfDirectoryPreviewMode()
url = root_url+'/channels/'
#ChannelsMenu (url)

#-----------------------------------------------------------------------------------------------
def PornstarsMenu(url):

        page = common.OpenUrl(url)

        match = re.compile(r'<div class="page-content item">\s*.+\s*<a title="(.+)" href="(.+)"(?:\s*.*){3} data-original="(.+)" alt=".+"(?:.*\s*){5}i>(.+)<\/div>').findall(page)

        a=[]
        for title,url,img,total_videos in match:
                img = img.replace(' ','%20')
                title = title + ' (' + total_videos + ' videos)'
                temp = [url,img,title]
                a.append(temp)
                print ("url: "+url)
                print ("img: "+img)
                print ("title: "+title)
                
        total=len(a)

        for url, img, title in a:
                #print (url)
                common.addVideosItemWithImg(title,url,mode.VideosMenu.value,img)

        try:
                next_page = re.compile(r'<li class="pagination-next"><a href="(.+)"  data').findall(page)[0]
                next_page = root_url + next_page
                print ("Next Page: "+str(next_page))
                common.addNextItem("Next",next_page,mode.PornstarsMenu.value)
        except:
                pass

        common.EndOfDirectoryPreviewMode()
url = root_url+'/models/'
#PornstarsMenu (url)
#-----------------------------------------------------------------------------------------------
def Search():
        keyb = xbmc.Keyboard('', "Enter Keyword:")
        keyb.doModal()
        if (keyb.isConfirmed()):
                searchText = keyb.getText()
                searchParameter=common.quote_plus(searchText)
                url = root_url+'/search/' + str(searchParameter) + '/'
                VideosMenu (url)

#-----------------------------------------------------------------------------------------------
def GetVideoUrl(url):
        html = common.OpenUrl(url)
        
        pattern1 = r'<meta itemprop="contentUrl" content="(.+)">'
        pattern2 = r"video_url: '(.+)',\s*preview_url"
        pattern3 = r'(https:\/\/.+mp4).+\?download=true&download_filename=(.+\.mp4)'

        match1 = re.compile(pattern1).findall(html)
        match2 = re.compile(pattern2).findall(html)
        match3 = re.compile(pattern2).findall(html)

        if len(match1)>0:
                video_url = re.compile(pattern1).findall(html)[0]
        elif len(match2)>0:
                video_url = re.compile(pattern2).findall(html)[0]
        elif len(match3)>0:
                video_url = re.compile(pattern3).findall(html)[0]

        #video_url = 'https://freshporno.net/get_file/2/1f313af1615b729a51de8be9f97b4f29/16000/16541/16541_720p.mp4/?download=true&download_filename=angela-white-unbound-part-2_720p.mp4'

        print ("video_url: "+ str(video_url))
       

        return video_url

#GetVideoUrl(url)
#-----------------------------------------------------------------------------------------------
