import re
import common
import xbmcgui,xbmc,xbmcaddon,xbmcplugin

root_url = 'https://spankbang.com'
#-----------------------------------------------------------------------------------------------
def setMode(mode,name,url,iconimage):
        if mode==601: MainMenu()
        elif mode==651: ListVideos(url)
        elif mode==652: FindVideoSources(name,url,iconimage)
        elif mode==680: Search()
        elif mode==605: common.download(name,url)
        elif mode==206: common.selfAddon.openSettings()
        elif mode==640: TopTagsMenu()
        elif mode==660: CategoriesMenu()
        elif mode==661: ChannelsMenu()
        elif mode==670: ListPornstars(url)
        
#-----------------------------------------------------------------------------------------------
# 601
#-----------------------------------------------------------------------------------------------
def MainMenu():
        common.addFolderItem("Top Tags",'-',640)
        common.addFolderItem("Channels",'-',661)
        common.addFolderItem("Trending",root_url+'/trending_videos/',651)
        common.addFolderItem("Upcoming",root_url+'/upcoming/',651)
        common.addFolderItem("New",root_url+'/new_videos/',651)
        common.addFolderItem("Popular",root_url+'/most_popular/',651)
        common.addFolderItem("Pornstars",root_url+'/pornstars',670)
        common.addSearchItem("Search",'-',680,)
        common.EndOfDirectoryListMode()

#-----------------------------------------------------------------------------------------------
# 651
#-----------------------------------------------------------------------------------------------
def ListVideos(url):

        print ("ListVideos: " + url)
        pageSource = common.OpenUrl(url)
        videoblock = re.compile('<div class="video-item" data-id="\d+" id="v_id_\d+" data-group=".*">\s<a href="(.+)" class="thumb ">\s<picture>\s<img src=".+" data-src="(.+)" alt="(.+)" data-preview=".+" \/>\s<\/picture>\s<p class=".+">\s<span class=".+">(.+)<\/span>\s<span class=".+">.+<\/span>\s<\/p>\s<\/a>\s<a href="(.+)<\/a>').findall(pageSource)

        a = []
        for x in range(0, len(videoblock)):     
                url = videoblock[x][0]
                img = videoblock[x][1]
                title = videoblock[x][2]
                try:
                        duration = videoblock[x][3]
                except:
                        duration = ''
                if len(duration)>0:
                        title = "("+str(duration)+" min) "+str(title)
                title = title.replace("&#39;","'")
                title = title.replace("{IGGY}","")
                title = title.replace("<strong>","")
                title = title.replace("</strong>","")

                print (img)

                temp = [url,title,img];
                a.append(temp)

        print ("Total Videos: "+ str(len(videoblock)))
        total=len(a)

        for url,title,img in a:
                if img[:2] == '//': img = 'http:' + img
                common.addVideoItem(title,url,652,img)
                #context_menu.append('Download...', url)

        try:
                next_page = re.compile('<li class="active"><a>(\d+)</a></li><li><a href="(.+?)">').findall(pageSource)[0][1]
        except:
                next_page = ''

        next_page = root_url + next_page
        
        print ("Next Page: "+str(next_page))
        common.addNextItem("Next",next_page,651)

        common.EndOfDirectoryPreviewMode()
        
#-----------------------------------------------------------------------------------------------
# 562
#-----------------------------------------------------------------------------------------------
def FindVideoSources(name,url,iconimage):
        video_url = GetVideoUrl(url)
        if video_url: common.PlayVideo(name,video_url,iconimage)
        
#-----------------------------------------------------------------------------------------------
# 640          
#-----------------------------------------------------------------------------------------------
def TopTagsMenu():
        common.addLinkItem("[B][COLOR white]TOP TAGS[/COLOR][/B]",'','-')

        page = common.OpenUrl(root_url+"/tags")

        tags = re.compile('<ul class="list">[\s\S]*?<\/ul>').findall(page)

        match = re.compile('<li><a href="(.+)" class="keyword">(.+)<\/a><\/li>').findall(tags[0])

        for url, title in match:
                #print (url)
                common.addVideosItem(title,root_url+url,651)
                
        common.EndOfDirectoryListMode()

#-----------------------------------------------------------------------------------------------
# 660          
#-----------------------------------------------------------------------------------------------
def CategoriesMenu():
        common.addLinkItem("[B][COLOR white]CATEGORIES[/COLOR][/B]",'','-')

        page = common.OpenUrl(root_url+"/categories")

        match = re.compile('<a href="(\/category.+)"><img src=".+"><span>(.+)</span></a>').findall(page)

        for url, title in match:
                #print url
                common.addVideosItem(title,root_url+url,651)
                
        common.EndOfDirectoryListMode()

#-----------------------------------------------------------------------------------------------
# 661
#-----------------------------------------------------------------------------------------------
def ChannelsMenu():
        common.addLinkItem("[B][COLOR white]CHANNELS[/COLOR][/B]",'','-')

        page = common.OpenUrl(root_url+"/channels")

        channel = '<a href="(.+channel.+)" class=".+">\s<img src=".+" data-src=".+" alt=".+" \/>\s(.+)\s<\/a>'
        channel = '<a href="(.+channel.+)" class=".+">\s<img src="(.+)" title="(.+)" alt=".+" \/>\s<\/a>\s'

        match = re.compile(channel).findall(page)

        for url, img, title in match:
                img = "https:"+img
                print (img)
                common.addVideosItemWithImg(title,root_url+url,651,img)

        common.EndOfDirectoryPreviewMode()

#-----------------------------------------------------------------------------------------------
# 670
#-----------------------------------------------------------------------------------------------
def ListPornstars(url):
        print ("ListPornstars: "+url)
        pageSource = common.OpenUrl(url)
        match = re.compile('<a href="(.+)" class=".+">\s<img src="(.+)" title="(.+)" alt=".+" />\s<span class="views"><svg class=".+"><use xlink:href=".+"></use></svg>(.+)</span>\s<span class="videos"><svg class=".+"><use xlink:href=".+"></use></svg>(.+)</span>\s</a>').findall(pageSource)
        
        print ("Total: "+ str(len(match)))

        for url, img, title, viewCount, videoCount in match:
        #for url, img, title, in match:
                url = root_url+str(url)
                print ("before: "+img)
                title = str(title) + ' ' + str(viewCount) + ' views ' + str(videoCount) + ' videos'
                #print (img)
                common.addVideosItemWithImg(title,url,651,img)
        try:
                next_page = re.compile('<li class="active"><a>(\d+)</a></li><li><a href="(.+?)">').findall(pageSource)[0][1]
        except:
                next_page = ''


        next_page = root_url + next_page
        
        print ("Next Page: "+str(next_page))
        common.addNextItem("Next",next_page,670)

        common.EndOfDirectoryPreviewMode()

#-----------------------------------------------------------------------------------------------
# 680
#-----------------------------------------------------------------------------------------------
def Search():
        keyb = xbmc.Keyboard('', "Enter Keyword:")
        keyb.doModal()
        if (keyb.isConfirmed()):
                searchText = keyb.getText()
                searchParameter=common.quote_plus(searchText)
                #url = root_url+'/s/' + str(searchParameter)
                url = root_url+"/keyword?keyword==" + str(searchParameter)
                ListVideos (url)


#-----------------------------------------------------------------------------------------------
def GetVideoUrl(url):
        #url = quote(url)
        print (root_url+url)
        html = common.OpenUrl(root_url+url)

        try:
                stream_url_480p = re.compile("var stream_url_480p  = '(.+)';").findall(html)[0]
        except:
                stream_url_480p = ''
        try:
                stream_url_720p = re.compile("var stream_url_720p  = '(.+)';").findall(html)[0]
        except:
                stream_url_720p = ''
        try:
                stream_url_1080p = re.compile("var stream_url_1080p  = '(.+)';").findall(html)[0]
        except:
                stream_url_1080p = ''
        try:
                stream_url_4k = re.compile('"contentUrl": "(.+)"').findall(html)[0]
        except:
                stream_url_4k = ''

        video_url = ''
        video_quality = "1"
        if video_quality == "1":
                video_url = ( stream_url_4k if stream_url_4k != '' else ( stream_url_1080p if stream_url_1080p != '' else ( stream_url_720p if stream_url_720p != '' else stream_url_480p ) ) )
        else:
                video_url = stream_url_480p
                        
                        
        print ("stream_url_480p: " + stream_url_480p)
        print ("stream_url_720p: " + stream_url_720p)
        print ("stream_url_1080p: " + stream_url_1080p)
        print ("stream_url_4k: " + stream_url_4k)

        #url_video = quote(video_url)
        video_url = video_url.replace("%3A",":")

        #video_url = "https://cdnthumb4.spankbang.com/0/5/0/5042243-t.mp4"

        print ("GetVideoUrl: "+video_url)
        return video_url

#-----------------------------------------------------------------------------------------------
