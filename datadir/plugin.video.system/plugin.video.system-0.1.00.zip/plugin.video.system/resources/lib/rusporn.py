import re
import common
import xbmcgui,xbmc,xbmcaddon,xbmcplugin

root_url = 'https://en.rusporn.porn'
#-----------------------------------------------------------------------------------------------
def setMode(mode,name,url,iconimage):
        if mode==701: MainMenu()
        elif mode==751: ListVideos(url)
        elif mode==752: FindVideoSources(name,url,iconimage)
        elif mode==780: Search()
        elif mode==705: download(name,url)
        elif mode==760: CategoriesMenu()
        elif mode==770: ListPornstars(url)
        
#-----------------------------------------------------------------------------------------------
# 501
#-----------------------------------------------------------------------------------------------
def MainMenu():
        common.addFolderItem("All Videos",root_url,751)
        common.addFolderItem("Categories",'-',760)
        common.addFolderItem("Popular",root_url+'/most-popular/',751)
        common.addFolderItem("Best",root_url+'/the-best/',751)
        common.addFolderItem("Pornstars",root_url+'/models/',770)
        common.addSearchItem("Search",'-',780)
        common.EndOfDirectoryListMode()

#-----------------------------------------------------------------------------------------------
# 551
#-----------------------------------------------------------------------------------------------
def ListVideos(url):
        print ("ListVideos: " + url)
        page = common.OpenUrl(url)
        page = page.replace("\r\n","")
        
        videoblocks = re.compile('<div class="preview-images">(.+?)</div>\s+</div>\s+</div>').findall(page)

        a=[]
        for block in videoblocks:
                match = re.compile('<a href="(.+?)">\s*<img src="(.+?)" alt="(.+?)"').findall(block)
                for url,img,title in match:
                        duration = re.compile('<div class="duration">(.+?)</div>').findall(block)[0]
                        likes = re.compile('<div class="likes">(.+?)</div>').findall(block)[0]
                        views = re.compile('<div class="views">(.+?)</div>').findall(block)[0]
                        temp = [url,title,img,str(duration),str(likes),str(views)];
                        a.append(temp)
                
        total=len(a)
        print ("total: "+str(total))
        for url,title,img,duration,rating,views in a:
                if img[:2] == '//': img = 'http:' + img
                title = '(' + duration + ' - ' + rating + ' - ' + views + ') ' + title
                url = url + "?videoformat=4"
                print (url)
                common.addVideoItem(title,url,752,img)
                #context_menu.append('Download...', url)
        try:
                next_page = re.compile('<a href="(.+?)">Next&raquo;<\/a>').findall(page)[0]
        except:
                next_page=""

        print ("Next Page: "+str(next_page))
        if len(next_page) > 0:
                common.addNextItem("Next",next_page,751)
        common.EndOfDirectoryPreviewMode()

#-----------------------------------------------------------------------------------------------
# 552
#-----------------------------------------------------------------------------------------------
def FindVideoSources(name,url,iconimage):
        video_url = GetVideoUrl(url)
        if video_url: common.PlayVideo(name,video_url,iconimage)

#-----------------------------------------------------------------------------------------------
# 560          
#-----------------------------------------------------------------------------------------------
def CategoriesMenu():
        common.addLinkItem("[B][COLOR white]CATEGORIES[/COLOR][/B]",'','-')

        page = common.OpenUrl(root_url)
        page = page.replace("\n","")

        categories = re.compile('<div id="leftcategories">(.+?)<\/div>').findall(page)[0]
        match = re.compile('<a href="(.+?)">(.+?)</a>').findall(categories)
        for url, title in match:
                common.addVideosItem(title,url,751)
                
        common.EndOfDirectoryListMode()

#-----------------------------------------------------------------------------------------------
# 570
#-----------------------------------------------------------------------------------------------
def ListPornstars(url):

        page = common.OpenUrl(url)
        page = page.replace("\n","")

        videoblocks = re.compile('<div class="preview-images">(.+?)</div>\s+</div>\s+</div>').findall(page)

        a=[]
        for block in videoblocks:
                match = re.compile('<a href="(.+?)">\s*<img src="(.+?)" alt="(.+?) - (.+?)"').findall(block)
                for url,img,title_ru,title_en in match:
                        temp = [root_url+url,img,title_en];
                        a.append(temp)
                
        total=len(a)

        for url, img, title in a:
                print (url)
                common.addVideosItemWithImg(title,url,751,img)

        try:
                next_page = re.compile('<a href="(.+?)">Next&raquo;<\/a>').findall(page)
                common.addNextItem("Next",next_page,770)
        except:
                pass

        common.EndOfDirectoryPreviewMode()

#-----------------------------------------------------------------------------------------------
# 580
#-----------------------------------------------------------------------------------------------
def Search():
        keyb = xbmc.Keyboard('', "Enter Keyword:")
        keyb.doModal()
        if (keyb.isConfirmed()):
                searchText = keyb.getText()
                searchParameter=common.quote_plus(searchText)
                url = root_url+'/search?text=' + str(searchParameter)
                ListVideos (url)

#-----------------------------------------------------------------------------------------------
def GetVideoUrl(url):
        html = common.OpenUrl(url)
        video_url = ""
        try: 
                video_url = re.compile('src="(.+?mp4)"').findall(html)[0]
        except: return

        video_url = video_url.replace("%3A",":")
        video_url = video_url.replace("480p","720p")

        print (video_url)

        return video_url

#-----------------------------------------------------------------------------------------------
