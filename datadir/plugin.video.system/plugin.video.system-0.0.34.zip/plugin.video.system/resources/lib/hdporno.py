import re
import common
import xbmcgui,xbmc,xbmcaddon,xbmcplugin

root_url = 'https://en.xhdporno.porn'
#-----------------------------------------------------------------------------------------------
def setMode(mode,name,url,iconimage):
        if mode==501: MainMenu()
        elif mode==551: ListVideos(url)
        elif mode==552: FindVideoSources(name,url,iconimage)
        elif mode==580: Search()
        elif mode==505: download(name,url)
        elif mode==560: CategoriesMenu()
        elif mode==570: ListPornstars(url)
        
#-----------------------------------------------------------------------------------------------
# 501
#-----------------------------------------------------------------------------------------------
def MainMenu():
        common.addFolderItem("Categories",'-',560)
        common.addFolderItem("Highest Rated",root_url+'/reting/?sort=1',551)
        common.addFolderItem("Most Popular",root_url+'/?sort=1',551)
        common.addFolderItem("Pornstars",root_url+'/porno-models/',570)
        common.addSearchItem("Search",'-',580)
        common.EndOfDirectoryListMode()

#-----------------------------------------------------------------------------------------------
# 551
#-----------------------------------------------------------------------------------------------
def ListVideos(url):
        print ("ListVideos: " + url)
        page = common.OpenUrl(url)
        page = page.replace("\n","")
        
        videoblock = re.compile('<div id="preview">(.+?)</a></div>').findall(page)

        a = []
        print ("videoblock: "+ str(len(videoblock)))
        for x in range(0, len(videoblock)):
                match = re.compile('<div class="preview_screen"><a href="(.+?)"><img src="(.+?)" alt="(.+)" onmouseover="(.+)" onmouseout="(.+)"').findall(videoblock[x])[0]
                duration = re.compile('<div class="dlit">(.+?)</div>').findall(videoblock[x])[0]
                rating = re.compile('<div class="rate">(.+?)</div>').findall(videoblock[x])[0]
                views = re.compile('<div class="views">(.+?)</div>').findall(videoblock[x])[0]
                
                temp = [match[0],match[2],match[1],duration,rating,views];
                a.append(temp)

        total=len(a)
        print ("total: "+ str(total))
        for url,title,img,duration,rating,views in a:
                if img[:2] == '//': img = 'http:' + img
                title = '(' + duration + ' - ' + rating + ' - ' + views + ') ' + title
                print (url)
                common.addVideoItem(title,url,552,img)
                #context_menu.append('Download...', url)
        
        next_page = ""
        try:
                next_page = re.compile('<div class="navigation">  <a href="(.+?)"').findall(page)[0]
                print ('Next 1: '+ next_page)
        except:
                try:
                        next_page = re.compile('<div class="navigation"><a href="(.+?)"').findall(page)[0]
                        print ('Next 2: '+ next_page)
                except: pass

        if len(next_page) > 0:
                print ("Next Page: "+str(next_page))
                common.addNextItem("Next",next_page,551)
        
        common.EndOfDirectoryPreviewMode()
#-----------------------------------------------------------------------------------------------
# 552
#-----------------------------------------------------------------------------------------------
def FindVideoSources(name,url,iconimage):
        video_url = GetVideoUrl(url)
        if video_url: common.PlayVideo(name,video_url,iconimage)
        
#-----------------------------------------------------------------------------------------------
# 560          
#-----------------------------------------------------------------------------------------------
def CategoriesMenu():
        common.addLinkItem("[B][COLOR white]CATEGORIES[/COLOR][/B]",'','-')

        page = common.OpenUrl(root_url)
        page = page.replace("\n","")

        match = re.compile('<a href="/(category.+?)">(.+?)</a>').findall(page)
        for url, title in match:
                common.addVideosItem(title,root_url+"/"+url,551)
                
        common.EndOfDirectoryListMode()
        
#-----------------------------------------------------------------------------------------------
# 570
#-----------------------------------------------------------------------------------------------
def ListPornstars(url):
        pageSource = common.OpenUrl(url)
        match = re.compile('<div class="preview_screen"><a href="/(.+?)"><img src="(.+?)" alt="(.+?)" title="(.+?)">').findall(pageSource)
        for url, img, title1, title2 in match:
                url = root_url+"/"+url
                common.addVideosItemWithImg(title2,url,551,img)
        try:
                next_page = re.compile(' <a href="(.+)" title=\'Next \(\d+\)\'>Next &gt;&gt;').findall(pageSource)[0]
                common.addNextItem("Next",next_page,570)
                
        except: pass

        common.EndOfDirectoryPreviewMode()

#-----------------------------------------------------------------------------------------------
# 580
#-----------------------------------------------------------------------------------------------
def Search():
        keyb = xbmc.Keyboard('', "Enter Keyword:")
        keyb.doModal()
        if (keyb.isConfirmed()):
                searchText = keyb.getText()
                searchParameter=common.quote_plus(searchText)
                url = root_url+'/search?text=' + str(searchParameter)
                ListVideos (url)

#-----------------------------------------------------------------------------------------------
def GetVideoUrl(url):
        html = common.OpenUrl(url)
        video_url = ""
        try: 
                video_url = re.compile('\[720p]\s(.+?)\"').findall(html)[0]
        except: return

        video_url = video_url.replace("%3A",":")
        video_url = video_url.replace("480p","720p")

        return video_url
#GetVideoUrl('https://en.xhdporno.name/video/podruga-s-bolshoy-zhopoy-erotichno-vstala-rakom-pered-parnem.html')
#-----------------------------------------------------------------------------------------------


