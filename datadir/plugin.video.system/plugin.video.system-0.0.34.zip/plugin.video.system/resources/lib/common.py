import sys,re
from urllib.request import urlopen, Request
from urllib.parse import urlencode, quote_plus
import xbmc,xbmcgui,xbmcaddon,xbmcplugin

try:
        import cloudscraper2
except:
        import cloudscraper

#-----------------------------------------------------------------------------------------------
addon_id = 'plugin.video.system'
selfAddon = xbmcaddon.Addon(id=addon_id)
addonfolder = selfAddon.getAddonInfo('path')
artfolder = addonfolder + '/resources/img/'
down_path = selfAddon.getSetting('download-folder')
video_quality = selfAddon.getSetting('kodion.video.quality')
progressMessage = xbmcgui.DialogProgress()

_HANDLE = None
try:
        _HANDLE = int(sys.argv[1])
except:
        pass        

#-----------------------------------------------------------------------------------------------
def OpenUrl(url):
        try:
                scraper = cloudscraper2.create_scraper(browser={'browser': 'firefox','platform': 'windows','mobile': False})
        except:
                scraper = cloudscraper.create_scraper(browser={'browser': 'firefox','platform': 'windows','mobile': False})
        return scraper.get(url).content.decode('utf-8')

#-----------------------------------------------------------------------------------------------
def OpenUrlSimple(url):
	req = Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urlopen(req)
	link=response.read().decode('utf-8')
	response.close()
	return link

#-----------------------------------------------------------------------------------------------
def addLinkItem(name,url,iconimage):
	name = formatString(name)
	ok=True
	liz=xbmcgui.ListItem(name)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	try:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
	except:
		pass
	return ok

#-----------------------------------------------------------------------------------------------
def addGenericItem(name,url,mode,iconimage):
	#print ("addFolderItem")
	name = formatString(name)
	u=sys.argv[0]+"?url="+quote_plus(url)+"&mode="+str(mode)+"&name="+quote_plus(name)+"&iconimage="+quote_plus(iconimage)
	#print ("u: "+u)
	ok=True
	liz=xbmcgui.ListItem(name)
	print ("iconimage:"+iconimage)
	#liz.setArt({'icon': 'DefaultVideoPlaylists.png'})
	
	liz.setArt({'icon': iconimage})

	try:
		ok=xbmcplugin.addDirectoryItem(handle=_HANDLE,url=u,listitem=liz,isFolder=True,totalItems=1)
	except:
		pass

	return ok

#-----------------------------------------------------------------------------------------------
def addVideosItem(name,url,mode):
	return addGenericItem(name,url,mode,'Videos.png')

#-----------------------------------------------------------------------------------------------
def addVideosItemWithImg(name,url,mode,img):
	return addGenericItem(name,url,mode,img)

#-----------------------------------------------------------------------------------------------
def addFolderItem(name,url,mode):
	return addGenericItem(name,url,mode,'DefaultFolder.png')

#-----------------------------------------------------------------------------------------------
def addPasswordItem(name,url,mode):
	return addGenericItem(name,url,mode,artfolder+'Password.png')

#-----------------------------------------------------------------------------------------------
def addNextItem(name,url,mode):
	return addGenericItem(name,url,mode,artfolder+'Next.png')

#-----------------------------------------------------------------------------------------------
def addSearchItem(name,url,mode):
	return addGenericItem(name,url,mode,artfolder+'Search.png')

#-----------------------------------------------------------------------------------------------
def addVideoItem(name,url,mode,iconimage):
	name = formatString(name)
	u=sys.argv[0]+"?url="+quote_plus(url)+"&mode="+str(mode)+"&name="+quote_plus(name)+"&iconimage="+quote_plus(iconimage)
	ok=True
	liz=xbmcgui.ListItem(name)

	if iconimage[:2] == '//': iconimage = 'https:' + iconimage
	liz.setArt({'icon':iconimage})

	ok=xbmcplugin.addDirectoryItem(handle=_HANDLE,url=u,listitem=liz,isFolder=False,totalItems=1)

	return ok

#-----------------------------------------------------------------------------------------------
def formatString(text):
        text = str(text)
        text = text.replace("&#8211;","-")
        text = text.replace("&#8217;","'")
        text = text.replace("&#038;","&")
        text = text.replace("&amp;","&")
        return text

#-----------------------------------------------------------------------------------------------
def PlayVideo(name,streamurl,iconimage = "DefaultVideo.png"):
        progressMessage.create('System', "Opening Video. Please Wait...")
        progressMessage.update(0)

        listitem = xbmcgui.ListItem(name)
        listitem.setArt({'icon':iconimage})
        player = xbmc.Player()
        player.play(streamurl,listitem)

#-----------------------------------------------------------------------------------------------
def EndOfDirectoryListMode():
	xbmcplugin.endOfDirectory(_HANDLE)
	xbmc.sleep(50)
	xbmc.executebuiltin("Container.SetViewMode(200)")
	xbmc.executebuiltin("Container.SetViewMode(200)")

#-----------------------------------------------------------------------------------------------
def EndOfDirectoryPreviewMode():
	xbmcplugin.endOfDirectory(_HANDLE)
	xbmc.sleep(50)
	xbmc.executebuiltin("Container.SetViewMode(500)")
	xbmc.executebuiltin("Container.SetViewMode(500)")
